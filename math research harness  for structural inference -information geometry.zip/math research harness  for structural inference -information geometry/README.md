# Math Research Harness

This repository is a starting point for owner-directed mathematical research
with AI agents. It organizes conversation, evidence, literature, computation,
scratch work, durable notes, canonical state, and Git checkpoints. Its sample
inquiry is fictional and uses placeholders such as `Property P`, `Condition A`,
and `setting S`.

## Start here

- Agents follow [`AGENTS.md`](AGENTS.md).
- Optional cross-thread mathematical conventions live in
  [`PROJECT-FOUNDATIONS.md`](PROJECT-FOUNDATIONS.md); mathematical
  work normally starts from `STEERING.md` and the relevant thread ledger.
- Owners can begin with
  [`OWNER-GUIDE/OWNER-GUIDE.md`](OWNER-GUIDE/OWNER-GUIDE.md).
- Harness reviews are opt-in; invoke
  [`/review-agent-harness`](.github/prompts/review-agent-harness.prompt.md)
  explicitly with `mode=compare`, `mode=freshness`, or a separately authorized
  `mode=apply`. Freshness checks write a dated diff report first and never
  silently update the memo or its evidence register.
- The generic literature workflow is in [`LITERATURE.md`](LITERATURE.md).
- Computational reproducibility is described in
  [`COMPUTATIONS.md`](COMPUTATIONS.md), with selected backends recorded in
  [`ENVIRONMENT.md`](ENVIRONMENT.md).

## Prerequisites

Git records durable checkpoints. The configured computation stack runs through
`uv`, which installs its locked Python packages.

| Feature | Owner-installed command-line tools |
|---|---|
| Repository workflow | `git` |
| Mathematical computing and Python utilities | `uv` |

`uv sync` installs SymPy, NumPy, and SciPy from `uv.lock`.

To prepare the environment and run the tests:

```bash
uv sync
uv run python tools/computation_preflight.py
uv run python -m unittest discover -s tests
uv run python -m unittest discover -s .github/prompts -p 'test_hypothesis_batch.py'
```

Run the included Python utilities through `uv`.

Native publisher search URLs for the three required literature sources can be
generated with `uv run python tools/reference_search.py --query "search terms"`.
Repeat `--query` for multiple query families, use `--open` to launch the result
pages, or `--json` to capture the provider/query/URL list. The utility does not
scrape or bypass publisher access controls; search-result review remains part
of the literature workflow in [`LITERATURE.md`](LITERATURE.md).

## Repository map

| Path | Purpose |
|---|---|
| `AGENTS.md` | Authoritative session contract: boot, authority, evidence, records, and safety |
| `PROJECT-FOUNDATIONS.md` | Optional shared mathematical conventions and scope guards, with primary claim pointers |
| `STEERING.md` | Current directions that genuinely apply across research threads |
| Root policy documents | Session contract, research policies, and computational environment |
| `templates/` | Optional starting shapes for new records |
| `.github/prompts/` | Hypothesis workflow and validator, plus the opt-in agent-harness review prompt |
| `threads/` | One fictional thread showing present-facing canonical state |
| `examples/` | A worked conversation-to-checkpoint walkthrough |
| `lib/` | Maintained reusable research code in any language or system |
| `experiments/` | One-off programs organized by research thread |
| `data/` | Ignored local machine-readable outputs and certificates, with a tracked usage guide |
| `results/` | Human-readable summaries paired with durable outputs |
| `paper/` | Optional live paper material, edited only on explicit owner request, with the manuscript vocabulary check in `paper/vocab/` |
| `briefings/` | Optional interface for collaborators without repository access |
| `references/` | Ignored local source workspace with a tracked usage guide |
| `.research-scratch/` | Ignored workspace for disposable probes and reasoning |
| `research-scratch/` | Ignored workspace for generated hypothesis candidates and batch manifests |
| `harness-improvement-proposals/` | Owner-requested harness comparison reports; proposals are not applied automatically |
| `harness-improvement-proposals/research-evidence-register.json` | Claim-level sources, review dates, freshness intervals, and evidence history for the harness research memo |
| `tools/` | Literature acquisition, preparation, catalog and citation-discovery utilities, the claim-catalog audit, and the manuscript vocabulary check |
| `tests/` | Offline unit tests for the reusable harness tools; hypothesis batch tests are alongside their workflow in `.github/prompts/` |

## Design principles

1. Conversation controls the work; the owner does not operate the harness.
2. Load only the context the current task needs.
3. Scope, evidence strength, significance, and publication authority are
   separate decisions.
4. Continue while a credible next step has worthwhile expected value.
5. Keep fluid work in scratch; preserve only coherent durable packages.
6. Let canonical state describe the present and Git preserve history.
7. Treat opportunities as a map, not an assignment queue.

Computational work currently uses SymPy for symbolic work, NumPy for numerical
arrays and linear algebra, and SciPy for numerical routines. Record future
backend changes in [`ENVIRONMENT.md`](ENVIRONMENT.md), and record the software
and version when a result depends on them. Machine-readable outputs
under `data/` stay on local disk; the tracked record of a computation is its
manifest in `results/`.

This is a working template, not a fixed configuration. When starting a real
project, agents should replace the fictional thread and adapt the session
contract, terminology, records, tools, and environment guidance to the owner's
working practices and the actual repository. The owner can describe preferences
in ordinary conversation; the agent should turn them into scoped repository
changes rather than requiring the owner to configure the harness manually.

The template is available under the [`MIT License`](LICENSE).
