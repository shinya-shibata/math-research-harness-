# Shared mathematical foundations

This file is a conditional cross-thread reference, not universal mathematical
boot state. Read it when a thread ledger cites it, when the task genuinely
spans several threads, or when one of the conventions recorded here is
load-bearing. The normal mathematical boot sequence is `AGENTS.md`,
`STEERING.md`, and the relevant thread ledger.

Thread ledgers own their definitions, current theory, and specialized
mathematics. This file is not an independent claim catalog. Each nonformal
result cites the primary canonical claim that owns its exact statement, status,
and evidence. Thread ledgers may impose narrower hypotheses or local
conventions; they do not silently enlarge a statement recorded here.

## Current foundations

The fictional starter state has no admitted project-wide mathematical facts.
When adapting the template, organize entries by the mathematics—for example,
ambient conventions, reusable cross-thread results, and recurring scope guards.
Keep proofs, detailed provenance, and specialized consequences in the owning
thread, and cite its durable claim as `<thread>:<claim-id>`.

## Admission and maintenance

Foundation maintenance is part of ordinary canonical checkpoints. The owner
does not need to request a separate thread, campaign, or periodic review. When
an affected primary claim changes or is corrected in a way that changes common
boot state, update the existing entry here in the same checkpoint.

Promotion of a new item is exceptional. Unless the owner explicitly directs
otherwise, add it only when all of the following hold:

1. **Durable basis.** It is formal, or it has an exact primary durable claim
   whose evidence status and scope support its use here.
2. **Cross-thread value.** Agents working in several substantively different
   threads need it to choose correct assumptions or routes, avoid redoing
   settled work, or avoid a recurring false inference.
3. **Stability.** It is not merely a fresh campaign result, family formula,
   bounded computation, open route, or pending literature claim.
4. **Compression.** Its reusable content can be stated briefly here while
   proof, provenance, qualifications, and specialized consequences remain in
   the owning claim catalog and ledger.

Novelty, strength, or interest alone is not an admission reason. At an ordinary
checkpoint, assess only affected claims; a full scan of all threads is not
required. If cross-thread value is unclear, leave the result in its owning
thread. It may be promoted later when repeated use makes that value clear,
without maintaining a separate candidate queue.

Every addition should check its section for duplication and obsolete wording.
Prefer consolidation or replacement to append-only growth. If an addition
would make this layer cease to be quickly scannable, compress it first or keep
it local.
