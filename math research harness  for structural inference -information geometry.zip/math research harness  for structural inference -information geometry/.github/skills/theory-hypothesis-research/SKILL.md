---
name: theory-hypothesis-research
description: "Generate new mathematical theories and hypotheses from an authorized research question, screen them against relevant literature, and test their correctness with explicit proof obligations, counterexample checks, and bounded computations. Use for theory generation, conjecture formation, hypothesis validation, mathematical research, or checking whether a proposed result is actually established."
argument-hint: "Research question, thread or ledger, scope, candidate count, and validation limits"
user-invocable: true
---

# Theory and Hypothesis Research

## Purpose

Produce a bounded, auditable research result for a new theory or hypothesis:

- a clearly quantified candidate statement;
- definitions, assumptions, conventions, and unresolved terms;
- literature checks that distinguish known results from unverified leads;
- a first discriminating test and explicit proof obligations;
- an evidence status that matches what was actually established.

This skill does not authorize a new research campaign, a new durable thread,
changes to canonical ledgers, publication edits, or claims of novelty. Those
require the repository's authorization rules and an explicit owner decision.

## When to Use

Use this skill when the request asks to:

- invent or extend a mathematical theory, conjecture, or structural principle;
- generate several hypotheses from an open research question;
- determine whether a proposed theorem is correct;
- find a counterexample, boundary case, or obstruction;
- turn an informal idea into a testable, literature-aware research candidate.

For a single narrow proof or computation with no theory generation, use the
more focused workflow instead.

## Required Inputs

Clarify these before doing substantive work. State defaults explicitly when
the user leaves them blank:

1. Research question and intended outcome.
2. Authorized thread or ledger and the specific open entries or notes.
3. Candidate count or whether one candidate is being audited.
4. Allowed transformation families, model class, and exclusions.
5. Literature, symbolic, numerical, or formal-check limits.
6. Scratch output directory and desired report format.

If the thread is ambiguous, ask which thread to use. Do not silently expand
from one thread to the whole repository.

## Workflow

### 1. Establish the local problem

Read `AGENTS.md`, `STEERING.md`, the authorized thread ledger, and only the
ledger-cited notes needed for the question. Extract the unresolved claim,
definitions, conventions, and owner-imposed boundaries. Keep structural,
statistical, geometric, and computational statements separate when the
problem spans them.

### 2. Search before generating

Run an independent question-driven literature search before using local
bibliographies. Search arXiv, SpringerLink, and SIAM with at least three
distinct query families:

- exact claim or main concepts;
- terminology variants and neighboring fields;
- contrary results, counterexamples, or failure conditions.

Inspect result pages and relevant primary sources, not just snippets. Record
queries, dates, inspected scope, source URLs and locators, access failures,
and unresolved coverage. Then use relevant local references, including
`tem.md`, as a separate discovery route and search their titles, authors,
identifiers, and alternate terminology at each provider.

An unavailable or unattempted provider makes the review `incomplete`. Never
turn a failed search into evidence of novelty or write `no match found` without
recording the stated search scope.

### 3. Define a finite generation space

For multiple candidates, create a finite seed-by-transformation matrix before
generating. Use only requested transformations, such as:

- weaken or strengthen assumptions;
- converse, equivalence, characterization, or boundary cases;
- low-dimensional, limiting, or degenerate cases;
- changes of dimension, model class, regularity, or coefficient field;
- invariance, parameterization, coordinate, or gauge dependence;
- constructive extensions, obstructions, or counterexamples;
- carefully mapped cross-domain transfers.

Keep batches at 50 candidates or fewer. Vary mechanisms and include
constructive, conditional, boundary, converse, and obstruction candidates
where appropriate. LLM recollection may suggest directions, but recalled
citations and priority claims remain unverified search leads.

### 4. Write candidate statements

For every candidate, record:

- unique ID and seed references;
- transformation family;
- a precise statement with subject, quantifiers, and conclusion;
- definitions, assumptions, conventions, and unresolved terms;
- motivation and predictions;
- known obstacles or candidate counterexamples;
- the cheapest concrete first test;
- work status and evidence status.

New candidates start with `work_status: generated` and no evidence status.
Do not label them `unverified` merely because they are new; that label has a
specific repository meaning. Collapse exact duplicates while retaining their
IDs. Mark semantic duplicates as possible duplicates and conflicts as
`conflicts_with`; do not discard them automatically.

### 5. Validate each candidate

Search each candidate's exact claim and definitions at all three required
providers. Check assumptions, scope, conventions, and version-specific
details in primary sources. Then formulate proof obligations and perform the
cheapest discriminating check first, for example:

- substitute boundary, degenerate, symmetric, or minimal cases;
- derive an independent necessary condition;
- use symbolic calculation in a small exact model;
- completely enumerate a stated finite case;
- run a bounded numerical search for counterexamples;
- check identifiability, regularity, and finite-versus-asymptotic scope.

For computation, follow `COMPUTATIONS.md` and `ENVIRONMENT.md`. Record the
backend, versions, arithmetic domain, exact command, finite scope, output,
and verifier. A successful finite calculation supports only that scope; it is
not a general proof.

### 6. Classify the result

Keep work status separate from mathematical evidence status:

- `generated`, `screened`, `selected`, `rejected`, or `parked` describe work;
- `open`, `proved/agent`, `proved/literature`, `proved/owner-checked`,
  `verified-computationally`, `refuted`, or `disputed` describe evidence.

Use `proved/literature` only when the exact claim, hypotheses, scope, and
conventions match an identified source. Use `proved/owner-checked` only when
the owner has checked the proof. Mark incomplete literature reviews and
bounded computations explicitly.

### 7. Save and report

For candidate batches, save:

```text
research-scratch/<thread>/<session>/
  candidates.jsonl
  batch-manifest.md
```

Do not overwrite existing output. Validate JSONL structure with:

```text
uv run python .github/prompts/hypothesis_batch.py research-scratch/<thread>/<session>
```

The manifest must include scope, seeds, transformation matrix, search records,
candidate counts, duplicate handling, selection rationale, prompt/model
identity when available, run date, incomplete work, and remaining ambiguity.
For a single audited hypothesis, use a concise hypothesis card or research
note in the authorized scratch or note location rather than silently updating
the ledger.

## Completion Criteria

Before reporting completion, confirm that:

- the authorization and scope were explicit;
- the candidate is mathematically quantified or unresolved terms are listed;
- all required literature providers and failures are recorded;
- the first discriminating test has an exact scope and result;
- proof, computation, and literature evidence are not conflated;
- finite successes are not presented as general theorems;
- scratch artifacts validate structurally;
- no canonical ledger, manuscript, or durable claim was changed without
  explicit authorization.

Report what was established, what was only suggested, what failed, and the
single best next discriminating step. Do not expose private chain-of-thought;
provide concise motivations, search records, proof obligations, and checkable
results instead.