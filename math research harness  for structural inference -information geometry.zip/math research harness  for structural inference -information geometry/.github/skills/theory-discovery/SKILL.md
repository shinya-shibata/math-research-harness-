---
name: theory-discovery
description: "Use only after an explicit owner request to explore a supplied research question broadly, generate and challenge theories using free lawful resources, and produce an auditable report without changing canonical state."
user-invocable: false
---

# Theory Discovery

This workflow maximizes useful exploration, not certainty. Its output is a set
of competing, testable theories ranked by the evidence that survived
adversarial checking.

## Authorization

Require an explicit owner request naming the research question, scope, and
resource limits. The workflow may use public or properly authorized free
sources, local tools, symbolic or numerical computation, and cross-domain
search. It must obey terms of service, robots rules, rate limits, licenses,
and provider policies. It must not bypass paywalls, authentication, access
controls, or usage restrictions.

The workflow may write only a new scratch discovery directory. It never edits a
ledger, manuscript, canonical claim catalog, owner direction, or durable thread
without a separate explicit instruction.

## Procedure

1. Formalize the question, objects, quantifiers, conventions, scope, and stop
   conditions. Record unresolved definitions instead of inventing them.
2. Search public literature and data through the required providers and any
   additional lawful sources allowed by the request. Record exact queries,
   dates, inspected scope, access failures, and source locators.
3. Generate candidates through independent mechanisms: deductive extension,
   converse or characterization, boundary case, constructive mechanism,
   obstruction, and carefully mapped cross-domain transfer where applicable.
4. For each candidate, state assumptions, predictions, proof obligations,
   likely failure modes, and the cheapest discriminating test.
5. Attack candidates before ranking them. Search contrary literature, known
   counterexamples, minimal cases, degenerate limits, and necessary conditions.
6. Use computation only with an exact finite scope and recorded backend. A
   finite success supports only that scope.
7. Rank candidates by explanatory coverage, assumption cost, compatibility with
   checked evidence, resistance to attempted refutation, and testability. This
   is a research prioritization, not a truth guarantee.
8. Stop on the stated budget, a genuine obstruction, owner dependency, or
   diminishing information gain. Report incomplete work explicitly.

## Evidence labels

Use the repository's evidence labels only: `open`, `proved/agent`,
`proved/literature`, `proved/owner-checked`, `verified-computationally`,
`refuted`, `disputed`, or `parked`. New candidates normally begin as `open`.
Never infer novelty from failure to find a match.

## Record keeping

Write one JSON object per line to `theory-candidates.jsonl`, validate it with
`theory_discovery.py`, and keep the human-readable plan and final report beside
it. Do not include private chain-of-thought; retain concise motivations,
search provenance, proof obligations, tests, and checkable results.