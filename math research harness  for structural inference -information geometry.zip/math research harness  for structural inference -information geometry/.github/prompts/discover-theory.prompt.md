---
name: "Discover Theory"
description: "On explicit owner request, perform broad free and lawful research on a supplied question, generate competing theories, attack them, and return an auditable report without changing canonical state."
argument-hint: "Research question, scope, depth, budget, exclusions, and deliverable"
agent: "agent"
---

# Owner-Directed Theory Discovery

Run this prompt only when the owner explicitly requests broad theory discovery
for the supplied research question. This is separate from the bounded
`/generate-hypothesis-candidates` workflow.

## Request

- Research question: ${input:question}
- Scope and permitted domains: ${input:scope}
- Exploration depth: ${input:depth}
- Time, compute, and request budget: ${input:budget}
- Exclusions: ${input:exclusions}
- Deliverable: ${input:deliverable}

The question, scope, and budget must be explicit. Ask for the missing value
instead of silently broadening it. Do not create a new durable thread or edit a
ledger, manuscript, or owner direction.

## Contract

Follow [`theory-discovery/SKILL.md`](../skills/theory-discovery/SKILL.md),
[`AGENTS.md`](../../AGENTS.md), [`LITERATURE.md`](../../LITERATURE.md), and
[`COMPUTATIONS.md`](../../COMPUTATIONS.md). Use only public or properly
authorized free resources. Follow terms of service, robots rules, rate limits,
licenses, and provider policies. Never bypass paywalls, authentication,
access controls, or usage limits.

Search broadly, but do not confuse breadth with truth. Generate competing
explanations, search for contrary results, and prioritize the cheapest
discriminating test. Treat recalled citations as leads until checked. Keep
finite computation, literature evidence, proof, and owner judgment distinct.

## Output

Create a new directory under
`research-scratch/<thread>/<session>/discovery/` containing:

```text
discovery-plan.md
theory-candidates.jsonl
literature-log.jsonl
counterexamples.jsonl
computation-summary.md
final-report.md
```

Do not overwrite an existing session. Validate `theory-candidates.jsonl` with:

```text
uv run python .github/prompts/theory_discovery.py research-scratch/<thread>/<session>/discovery
```

Report the exact search scope, sources, failures, candidate count, strongest
counterexamples, evidence status, unresolved assumptions, and the single best
next test. Do not call a candidate true, novel, or proved unless its recorded
evidence supports that exact label.