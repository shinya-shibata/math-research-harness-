"""Validate and summarize a hypothesis candidate batch without modifying it."""

from __future__ import annotations

import argparse
import json
import re
import sys
from collections import Counter
from pathlib import Path
from typing import Any, Iterator

from jsonschema import Draft202012Validator, SchemaError


WORKSPACE_ROOT = Path(__file__).resolve().parents[2]
SCHEMA_PATH = Path(__file__).resolve().with_name("HYPOTHESIS-CANDIDATE.schema.json")
REQUIRED_LITERATURE_PROVIDERS = {
    "arxiv",
    "springer",
    "siam",
}


class BatchError(ValueError):
    """Invalid batch location or schema setup."""


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "batch_dir",
        type=Path,
        help="research-scratch/<thread>/<session> containing the JSONL and manifest",
    )
    parser.add_argument(
        "--root",
        type=Path,
        default=WORKSPACE_ROOT,
        help="workspace root (defaults to the repository root)",
    )
    parser.add_argument(
        "--schema",
        type=Path,
        default=None,
        help="JSON Schema path (defaults to the schema beside this tool)",
    )
    parser.add_argument("--json", action="store_true", help="emit a machine-readable report")
    return parser


def resolve_batch_directory(root: Path, batch_dir: Path) -> Path:
    root_resolved = root.resolve()
    candidate = batch_dir if batch_dir.is_absolute() else root_resolved / batch_dir
    batch_resolved = candidate.resolve()
    try:
        relative = batch_resolved.relative_to(root_resolved)
    except ValueError as error:
        raise BatchError("batch directory must be inside the workspace") from error

    if len(relative.parts) != 3 or relative.parts[0] != "research-scratch":
        raise BatchError("batch directory must be research-scratch/<thread>/<session>")
    if not batch_resolved.is_dir():
        raise BatchError(f"batch directory does not exist: {relative.as_posix()}")
    return batch_resolved


def load_validator(schema_path: Path) -> Draft202012Validator:
    try:
        schema = json.loads(schema_path.read_text(encoding="utf-8"))
        Draft202012Validator.check_schema(schema)
    except (OSError, UnicodeError, json.JSONDecodeError, SchemaError) as error:
        raise BatchError(f"cannot load a valid JSON Schema from {schema_path}: {error}") from error
    return Draft202012Validator(schema)


def source_references(candidate: dict[str, Any]) -> Iterator[tuple[str, Any]]:
    for field in ("seed_refs", "conflicts_with", "evidence_refs"):
        for index, reference in enumerate(candidate.get(field, [])):
            yield f"{field}[{index}]", reference

    for obstacle_index, obstacle in enumerate(candidate.get("known_obstacles", [])):
        for reference_index, reference in enumerate(obstacle.get("refs", [])):
            yield f"known_obstacles[{obstacle_index}].refs[{reference_index}]", reference

    literature_review = candidate.get("literature_review", {})
    for index, seed in enumerate(literature_review.get("local_reference_seeds", [])):
        yield f"literature_review.local_reference_seeds[{index}]", {
            "path": seed["local_path"]
        }


def check_reference(root: Path, raw_path: str) -> str | None:
    if not raw_path or "\\" in raw_path or raw_path.startswith("/"):
        return "reference path must be a non-empty workspace-relative path using '/'"
    if re.match(r"^[A-Za-z]:", raw_path):
        return "absolute drive paths are not allowed"

    parts = Path(raw_path).parts
    if any(part in {".", ".."} for part in parts):
        return "reference path cannot contain '.' or '..' components"

    root_resolved = root.resolve()
    resolved = (root_resolved / Path(*parts)).resolve()
    try:
        resolved.relative_to(root_resolved)
    except ValueError:
        return "reference path resolves outside the workspace"
    if not resolved.is_file():
        return "referenced file does not exist"
    return None


def reference_key(candidate: dict[str, Any]) -> tuple[str, str] | None:
    statement = candidate.get("statement_draft")
    definitions = candidate.get("definitions_and_assumptions")
    if not isinstance(statement, str) or not isinstance(definitions, dict):
        return None
    normalized_statement = re.sub(r"\s+", " ", statement).strip()
    normalized_definitions = json.dumps(
        definitions,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    )
    return normalized_statement, normalized_definitions


def inspect_batch(root: Path, batch_dir: Path, schema_path: Path) -> dict[str, Any]:
    batch_path = resolve_batch_directory(root, batch_dir)
    validator = load_validator(schema_path)
    root_resolved = root.resolve()
    relative_batch = batch_path.relative_to(root_resolved).as_posix()
    candidates_path = batch_path / "candidates.jsonl"
    manifest_path = batch_path / "batch-manifest.md"
    if not candidates_path.is_file():
        raise BatchError(f"missing candidates.jsonl in {relative_batch}")

    issues: list[dict[str, Any]] = []
    warnings: list[dict[str, Any]] = []
    if not manifest_path.is_file():
        issues.append({
            "line": None,
            "code": "missing_manifest",
            "path": "batch-manifest.md",
            "message": "batch manifest is missing from the candidate directory",
        })
    elif not manifest_path.read_text(encoding="utf-8").strip():
        issues.append({
            "line": None,
            "code": "empty_manifest",
            "path": "batch-manifest.md",
            "message": "batch manifest is empty",
        })

    try:
        lines = candidates_path.read_text(encoding="utf-8").splitlines()
    except (OSError, UnicodeError) as error:
        raise BatchError(f"cannot read {relative_batch}/candidates.jsonl: {error}") from error

    parsed_count = 0
    schema_valid_count = 0
    candidates: list[tuple[int, dict[str, Any]]] = []
    candidate_ids: dict[str, int] = {}
    duplicate_groups: dict[tuple[str, str], list[str]] = {}
    counts_by_transformation: Counter[str] = Counter()
    counts_by_work_status: Counter[str] = Counter()
    counts_by_literature_status: Counter[str] = Counter()

    for line_number, line in enumerate(lines, start=1):
        if not line.strip():
            issues.append({
                "line": line_number,
                "code": "blank_line",
                "path": "$",
                "message": "JSONL lines must each contain one JSON object",
            })
            continue
        try:
            value = json.loads(line)
        except json.JSONDecodeError as error:
            issues.append({
                "line": line_number,
                "code": "invalid_json",
                "path": "$",
                "message": f"invalid JSON: {error.msg}",
            })
            continue

        parsed_count += 1
        if not isinstance(value, dict):
            schema_errors = list(validator.iter_errors(value))
            for error in schema_errors:
                issues.append({
                    "line": line_number,
                    "code": "schema_validation",
                    "path": "/".join(str(part) for part in error.absolute_path) or "$",
                    "message": error.message,
                })
            continue

        schema_errors = list(validator.iter_errors(value))
        if schema_errors:
            for error in schema_errors:
                issues.append({
                    "line": line_number,
                    "code": "schema_validation",
                    "path": "/".join(str(part) for part in error.absolute_path) or "$",
                    "message": error.message,
                })
            continue

        schema_valid_count += 1
        candidates.append((line_number, value))
        candidate_id = value["candidate_id"]
        if candidate_id in candidate_ids:
            issues.append({
                "line": line_number,
                "code": "duplicate_candidate_id",
                "path": "candidate_id",
                "message": f"ID also appears on line {candidate_ids[candidate_id]}",
            })
        else:
            candidate_ids[candidate_id] = line_number

        transformation = value["transformation"]["family"]
        counts_by_transformation[transformation] += 1
        counts_by_work_status[value["work_status"]] += 1
        literature_review = value["literature_review"]
        counts_by_literature_status[literature_review["status"]] += 1
        provider_searches = literature_review["provider_searches"]
        providers = [entry["provider"] for entry in provider_searches]
        local_seed_terms = {
            query
            for seed in literature_review["local_reference_seeds"]
            for query in seed["query_terms"]
        }
        missing_providers = sorted(REQUIRED_LITERATURE_PROVIDERS - set(providers))
        repeated_providers = sorted(
            provider for provider in set(providers) if providers.count(provider) > 1
        )
        if missing_providers or repeated_providers:
            issues.append({
                "line": line_number,
                "code": "literature_provider_coverage",
                "path": "literature_review/provider_searches",
                "message": (
                    f"each required external provider must appear exactly once; "
                    f"missing={missing_providers}, repeated={repeated_providers}"
                ),
            })
        if literature_review["status"] == "complete":
            unavailable = sorted(
                entry["provider"] for entry in provider_searches
                if entry["status"] != "searched"
            )
            if unavailable:
                issues.append({
                    "line": line_number,
                    "code": "incomplete_literature_search",
                    "path": "literature_review/provider_searches",
                    "message": f"complete review contains unavailable providers: {unavailable}",
                })
        for provider_search in provider_searches:
            local_queries = set(provider_search["local_reference_queries"])
            provider_queries = set(provider_search["queries"])
            if not local_queries.issubset(provider_queries):
                issues.append({
                    "line": line_number,
                    "code": "local_reference_query_not_searched",
                    "path": "literature_review/provider_searches",
                    "message": (
                        f"{provider_search['provider']} lists local-reference queries "
                        "that are absent from its query list"
                    ),
                })
            if not local_queries.issubset(local_seed_terms):
                issues.append({
                    "line": line_number,
                    "code": "local_reference_query_not_traced",
                    "path": "literature_review/provider_searches",
                    "message": (
                        f"{provider_search['provider']} lists local-reference queries "
                        "that are absent from local_reference_seeds"
                    ),
                })
            if local_seed_terms and not local_queries:
                issues.append({
                    "line": line_number,
                    "code": "local_reference_seed_unsearched",
                    "path": "literature_review/provider_searches",
                    "message": (
                        f"{provider_search['provider']} has no query derived from the "
                        "recorded local bibliography seeds"
                    ),
                })

        duplicate_key = reference_key(value)
        if duplicate_key is not None:
            duplicate_groups.setdefault(duplicate_key, []).append(candidate_id)

    for line_number, candidate in candidates:
        for field, reference in source_references(candidate):
            error = check_reference(root_resolved, reference["path"])
            if error:
                issues.append({
                    "line": line_number,
                    "code": "invalid_reference",
                    "path": f"/{field}/path",
                    "message": f"{reference['path']!r}: {error}",
                })

    exact_duplicates = [
        ids for ids in duplicate_groups.values() if len(ids) > 1
    ]
    for ids in exact_duplicates:
        warnings.append({
            "code": "exact_duplicate_candidates",
            "candidate_ids": ids,
            "message": "same statement and definitions/assumptions; candidates were not removed",
        })

    return {
        "batch_dir": relative_batch,
        "candidates_file": f"{relative_batch}/candidates.jsonl",
        "manifest_file": f"{relative_batch}/batch-manifest.md",
        "jsonl_lines": len(lines),
        "parsed_records": parsed_count,
        "schema_valid_candidates": schema_valid_count,
        "valid": not issues,
        "counts_by_transformation": dict(sorted(counts_by_transformation.items())),
        "counts_by_work_status": dict(sorted(counts_by_work_status.items())),
        "counts_by_literature_status": dict(sorted(counts_by_literature_status.items())),
        "exact_duplicate_groups": exact_duplicates,
        "issues": issues,
        "warnings": warnings,
    }


def print_text_report(report: dict[str, Any]) -> None:
    result = "PASS" if report["valid"] else "FAIL"
    print(f"{result}: {report['batch_dir']}")
    print(
        f"Records: {report['parsed_records']} parsed; "
        f"{report['schema_valid_candidates']} schema-valid; "
        f"{report['jsonl_lines']} JSONL lines"
    )
    print(f"By transformation: {report['counts_by_transformation']}")
    print(f"By work status: {report['counts_by_work_status']}")
    print(f"By literature status: {report['counts_by_literature_status']}")
    if report["exact_duplicate_groups"]:
        print(f"Exact duplicate groups: {report['exact_duplicate_groups']}")
    for item in report["warnings"]:
        print(f"WARNING {item['code']}: {item['candidate_ids']}")
    for issue in report["issues"]:
        line = f"line {issue['line']} " if issue["line"] is not None else ""
        print(f"ERROR {line}{issue['path']}: {issue['message']}", file=sys.stderr)


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    root = args.root.resolve()
    schema_path = (args.schema or SCHEMA_PATH).resolve()
    try:
        report = inspect_batch(root, args.batch_dir, schema_path)
    except (BatchError, OSError) as error:
        print(error, file=sys.stderr)
        return 2

    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print_text_report(report)
    return 0 if report["valid"] else 1


if __name__ == "__main__":
    raise SystemExit(main())