from __future__ import annotations

import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[2]
VALIDATOR = ROOT / ".github" / "prompts" / "theory_discovery.py"


class TheoryDiscoveryTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary_directory = tempfile.TemporaryDirectory()
        self.discovery_dir = Path(self.temporary_directory.name) / "discovery"
        self.discovery_dir.mkdir()
        for filename in ("discovery-plan.md", "final-report.md"):
            (self.discovery_dir / filename).write_text("# record\n", encoding="utf-8")

    def tearDown(self) -> None:
        self.temporary_directory.cleanup()

    def candidate(self, candidate_id: str = "theory-1") -> dict[str, object]:
        return {
            "candidate_id": candidate_id,
            "statement": "A property holds for every object in the stated class.",
            "definitions": ["The class is defined by the research question."],
            "assumptions": ["The object is regular."],
            "rationale": "It explains the observed boundary case.",
            "predictions": ["The minimal case satisfies the property."],
            "proof_obligations": ["Derive the property from the assumptions."],
            "counterexample_search": ["Enumerate all objects of size one."],
            "next_test": "Run the finite size-one enumeration.",
            "evidence_status": "open",
        }

    def run_validator(self, records: list[dict[str, object]]) -> subprocess.CompletedProcess[str]:
        contents = "\n".join(json.dumps(record) for record in records) + "\n"
        (self.discovery_dir / "theory-candidates.jsonl").write_text(contents, encoding="utf-8")
        return subprocess.run(
            [sys.executable, str(VALIDATOR), str(self.discovery_dir)],
            capture_output=True,
            text=True,
            check=False,
        )

    def test_valid_discovery_is_accepted(self) -> None:
        result = self.run_validator([self.candidate()])
        self.assertEqual(result.returncode, 0)

    def test_duplicate_ids_are_rejected(self) -> None:
        result = self.run_validator([self.candidate(), self.candidate()])
        self.assertEqual(result.returncode, 1)
        self.assertIn("duplicate candidate_id", result.stderr)

    def test_missing_report_is_rejected(self) -> None:
        (self.discovery_dir / "final-report.md").unlink()
        result = self.run_validator([self.candidate()])
        self.assertEqual(result.returncode, 1)
        self.assertIn("missing final-report.md", result.stderr)


if __name__ == "__main__":
    unittest.main()