# 仮説候補カード

> このカードは検討中の候補を整理する記録であり、それ自体は証明・新規性の確認・台帳への採用を意味しない。生成候補から詳査対象として選ばれた後に記入する。

## 識別情報

- Candidate ID:
- Work status: `selected` | `parked` | `rejected` | other
- Evidence status: `not assessed` | `open` | `proved/agent` | `proved/literature` | `proved/owner-checked` | `verified-computationally` | `refuted` | `disputed` | other
- Date:
- Agent:
- Source batch:
- Seed references:
- Transformation family:

`Work status` は作業の進み具合、`Evidence status` は主張に対する証拠状態を表す。証拠がまだ評価されていない場合は `not assessed` とする。`open` は、明確な主張を未解決の問題として扱う場合に限る。証拠ラベルの意味は `AGENTS.md` に従う。

## 候補主張

### Statement

対象、量化範囲、結論を明記する。定義や範囲が決まっていない部分は、補って断定せず未解決事項として記す。

### Scope and conventions

- 対象となる数学的・物理的・統計的設定:
- 記法、符号、座標、単位、規約:
- 主張が適用される範囲と、適用を主張しない範囲:

### Definitions and assumptions

- Definitions:
- Assumptions and regularity conditions:
- Boundary, limiting, or degeneracy conditions:
- Unresolved terms or choices:

## 動機と根拠

候補を調べる理由を簡潔に記す。既存の定義、主張、議論、文献、計算との関係を分けて示し、未確認の主張を既知の事実として扱わない。

- Motivation:
- Related ledger claims, notes, and sources:
- Transformation from the seed:
- Apparent overlap or conflict to check:

## 予測と帰結

候補が正しければ導かれる補題、構成、観測可能な結果を列挙する。候補そのものを言い換えただけの項目は帰結として数えない。

- Prediction or consequence 1:
- Prediction or consequence 2:
- Conditions needed for each consequence:

## 証明・検証義務

候補を支持するために必要な論証と、主張のどの部分が未確認かを記す。文献、形式証明、記号計算、数値計算は、得られる証拠の範囲を明示する。

- Proof obligations:
- Required lemmas or constructions:
- Required literature checks:
- Required formal or symbolic checks:
- Required computational checks and exact scope:
- What would constitute a proof, and what would not:

## 最初の反証テスト

| Test | Method | Exact scope | Failure condition | Result / evidence reference |
|---|---|---|---|---|
| 1 | | | | Not run |

テスト結果は `not run`, `supports within scope`, `refutes within scope`, `inconclusive` などで記録する。有限計算の成功を一般証明へ拡張しない。

## 既知の障害・反例候補

- Obstacle or candidate counterexample:
- Relevant source or artifact:
- Why it does or does not settle the candidate:

矛盾する既知主張を見つけても、自動的に候補を削除しない。反例候補か、仮定や規約の不一致かを確認する。

## 文献状況

- Search scope and date:
- Sources checked, with bibliographic identity and locator:
- Matches, differences in assumptions, or unresolved citation issues:
- Novelty assessment: `not assessed` | `possible overlap` | `known overlap` | `no match found in stated search`

文献検索で一致を見つけなかったことは新規性の証明ではない。`proved/literature` は、正確な主張・仮定・範囲・規約を特定資料と照合した場合に限る。

## 計算記録

- Question and exact computed scope:
- Program, configuration, and exact command:
- Backend, package versions, arithmetic domain, and conventions:
- Seed or nondeterminism details:
- Output, certificate, verifier, or result-manifest reference:
- What the computation establishes and does not establish:

耐久的な計算証拠は `COMPUTATIONS.md` と該当する計算記録テンプレートに従う。計算を行っていない場合、この節は `Not run` とする。

## 現在の評価と次の判断

- Current assessment and evidence status:
- Remaining ambiguity or blocker:
- Recommended next discriminating step:
- Owner decision, if any:

このカードから `LEDGER.md`、durable claim、論文へ自動反映しない。canonical な記録への昇格や公開には `AGENTS.md` の権限・証拠規則を適用する。

## Canonical implications

この節は、実際に canonical state を変更する証拠があり、その変更が別途認められた場合にだけ使う。それ以外は節ごと削除する。