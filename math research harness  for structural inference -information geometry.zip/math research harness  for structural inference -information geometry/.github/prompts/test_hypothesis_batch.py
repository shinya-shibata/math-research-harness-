from __future__ import annotations

import contextlib
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[2]
LITERATURE_PROVIDERS = [
    "arxiv",
    "springer",
    "siam",
]
sys.path.insert(0, str(ROOT / ".github" / "prompts"))

import hypothesis_batch


class HypothesisBatchTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary_directory = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary_directory.name)
        self.batch_dir = self.root / "research-scratch" / "test-thread" / "session-1"
        self.batch_dir.mkdir(parents=True)
        self.source_file = self.root / "threads" / "test-thread" / "LEDGER.md"
        self.source_file.parent.mkdir(parents=True)
        self.source_file.write_text("# Test ledger\n", encoding="utf-8")
        self.candidates_path = self.batch_dir / "candidates.jsonl"
        self.manifest_path = self.batch_dir / "batch-manifest.md"
        self.manifest_path.write_text("# Test batch\n", encoding="utf-8")

    def tearDown(self) -> None:
        self.temporary_directory.cleanup()

    def candidate(self, candidate_id: str = "candidate-1") -> dict[str, object]:
        return {
            "candidate_id": candidate_id,
            "seed_refs": [{"path": "threads/test-thread/LEDGER.md", "label": "Open item"}],
            "transformation": {
                "family": "special_case",
                "description": "Restrict to a minimal case.",
            },
            "statement_draft": "For every object in the specified class, property P holds.",
            "definitions_and_assumptions": {
                "definitions": ["Property P is defined in the seed."],
                "assumptions": ["The object is regular."],
            },
            "motivation": "Test the boundary of the seed claim.",
            "predictions": ["The minimal case satisfies P."],
            "first_test": {
                "description": "Check the smallest instance.",
                "method": "finite_search",
                "scope": "All instances of size one.",
                "failure_condition": "A size-one instance violates P.",
            },
            "known_obstacles": [],
            "work_status": "generated",
            "evidence_status": None,
            "literature_review": {
                "status": "complete",
                "search_date": "2026-09-29",
                "provider_searches": [
                    {
                        "provider": provider,
                        "status": "searched",
                        "queries": [
                            "property P exact phrase",
                            "property P alternate terminology",
                            "property P counterexample or failure",
                        ],
                        "local_reference_queries": [],
                        "results_summary": "No exact theorem match among inspected results.",
                    }
                    for provider in LITERATURE_PROVIDERS
                ],
                "local_reference_seeds": [],
                "sources_checked": [],
                "novelty_assessment": "no_match_found_in_stated_search",
            },
        }

    def write_candidates(self, candidates: list[dict[str, object]]) -> None:
        contents = "\n".join(json.dumps(item) for item in candidates) + "\n"
        self.candidates_path.write_text(contents, encoding="utf-8")

    def run_batch(self, *arguments: str) -> tuple[int, str, str]:
        stdout, stderr = io.StringIO(), io.StringIO()
        argv = ["--root", str(self.root), str(self.batch_dir), *arguments]
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            code = hypothesis_batch.main(argv)
        return code, stdout.getvalue(), stderr.getvalue()

    def test_valid_batch_reports_counts_and_reads_manifest_beside_jsonl(self) -> None:
        self.write_candidates([self.candidate()])

        code, output, error = self.run_batch("--json")

        self.assertEqual((code, error), (0, ""))
        self.assertIn('"valid": true', output)
        self.assertIn('"special_case": 1', output)
        self.assertIn("batch-manifest.md", output)

    def test_invalid_json_line_is_reported(self) -> None:
        self.candidates_path.write_text("{not json}\n", encoding="utf-8")

        code, output, error = self.run_batch("--json")

        self.assertEqual(code, 1)
        self.assertIn('"invalid_json"', output)
        self.assertIn('"line": 1', output)

    def test_schema_violation_is_reported(self) -> None:
        candidate = self.candidate()
        candidate["work_status"] = "generated"
        candidate["evidence_status"] = "proved/agent"
        self.write_candidates([candidate])

        code, output, _ = self.run_batch("--json")

        self.assertEqual(code, 1)
        self.assertIn('"schema_validation"', output)

    def test_missing_external_provider_is_reported(self) -> None:
        candidate = self.candidate()
        candidate["literature_review"]["provider_searches"].pop()
        self.write_candidates([candidate])

        code, output, _ = self.run_batch("--json")

        self.assertEqual(code, 1)
        self.assertIn('"literature_provider_coverage"', output)

    def test_missing_local_reference_seed_file_is_reported(self) -> None:
        candidate = self.candidate()
        candidate["literature_review"]["local_reference_seeds"] = [{
            "local_path": "references/missing.md",
            "section": "References",
            "bibliographic_reference": "A. Author, Example title (2020).",
            "query_terms": ["Example title", "Author Example title 2020"],
        }]
        self.write_candidates([candidate])

        code, _, error = self.run_batch()

        self.assertEqual(code, 1)
        self.assertIn("referenced file does not exist", error)

    def test_local_reference_seeds_must_be_searched_at_each_provider(self) -> None:
        candidate = self.candidate()
        local_query = "A. Author Example theorem 2020"
        candidate["literature_review"]["local_reference_seeds"] = [{
            "local_path": "threads/test-thread/LEDGER.md",
            "section": "References",
            "bibliographic_reference": "A. Author, Example theorem (2020).",
            "query_terms": [local_query],
        }]
        for provider_search in candidate["literature_review"]["provider_searches"]:
            provider_search["queries"].append(local_query)
            provider_search["local_reference_queries"] = [local_query]
        self.write_candidates([candidate])

        code, output, _ = self.run_batch("--json")

        self.assertEqual(code, 0)
        self.assertIn('"valid": true', output)

        candidate["literature_review"]["provider_searches"][-1]["local_reference_queries"] = []
        self.write_candidates([candidate])
        code, output, _ = self.run_batch("--json")

        self.assertEqual(code, 1)
        self.assertIn('"local_reference_seed_unsearched"', output)

    def test_provider_search_requires_three_distinct_queries(self) -> None:
        candidate = self.candidate()
        candidate["literature_review"]["provider_searches"][0]["queries"] = [
            "property P exact phrase"
        ]
        self.write_candidates([candidate])

        code, output, _ = self.run_batch("--json")

        self.assertEqual(code, 1)
        self.assertIn('"schema_validation"', output)

    def test_unavailable_provider_cannot_be_marked_complete(self) -> None:
        candidate = self.candidate()
        candidate["literature_review"]["provider_searches"][0] = {
            "provider": "arxiv",
            "status": "unavailable",
            "queries": [
                "property P exact phrase",
                "property P alternate terminology",
                "property P counterexample or failure",
            ],
            "local_reference_queries": [],
            "results_summary": "Search endpoint unavailable.",
            "failure_reason": "Network access was blocked.",
        }
        self.write_candidates([candidate])

        code, output, _ = self.run_batch("--json")

        self.assertEqual(code, 1)
        self.assertIn('"incomplete_literature_search"', output)

    def test_duplicate_ids_are_errors(self) -> None:
        self.write_candidates([self.candidate(), self.candidate()])

        code, output, _ = self.run_batch("--json")

        self.assertEqual(code, 1)
        self.assertIn('"duplicate_candidate_id"', output)

    def test_missing_reference_is_reported(self) -> None:
        candidate = self.candidate()
        candidate["seed_refs"] = [{"path": "threads/missing/LEDGER.md", "label": "Missing"}]
        self.write_candidates([candidate])

        code, _, error = self.run_batch()

        self.assertEqual(code, 1)
        self.assertIn("referenced file does not exist", error)

    def test_exact_duplicates_are_warned_but_not_removed(self) -> None:
        first = self.candidate("candidate-1")
        second = self.candidate("candidate-2")
        self.write_candidates([first, second])

        code, output, _ = self.run_batch("--json")
        report = json.loads(output)

        self.assertEqual(code, 0)
        self.assertEqual(report["schema_valid_candidates"], 2)
        self.assertEqual(report["exact_duplicate_groups"], [["candidate-1", "candidate-2"]])

    def test_batch_outside_requested_layout_is_rejected(self) -> None:
        other_directory = self.root / "elsewhere"
        other_directory.mkdir()

        stdout, stderr = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            code = hypothesis_batch.main(["--root", str(self.root), str(other_directory)])

        self.assertEqual(code, 2)
        self.assertIn("research-scratch/<thread>/<session>", stderr.getvalue())

    def test_missing_manifest_is_a_batch_error(self) -> None:
        self.manifest_path.unlink()
        self.write_candidates([self.candidate()])

        code, _, error = self.run_batch()

        self.assertEqual(code, 1)
        self.assertIn("batch manifest is missing", error)


if __name__ == "__main__":
    unittest.main()