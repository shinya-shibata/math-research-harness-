"""Validate an owner-directed theory discovery candidate file."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from jsonschema import Draft202012Validator, SchemaError


SCHEMA_PATH = Path(__file__).resolve().with_name("THEORY-DISCOVERY.schema.json")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("discovery_dir", type=Path)
    parser.add_argument("--schema", type=Path, default=SCHEMA_PATH)
    return parser


def load_validator(schema_path: Path) -> Draft202012Validator:
    try:
        schema = json.loads(schema_path.read_text(encoding="utf-8"))
        Draft202012Validator.check_schema(schema)
    except (OSError, UnicodeError, json.JSONDecodeError, SchemaError) as error:
        raise ValueError(f"cannot load schema: {error}") from error
    return Draft202012Validator(schema)


def validate(discovery_dir: Path, schema_path: Path) -> list[str]:
    if not discovery_dir.is_dir():
        return [f"discovery directory does not exist: {discovery_dir}"]
    candidates_path = discovery_dir / "theory-candidates.jsonl"
    if not candidates_path.is_file():
        return ["missing theory-candidates.jsonl"]

    validator = load_validator(schema_path)
    errors: list[str] = []
    seen_ids: set[str] = set()
    for line_number, line in enumerate(candidates_path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            errors.append(f"line {line_number}: blank lines are not allowed")
            continue
        try:
            record = json.loads(line)
        except json.JSONDecodeError as error:
            errors.append(f"line {line_number}: invalid JSON: {error.msg}")
            continue
        for error in validator.iter_errors(record):
            path = "/".join(str(part) for part in error.absolute_path) or "$"
            errors.append(f"line {line_number} {path}: {error.message}")
        if isinstance(record, dict) and isinstance(record.get("candidate_id"), str):
            candidate_id = record["candidate_id"]
            if candidate_id in seen_ids:
                errors.append(f"line {line_number}: duplicate candidate_id: {candidate_id}")
            seen_ids.add(candidate_id)
    for required_file in ("discovery-plan.md", "final-report.md"):
        if not (discovery_dir / required_file).is_file():
            errors.append(f"missing {required_file}")
    return errors


def main(argv: list[str] | None = None) -> int:
    arguments = build_parser().parse_args(argv)
    try:
        errors = validate(arguments.discovery_dir, arguments.schema)
    except ValueError as error:
        print(str(error), file=sys.stderr)
        return 2
    if errors:
        print("\n".join(errors), file=sys.stderr)
        return 1
    print("valid theory discovery: theory-candidates.jsonl")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())