# Local reference workspace

This directory is a local, ignored working area for source material and derived
text. Only this README is intended to be tracked. Do not edit source originals.

## Layout

- `items/arxiv/<versioned-id>/` and `items/{papers,books}/<slug>/` hold local
  items. Keep originals in `original/`, unpacked source in `source/`, and the
  item's `item.json` beside them.
- `external/<slug>.json` records an externally held source when a local text or
  TeX derivative is available. Keep derivatives under `derived/text/` and name
  their source in the asset record.
- `CATALOG.json` and `CATALOG.md` are generated. Do not edit them by hand.

## Record and catalog commands

Copy [`../templates/REFERENCE-ITEM.json`](../templates/REFERENCE-ITEM.json) to
an item's `item.json`, replace the example values, and ensure each listed local
asset exists. Paths are workspace-relative and use `/` separators.

From the workspace root, validate all records and regenerate both catalogs:

```powershell
uv sync
uv run python tools/reference_metadata.py
```

Check without writing:

```powershell
uv run python tools/reference_metadata.py --check
```

Validate a particular record while rebuilding the complete catalog:

```powershell
uv run python tools/reference_metadata.py --item references/items/papers/example/item.json
```

The metadata tool is offline. It reads item records and local paths, writes only
the two catalog files, and never edits an original, derivative, or `item.json`.
The catalog is an availability index, not evidence that a source was checked.

Search the catalog and explicitly listed TeX/text assets with
`tools/reference_lookup.py`. `--grep` never scans PDFs or unregistered files.