# Cross-thread steering

Use this file only for current owner directions that genuinely apply across
multiple research threads or for rare standing assignments.

Every mathematical session reads this file after `AGENTS.md` and before the
relevant thread ledger. This file holds current owner direction;
`PROJECT-FOUNDATIONS.md` holds the optional shared mathematical
conventions, read only when something actually calls for them.

There are no cross-thread directions in the fictional starter state.

Thread-specific targets, priorities, exclusions, and park/resume decisions
belong in the relevant `threads/<thread>/LEDGER.md`.
