from __future__ import annotations

import contextlib
import io
import json
import tempfile
import unittest
from pathlib import Path
import sys
from unittest.mock import patch


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))

import reference_lookup
import reference_metadata
import reference_search


class ReferenceToolTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary_directory = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary_directory.name)
        self.references = self.root / "references"
        self.local_dir = self.references / "items" / "papers" / "riemann-roch-example"
        (self.local_dir / "original").mkdir(parents=True)
        (self.local_dir / "source").mkdir()
        (self.references / "derived" / "text").mkdir(parents=True)
        (self.references / "external").mkdir()
        self.pdf = self.local_dir / "original" / "paper.pdf"
        self.pdf.write_bytes(b"placeholder binary source")
        self.tex = self.local_dir / "source" / "main.tex"
        self.tex.write_text("\\title{Riemann--Roch}\nA key theorem here.\n", encoding="utf-8")
        self.text = self.references / "derived" / "text" / "paper.txt"
        self.text.write_text("Extracted claim: Finitely generated.\n", encoding="utf-8")
        self.local_record = {
            "schema_version": 1,
            "slug": "riemann-roch-example",
            "kind": "local",
            "bibliographic_identity": {
                "title": "Riemann--Roch methods",
                "authors": ["Erdős, Pál", "Example, Ada"],
                "year": 2024,
                "identifiers": {"arxiv": "2401.01234v2", "doi": "10.1000/EXAMPLE"},
                "keywords": ["invariants", "geometry"],
                "abstract": "A test abstract.",
            },
            "assets": [
                {"path": self.relative(self.pdf), "role": "original", "source": None},
                {"path": self.relative(self.tex), "role": "tex", "source": self.relative(self.pdf)},
                {"path": self.relative(self.text), "role": "text", "source": self.relative(self.pdf)},
            ],
            "provenance": {"recorded_from": "test fixture"},
        }
        self.local_record_path = self.local_dir / "item.json"
        self.write_json(self.local_record_path, self.local_record)

    def tearDown(self) -> None:
        self.temporary_directory.cleanup()

    def relative(self, path: Path) -> str:
        return path.relative_to(self.root).as_posix()

    @staticmethod
    def write_json(path: Path, value: object) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    def run_metadata(self, *arguments: str) -> tuple[int, str, str]:
        stdout, stderr = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            code = reference_metadata.main(["--root", str(self.root), *arguments])
        return code, stdout.getvalue(), stderr.getvalue()

    def run_lookup(self, *arguments: str) -> tuple[int, str, str]:
        stdout, stderr = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            code = reference_lookup.main(["--root", str(self.root), *arguments])
        return code, stdout.getvalue(), stderr.getvalue()

    def test_catalog_generation_and_check_are_deterministic(self) -> None:
        code, _, error = self.run_metadata()
        self.assertEqual((code, error), (0, ""))
        catalog_path = self.references / "CATALOG.json"
        first_catalog = catalog_path.read_text(encoding="utf-8")
        code, _, error = self.run_metadata()
        self.assertEqual((code, error), (0, ""))
        self.assertEqual(catalog_path.read_text(encoding="utf-8"), first_catalog)
        code, _, error = self.run_metadata("--item", self.relative(self.local_record_path))
        self.assertEqual((code, error), (0, ""))
        code, _, error = self.run_metadata("--check")
        self.assertEqual((code, error), (0, ""))
        self.assertTrue((self.references / "CATALOG.md").is_file())

    def test_metadata_reports_stale_catalog_and_unsafe_paths(self) -> None:
        self.assertEqual(self.run_metadata()[0], 0)
        (self.references / "CATALOG.md").write_text("edited\n", encoding="utf-8")
        self.assertEqual(self.run_metadata("--check")[0], 1)
        self.local_record["assets"][0]["path"] = "references/items/../../outside.pdf"
        self.write_json(self.local_record_path, self.local_record)
        code, _, error = self.run_metadata()
        self.assertEqual(code, 2)
        self.assertIn("traverse", error)

    def test_check_does_not_create_missing_workspace(self) -> None:
        empty_root = Path(self.temporary_directory.name) / "missing-workspace"
        stdout, stderr = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            code = reference_metadata.main(["--root", str(empty_root), "--check"])
        self.assertNotEqual(code, 0)
        self.assertFalse((empty_root / "references").exists())

    def test_reference_template_is_valid_json_with_required_fields(self) -> None:
        template_path = ROOT / "templates" / "REFERENCE-ITEM.json"
        template = json.loads(template_path.read_text(encoding="utf-8"))
        self.assertEqual(template["schema_version"], 1)
        self.assertIn("bibliographic_identity", template)
        self.assertIn("assets", template)
        self.assertIn("provenance", template)

    def test_lookup_matches_accents_dashes_year_and_identifiers(self) -> None:
        self.assertEqual(self.run_metadata()[0], 0)
        code, output, error = self.run_lookup("erdos", "riemann-roch", "--year", "2020-2025")
        self.assertEqual((code, error), (0, ""))
        self.assertIn("Riemann--Roch methods", output)
        code, output, error = self.run_lookup("--id", "arxiv:2401.01234")
        self.assertEqual((code, error), (0, ""))
        self.assertIn("2401.01234v2", output)

    def test_grep_reports_tex_text_locations_but_skips_pdf(self) -> None:
        self.assertEqual(self.run_metadata()[0], 0)
        code, output, error = self.run_lookup("--grep", "finitely generated", "--json")
        self.assertEqual((code, error), (0, ""))
        results = json.loads(output)
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["path"], self.relative(self.text))
        self.assertEqual(results[0]["line"], 1)
        code, output, error = self.run_lookup("--grep", "binary source", "--json")
        self.assertEqual((code, error), (0, ""))
        self.assertEqual(json.loads(output), [])

    def test_external_record_is_searchable_and_kind_filter_works(self) -> None:
        external_text = self.references / "derived" / "text" / "external.txt"
        external_text.write_text("An external theorem.\n", encoding="utf-8")
        external_record = {
            "schema_version": 1,
            "slug": "external-theorem",
            "kind": "external",
            "bibliographic_identity": {
                "title": "External Theorem",
                "authors": ["Reader, Robin"],
                "year": None,
                "identifiers": {"arxiv": None, "doi": None},
                "keywords": ["theorem"],
                "abstract": None,
            },
            "assets": [{
                "path": self.relative(external_text),
                "role": "text",
                "source": "Externally held publisher copy, version checked by the owner",
            }],
            "provenance": {"recorded_from": "test fixture"},
        }
        self.write_json(self.references / "external" / "external-theorem.json", external_record)
        self.assertEqual(self.run_metadata()[0], 0)
        self.assertEqual(self.run_lookup("--kind", "external", "--title", "external theorem")[0], 0)
        code, output, error = self.run_lookup("--kind", "local", "--title", "external theorem")
        self.assertEqual((code, error), (0, ""))
        self.assertEqual(output.strip(), "No matches.")


class ReferenceSearchTests(unittest.TestCase):
    def test_builds_native_search_urls_for_all_required_providers(self) -> None:
        targets = reference_search.build_search_targets(["alpha connection", "counterexample"])
        self.assertEqual(len(targets), 6)
        self.assertEqual(
            {target["provider"] for target in targets},
            {"arxiv", "springer", "siam"},
        )
        self.assertTrue(all("alpha+connection" in targets[index]["url"]
                            for index in range(0, 6, 2)))

    def test_provider_filter_and_json_output(self) -> None:
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            code = reference_search.main([
                "--query", "curved exponential family", "--provider", "arxiv", "--json",
            ])
        self.assertEqual(code, 0)
        results = json.loads(output.getvalue())
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["provider"], "arxiv")
        self.assertIn("searchtype=all", results[0]["url"])

    def test_open_flag_opens_each_query_target(self) -> None:
        with patch.object(reference_search.webbrowser, "open_new_tab", return_value=True) as open_tab:
            code = reference_search.main([
                "--query", "first", "--query", "second", "--provider", "siam", "--open", "--json",
            ])
        self.assertEqual(code, 0)
        self.assertEqual(open_tab.call_count, 2)

    def test_empty_queries_are_rejected(self) -> None:
        with self.assertRaises(ValueError):
            reference_search.build_search_targets([" "])


if __name__ == "__main__":
    unittest.main()