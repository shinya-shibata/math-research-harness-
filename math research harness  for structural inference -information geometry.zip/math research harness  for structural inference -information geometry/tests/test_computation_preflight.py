from __future__ import annotations

import contextlib
import io
from pathlib import Path
import sys
import unittest


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))

import computation_preflight


class ComputationPreflightTests(unittest.TestCase):
    def test_backends_pass_smoke_checks(self) -> None:
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            result = computation_preflight.main()

        self.assertEqual(result, 0)
        self.assertIn("PASS SymPy exact differentiation", output.getvalue())
        self.assertIn("PASS NumPy linear solve", output.getvalue())
        self.assertIn("PASS SciPy adaptive quadrature", output.getvalue())


if __name__ == "__main__":
    unittest.main()