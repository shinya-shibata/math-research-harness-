# OP-3: model-specific resolution for nonzero curvature / holonomy

Date: 2026-10-06
Agent: GitHub Copilot in VS Code
Scope: bounded resolution for the concrete approximate-ancillary ambient in the FM-34 bridge.
Status: resolved in the narrow model-specific sense; the general theorem remains open.

## Resolution statement

For the explicit codimension-two logistic-tilt ambient constructed in
[20261004-fraser-fm34-bridge/integrable-structural-nonflat-normal.md](./20261004-fraser-fm34-bridge/integrable-structural-nonflat-normal.md),
the structural location-scale distribution is Frobenius-integrable while the
induced Fisher-normal Levi-Civita connection has nonzero curvature.

In precise form, the sample-space structural fields satisfy

`[v_mu, v_tau] = v_mu`,

so the rank-two distribution `span{v_mu, v_tau}` is involutive. Yet the
normal connection on the codimension-two normal bundle obeys

`R_perp,mu,tau^(0) = exp(-tau) * [[0, -28/45], [9/4, 0]] != 0`.

Therefore the implication

`F = 0  =>  R_perp^(alpha) = 0`

is false in this explicit ambient, at least for the Levi-Civita connection
`alpha = 0`.

## What this resolves

This resolves the narrow version of OP-3 as a concrete counterexample:

- exact structural integrability can coexist with nonzero normal curvature;
- the obstruction is not a consequence of the structural equation alone;
- the choice of ambient family, metric, and normal connection matters.

This is not a general theorem about all approximate ancillaries or all Fraser
structural models. It does not establish a canonical ancillary-holonomy
correspondence, and it does not identify a universal relationship between the
exact ancillary law and the normal connection.

## What remains open

The remaining issues are still open in the general sense:

1. the relation between a chosen approximate ancillary and an intrinsic normal
   bundle;
2. the global holonomy period beyond the local curvature value;
3. the exact criteria under which local curvature controls full holonomy;
4. a canonical selection rule for a gauge-independent approximate-ancillary
   score bundle.

One must separate local curvature from full holonomy. The exact statement is
only that the chosen ambient normal connection is nonflat in the neighborhood;
it is not a statement that the full holonomy group is nontrivial for every loop,
nor that the approximate ancillary itself selects this connection canonically.

## Evidence

The exact symbolic computation is reproduced with

`uv run python research-scratch/fraser_structural_geometry/20261004-fraser-fm34-bridge/codim2_curvature.py`

and the script reports:

- `h1_mean_zero = true`
- `h2_mean_zero = true`
- `normal_scores_orthogonal = true`
- `positive_normal_fisher = true`
- `lc_curvature_nonzero = true`

This confirms the displayed nonzero curvature matrix and the involutivity of the
structural distribution inside the explicit model.

## Conclusion for OP-3

OP-3 is resolved in the precise technical sense that a nonzero-curvature,
approximate-ancillary selected ambient exists in a concrete model and can be
verified exactly. The general theoretical bridge from approximate ancillarity to
intrinsic normal holonomy remains open.
