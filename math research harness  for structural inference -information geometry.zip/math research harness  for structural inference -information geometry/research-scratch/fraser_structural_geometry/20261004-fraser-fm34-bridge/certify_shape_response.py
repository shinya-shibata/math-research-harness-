"""Monte Carlo confidence bound for the logistic ancillary shape response."""

from __future__ import annotations

import json
import math

import numpy as np


def main() -> None:
    sample_size = 1_200_000
    chunk_size = 100_000
    seed = 20261004
    rng = np.random.Generator(np.random.PCG64(seed))
    total = 0.0
    total_sq = 0.0
    count = 0
    dimension = 4

    while count < sample_size:
        size = min(chunk_size, sample_size - count)
        y = 2.0 * rng.random((size, dimension)) - 1.0
        u = 2.0 * np.arctanh(y)
        centered = u - np.mean(u, axis=1, keepdims=True)
        radius = np.linalg.norm(centered, axis=1, keepdims=True)
        ancillary = centered / radius
        statistic = np.sum(ancillary**3, axis=1)
        shape_score = np.sum(y**3 - 0.6 * y, axis=1)
        values = statistic * shape_score
        total += float(np.sum(values))
        total_sq += float(np.dot(values, values))
        count += size

    estimate = total / sample_size
    delta = 0.01
    range_width = 3.2
    half_width = range_width * math.sqrt(
        math.log(2.0 / delta) / (2.0 * sample_size)
    )
    required_for_001 = math.ceil(
        range_width**2 * math.log(2.0 / delta) / (2.0 * 0.01**2)
    )
    sample_variance = (total_sq - sample_size * estimate**2) / (
        sample_size - 1
    )
    print(
        json.dumps(
            {
                "dimension_n": dimension,
                "sample_size": sample_size,
                "rng": "NumPy PCG64",
                "seed": seed,
                "estimate": estimate,
                "sample_sd": math.sqrt(sample_variance),
                "confidence_level": 0.99,
                "bounded_integrand_range": [-1.6, 1.6],
                "hoeffding_half_width": half_width,
                "hoeffding_interval": [
                    estimate - half_width,
                    estimate + half_width,
                ],
                "samples_required_for_half_width_0_01": required_for_001,
                "guarantee_assumption": (
                    "Hoeffding guarantee for independent draws from the exact "
                    "Uniform((-1,1)^4) law; applying it to a seeded PRNG is "
                    "the standard pseudorandom-sampling assumption, not a "
                    "deterministic quadrature certificate."
                ),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
