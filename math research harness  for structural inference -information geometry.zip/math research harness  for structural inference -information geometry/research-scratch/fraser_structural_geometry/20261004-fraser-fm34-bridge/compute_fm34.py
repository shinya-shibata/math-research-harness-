"""Bounded symbolic and randomized quasi-Monte Carlo check for FM-34."""

from __future__ import annotations

import json

import numpy as np
import sympy as sp
from scipy.stats import qmc


def exact_coefficients() -> dict[str, str]:
    y = sp.symbols("y", real=True)
    alpha = sp.symbols("alpha", real=True)
    h = y**3 - sp.Rational(3, 5) * y
    h_prime = sp.diff(h, y)
    q = 2 * y * sp.atanh(y) - 1

    def expectation(expr: sp.Expr) -> sp.Expr:
        return sp.simplify(sp.integrate(expr, (y, -1, 1)) / 2)

    g_shape = expectation(h**2)
    cubic_mixed = expectation(y * q * h)
    metric_shape_derivative = expectation(
        y * q * h
        - sp.Rational(1, 2) * h_prime * (1 - y**2) * q
        - y * h_prime * sp.atanh(y) * (1 - y**2)
    )
    normal_scale_cubic = expectation(q * h**2)
    h_alpha = sp.simplify(
        -(metric_shape_derivative + alpha * cubic_mixed) / (2 * g_shape)
    )
    return {
        "g_location_per_observation_without_scale_factor": str(
            expectation(y**2)
        ),
        "g_scale_per_observation": str((sp.pi**2 + 3) / 9),
        "g_shape_per_observation": str(g_shape),
        "T_mu_tau_shape_per_observation_at_tau0": str(cubic_mixed),
        "d_g_mu_tau_d_shape_per_observation_at_tau0": str(
            metric_shape_derivative
        ),
        "T_tau_shape_shape_per_observation": str(normal_scale_cubic),
        "T_tau_shape_shape_over_g_shape": str(
            sp.simplify(normal_scale_cubic / g_shape)
        ),
        "H_alpha_mu_tau_coordinate_coefficient_at_tau0": str(h_alpha),
    }


def ancillary_sensitivity(
    power: int, replicates: int, dimension: int, seed_start: int
) -> dict[str, object]:
    estimates: list[float] = []
    for seed in range(seed_start, seed_start + replicates):
        points = qmc.Sobol(d=dimension, scramble=True, seed=seed).random_base2(
            power
        )
        y = 2 * points - 1
        u = 2 * np.arctanh(y)
        centered = u - np.mean(u, axis=1, keepdims=True)
        ancillary = centered / np.linalg.norm(centered, axis=1, keepdims=True)
        shape_score = np.sum(y**3 - 0.6 * y, axis=1)
        statistic = np.sum(ancillary**3, axis=1)
        estimates.append(float(np.mean(statistic * shape_score)))

    values = np.asarray(estimates)
    return {
        "power": power,
        "replicates": replicates,
        "sample_size_per_replicate": 2**power,
        "dimension": dimension,
        "seed_start": seed_start,
        "replicate_means": estimates,
        "mean": float(np.mean(values)),
        "replicate_sd": float(np.std(values, ddof=1)),
        "replicate_se": float(np.std(values, ddof=1) / np.sqrt(replicates)),
    }


def main() -> None:
    print(
        json.dumps(
            {
                "exact_coefficients": exact_coefficients(),
                "ancillary_shape_sensitivity": [
                    ancillary_sensitivity(14, 8, 4, 20261004),
                    ancillary_sensitivity(16, 8, 4, 20261004),
                ],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
