"""Exact codimension-two logistic-tilt normal-curvature calculation."""

from __future__ import annotations

import json

import sympy as sp


def calculate() -> dict[str, object]:
    y, alpha = sp.symbols("y alpha", real=True)
    q = 2 * y * sp.atanh(y) - 1
    h1 = y**3 - sp.Rational(3, 5) * y
    h2 = y**4 - sp.Rational(14, 15) * y**2 + sp.Rational(1, 9)
    scores = (h1, h2)

    def expectation(expr: sp.Expr) -> sp.Expr:
        return sp.simplify(sp.integrate(sp.expand(expr), (y, -1, 1)) / 2)

    fisher_normal = sp.Matrix(
        [[expectation(scores[i] * scores[j]) for j in range(2)] for i in range(2)]
    )
    # These are lower-index connection coefficients in the normal frame.
    omega_mu_lower = sp.Matrix(
        [
            [
                expectation(
                    -sp.Rational(1, 2)
                    * (1 - y**2)
                    * sp.diff(scores[j], y)
                    * scores[i]
                )
                + (1 - alpha)
                / 2
                * expectation(y * scores[j] * scores[i])
                for j in range(2)
            ]
            for i in range(2)
        ]
    )
    omega_tau_lower = sp.Matrix(
        [
            [
                expectation(
                    -(1 - y**2)
                    * sp.atanh(y)
                    * sp.diff(scores[j], y)
                    * scores[i]
                )
                + (1 - alpha)
                / 2
                * expectation(q * scores[j] * scores[i])
                for j in range(2)
            ]
            for i in range(2)
        ]
    )
    omega_mu = sp.simplify(fisher_normal.inv() * omega_mu_lower)
    omega_tau = sp.simplify(fisher_normal.inv() * omega_tau_lower)

    # omega_mu carries a factor exp(-tau), while omega_tau is constant on S.
    curvature_coefficient = sp.simplify(
        omega_mu + omega_mu * omega_tau - omega_tau * omega_mu
    )
    omega_mu_lc = sp.simplify(omega_mu.subs(alpha, 0))
    omega_tau_lc = sp.simplify(omega_tau.subs(alpha, 0))
    curvature_lc = sp.simplify(curvature_coefficient.subs(alpha, 0))

    checks = {
        "h1_mean_zero": expectation(h1) == 0,
        "h2_mean_zero": expectation(h2) == 0,
        "h1_location_orthogonal": expectation(y * h1) == 0,
        "h2_location_orthogonal": expectation(y * h2) == 0,
        "h1_scale_orthogonal": expectation(q * h1) == 0,
        "h2_scale_orthogonal": expectation(q * h2) == 0,
        "normal_scores_orthogonal": expectation(h1 * h2) == 0,
        "positive_normal_fisher": bool(fisher_normal.det() > 0),
        "lc_curvature_nonzero": curvature_lc != sp.zeros(2),
    }
    if not all(checks.values()):
        raise ArithmeticError(f"Exact verification failed: {checks}")

    return {
        "h1": str(h1),
        "h2": str(h2),
        "fisher_normal": str(fisher_normal),
        "omega_mu_coefficient_after_factoring_exp_minus_tau": str(omega_mu),
        "omega_tau": str(omega_tau),
        "curvature_mu_tau_coefficient_after_factoring_exp_minus_tau": str(
            curvature_coefficient
        ),
        "levi_civita_omega_mu_coefficient": str(omega_mu_lc),
        "levi_civita_omega_tau": str(omega_tau_lc),
        "levi_civita_curvature_mu_tau_coefficient": str(curvature_lc),
        "checks": checks,
    }


if __name__ == "__main__":
    print(json.dumps(calculate(), indent=2))
