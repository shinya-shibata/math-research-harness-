# Integrable Structural Directions with Nonflat Fisher-Normal Transport

Date: 2026-10-04 15:42:25 +09:00  
Agent: GitHub Copilot in VS Code; underlying model version not exposed

## Result

An explicit regular four-parameter statistical ambient family contains the
two-parameter location-scale logistic model as a submodel. Its sample-space
location-scale structural distribution is Frobenius-integrable, but the
Levi-Civita normal connection of this submodel has nonzero curvature. Thus,
for this specified ambient geometry, structural integrability does not imply
flat normal transport.

The statement is `proved/agent` from the displayed formulas, with exact
symbolic moment checks recorded below. It is not a literature-priority claim,
does not establish any universal ancillary/curvature theorem, and does not
promote canonical thread state.

## Ambient family and regularity

For one observation set

`u=(x-mu)*exp(-tau)`,
`y=tanh(u/2)`,
`f(u)=1/(4*cosh(u/2)^2)`,

and define bounded shape functions

`h1(y)=y^3-3y/5`,
`h2(y)=y^4-14y^2/15+1/9`.

Let `C(k1,k2)=log integral f(u)*exp(k1*h1(y)+k2*h2(y)) du`.
For `n` independent observations use the product of

`p(x;mu,tau,k1,k2)
 = exp(-tau)*f(u)*exp(k1*h1(y)+k2*h2(y)-C(k1,k2))`.

Since both shape functions are bounded, `C` is finite and smooth for all
finite `(k1,k2)`. The location-scale logistic model is the surface
`S={(mu,tau,k1,k2): k1=k2=0}`.

At `S`, `Y=tanh(U/2)` is uniform on `(-1,1)` and the one-observation score
functions are

`s_mu=exp(-tau)*Y`,
`s_tau=2Y*atanh(Y)-1`,
`s_1=h1(Y)`,
`s_2=h2(Y)`.

Exact moments give

`E[h1]=E[h2]=0`,
`E[Y h1]=E[Y h2]=0`,
`E[q h1]=E[q h2]=0`, where `q=2Y*atanh(Y)-1`,
`E[h1*h2]=0`,
`E[h1^2]=4/175`,
`E[h2^2]=64/10125`.

The tangent Fisher block for `(mu,tau)` is positive definite and orthogonal
to the shape block. The full four-dimensional Fisher metric is positive
definite at every point of `S`, so `S` is a regular codimension-two
immersed submodel locally.

## Structural distribution is involutive

For the sample `x=(x_1,...,x_n)`, the location-scale structural equation is
`x_i=mu+exp(tau)u_i`. Its sample-space sensitivity fields are

`v_mu(x)=(1,...,1)`,
`v_tau(x)=(x_1-mu,...,x_n-mu)`.

Using the vector-field bracket
`[V,W]=DW[V]-DV[W]`, direct differentiation gives

`[v_mu,v_tau]=v_mu`.

Hence the rank-two distribution `span{v_mu,v_tau}` is involutive wherever
these fields are independent (the generic event for `n>=2` under the
continuous model). Its leaves are the location-scale group orbits. In the
usual Frobenius-residual notation,

`F_mu,tau=[v_mu,v_tau]-v_mu=0`.

## Exact normal connection and curvature

Along `S`, the normal coordinate frame `(partial_k1,partial_k2)` is
Fisher-orthogonal to the tangent space and has constant diagonal Gram matrix

`G_N=diag(4/175,64/10125)` per observation; the factor `n` cancels in the
connection coefficients.

For a regular parametric model with score functions `s_i`, the lowered
Levi-Civita connection coefficients in parameter coordinates satisfy

`Gamma^(0)_{ij,k}
 = E[(partial_i s_j)*s_k] + (1/2)E[s_i*s_j*s_k]`.

With the convention
`Gamma^(alpha)=Gamma^(0)-alpha*T^sharp/2`, replace `1/2` by
`(1-alpha)/2` in the cubic term. Applying this identity to the normal frame
and raising the normal index by `G_N` gives

`omega_mu^(alpha)=exp(-tau) * [[0,-4*alpha/45-28/45],
                               [9/4-9*alpha/28,0]]`,

`omega_tau^(alpha)=diag(-alpha/2,-alpha/7)`.

The matrices use the convention
`nabla_perp^(alpha) N_j = N_i*omega^i_j`. Since the first matrix is
`exp(-tau)` times a constant matrix and the second is constant, the curvature
matrix in the coordinate order `(mu,tau)` is

`R_perp,mu,tau^(alpha)
 = exp(-tau)*(M_mu+[M_mu,M_tau])`,

where `M_mu=exp(tau)*omega_mu^(alpha)` and
`M_tau=omega_tau^(alpha)`.

In particular, at `alpha=0` (the Levi-Civita connection),

`omega_mu^(0)=exp(-tau)*[[0,-28/45],[9/4,0]]`,
`omega_tau^(0)=0`,

and

`R_perp,mu,tau^(0)
 = exp(-tau)*[[0,-28/45],[9/4,0]] != 0`.

This is a concrete coexistence of `F=0` and nonzero normal curvature. It
refutes an implication from Frobenius integrability of these structural
directions to flatness of this chosen Fisher-normal connection. It does not
say that normal curvature is a property of the structural distribution
alone; the result depends on the explicit ambient family and metric.

## Verification

Run from repository root:

`uv run python research-scratch/fraser_structural_geometry/20261004-fraser-fm34-bridge/codim2_curvature.py`

The script verifies exact score-centering, tangent-normal orthogonality,
normal-score orthogonality, positive normal Fisher determinant, and nonzero
Levi-Civita curvature using SymPy 1.14.0 under Python 3.14.6. The project
preflight `uv run python tools/computation_preflight.py` passed. All stated
shape moments and connection matrices are exact rational expressions; no
floating-point search is involved in this curvature result.

## Remaining issue: ancillary shape response

The separate `n=4` quasi-Monte Carlo value for
`partial_kappa E[B(A)]` in [calculation-results.md](./calculation-results.md)
remains an approximate finite computation with empirical replicate error,
not an exact integral or rigorous error interval. The exact local curvature
construction above does not resolve that integration problem. It also does
not establish that ancillary shape sensitivity equals any component of
`H^(alpha)`.
