# FM-34 Calculation Results for the Tilted Logistic Ambient

Date: 2026-10-04 15:32:49 +09:00  
Agent: GitHub Copilot in VS Code; underlying model version not exposed

## Scope

This is a bounded model-specific computation for the explicit codimension-one
ambient family defined in [connection-bridge.md](./connection-bridge.md).
It does not modify the thread ledger or manuscript. Its conclusions apply at
the submodel `kappa=0`, not to arbitrary Fraser structural models.

## Model, scores, and metric

Let `Y=tanh(U/2) ~ Uniform(-1,1)`, `h(y)=y^3-3y/5`, and
`q(y)=2y*atanh(y)-1`. For one observation,

`p(x;mu,tau,kappa)=exp(-tau) f(u) exp(kappa*h(tanh(u/2))-C(kappa))`,
`u=(x-mu)exp(-tau)`,

where `f` is the standard logistic density and `C` normalizes the shape
exponential tilt. For `n` independent observations, use the product density.
At `kappa=0`, the one-observation scores are

`s_mu=e^-tau*y`, `s_tau=q(y)`, `s_kappa=h(y)`.

Because `E[y*h(y)]=0` and `q` is even while `h` is odd, the Fisher metric at
`kappa=0` is diagonal:

`g_mumu=n*e^(-2tau)/3`,
`g_tautau=n*(pi^2+3)/9`,
`g_kappakappa=4n/175`.

For the scale entry, putting `y=tanh(t)` gives
`E[y*atanh(y)]=1/2` and
`E[y^2*atanh(y)^2]=integral_0^infinity t^2*(sech(t)^2-sech(t)^4)dt
= pi^2/36+1/3`; hence `E[q^2]=(pi^2+3)/9`.

## Second fundamental form

With `h'(y)=3y^2-3/5`, the score derivatives at `kappa=0` are

`partial_kappa s_mu=-e^-tau*h'(y)*(1-y^2)/2`,
`partial_kappa s_tau=-h'(y)*atanh(y)*(1-y^2)`.

Differentiating the cross Fisher entry, including the density tilt, gives

`partial_kappa g_mu,tau|_0=-7n*e^-tau/45`.

The exact score moments needed for the alpha correction are

`E[h^2]=4/175`,
`E[y*q*h]=1/9`,
`E[q*h^2]=4/175`.

By parity, `partial_kappa g_mu,mu` and `partial_kappa g_tau,tau` vanish;
also `T_mu,mu,kappa=T_tau,tau,kappa=0`. Since the coordinate normal
`partial_kappa` is orthogonal to `S={kappa=0}` and the other coordinates are
the tangent coordinates, the normal component is

`H^(alpha)_mu,mu=H^(alpha)_tau,tau=0`,

`H^(alpha)_mu,tau
 = e^-tau*(245-175*alpha)/72 * partial_kappa`.

These coefficients use `Gamma^(alpha)=Gamma^(0)-alpha*T^sharp/2`.
At `tau=0`, they are `245/72` for `alpha=0`, `35/36` for `alpha=1`, and
zero for `alpha=7/5`. In the unit-normal frame
`N=sqrt(175/(4n))*partial_kappa`, multiply the displayed coefficient by
`sqrt(4n/175)`.

## Normal connection curvature

On `S`, use normal frame `partial_kappa`. Its length is constant along `S`.
The Levi-Civita normal connection coefficient therefore vanishes. The alpha
correction is computed from

`T_mu,kappa,kappa=0`,
`T_tau,kappa,kappa=n*4/175=g_kappa,kappa`.

Thus

`omega^(alpha)=-(alpha/2)d tau`.

It follows exactly that

`R_perp^(alpha)=d omega^(alpha)+omega^(alpha) wedge omega^(alpha)=0`

for every `alpha`. This chosen model has generically nonzero `H^(alpha)` but
flat induced normal transport along the two-dimensional submodel.

## Ancillary distribution response to shape

On `kappa=0`, the vector

`A_i=(U_i-mean(U))/||U-mean(U)||`

is an exact ancillary for `(mu,tau)`, since it is invariant under location
and positive scale. Use the bounded measurable functional
`B(A)=sum_i A_i^3`. Its derivative under the ambient shape perturbation is
exactly represented by

`partial_kappa E_kappa[B(A)]|_0
 = E_0[B(A)*sum_i h(Y_i)]`.

For `n=4`, this expectation was evaluated using scrambled Sobol points with
independent scrambles. The script maps `Y_i` to `U_i=2*atanh(Y_i)`, builds
`A`, and averages `B(A)*sum h(Y_i)`.

| points per replicate | scrambles | estimated derivative | replicate SD | replicate SE |
|---:|---:|---:|---:|---:|
| 16,384 | 8 | 0.04241421 | 0.00008931 | 0.00003158 |
| 65,536 | 8 | 0.04238315 | 0.00003282 | 0.00001160 |

The estimated derivative is about `0.0424`, positive for this selected
functional and `n=4`. The replicate SE is an empirical variability summary,
not a certified integration-error bound. Thus this particular ancillary
distribution responds to the chosen shape perturbation, but the response is
not identified with the second fundamental form, and no universal claim is
made for other ancillaries or ambient extensions.

## Reproduction

- Program: [compute_fm34.py](./compute_fm34.py)
- Exact invocation: `uv run python research-scratch/fraser_structural_geometry/20261004-fraser-fm34-bridge/compute_fm34.py`
- Backend preflight: `uv run python tools/computation_preflight.py` passed.
- Backend: Python 3.14.6, SymPy 1.14.0, NumPy 2.5.3, SciPy 1.18.1.
- Arithmetic: exact SymPy integration for the displayed rational moments;
  double-precision randomized quasi-Monte Carlo for the shape response.
- Finite scope: this one product family at `kappa=0`; shape response at `n=4`,
  two sample counts, eight scrambles per count, seeds 20261004–20261011.
- No second engine or independent verification was used.

## Open limitations

- The calculation does not establish a relation between ancillary shape
  sensitivity and `H^(alpha)` beyond their co-occurrence in this chosen model.
- The induced normal curvature is zero here, so this example does not establish
  or refute the possible coexistence of integrable structural directions with
  nonzero normal curvature.
- The quasi-Monte Carlo error is not rigorously bounded; a certified integral
  or analytic evaluation would strengthen the ancillary-response value.
