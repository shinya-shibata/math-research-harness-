# Ancillary Shape-Response Estimate with a Hoeffding Bound

Date: 2026-10-04 15:46:04 +09:00  
Agent: GitHub Copilot in VS Code; underlying model version not exposed

## Estimand

For the four-observation logistic location-scale submodel, let

`Y_i=tanh(U_i/2) iid Uniform(-1,1)`,
`h(y)=y^3-3y/5`,
`U_i=2*atanh(Y_i)`,
`A_i=(U_i-mean(U))/||U-mean(U)||`,
`B(A)=sum_i A_i^3`.

The derivative of the expectation of this fixed ancillary functional under
the one-parameter iid shape tilt at `kappa=0` is

`D = partial_kappa E_kappa[B(A)]|_0
   = E_0[Z]`,

where

`Z = B(A)*sum_i h(Y_i)`.

The identity follows by differentiating the normalized exponential-tilt
density; its score is `sum_i h(Y_i)` because `E[h(Y_i)]=0`. The event
`||U-mean(U)||=0` has probability zero; define `B=0` there.

## Uniform bound and confidence guarantee

Since `sum_i A_i^2=1`,

`|B(A)| <= sum_i |A_i|^3 <= (sum_i A_i^2)^(3/2)=1`.

On `[-1,1]`, `|h(y)|<=2/5`; hence for `n=4`,
`|sum_i h(Y_i)|<=8/5`. Therefore `Z` lies in `[-1.6,1.6]`, a range of
width `3.2`.

For `N` independent exact draws from the target uniform law, Hoeffding's
inequality gives

`Pr(|mean(Z)-D| >= eps) <= 2*exp(-2*N*eps^2/(3.2)^2)`.

With `N=1,200,000` and `delta=0.01`, this yields the two-sided 99% half-width

`eps = 3.2*sqrt(log(2/delta)/(2*N)) = 0.00475459295`.

The seeded NumPy PCG64 run returned

`mean(Z)=0.04226410581`,

so the conservative Hoeffding interval is

`[0.03750951286, 0.04701869875]`.

Under the ideal independent-sampling model, this interval has at least 99%
coverage. In particular, its lower endpoint is positive. This is a
probabilistic error guarantee, not a deterministic quadrature certificate.
The actual program uses a seeded pseudorandom generator; interpreting its
output through the ideal-IID guarantee invokes the usual pseudorandom
sampling assumption. The interval does not claim rigorous coverage against
the deterministic PRNG sequence itself.

## Reproduction and scope

- Program: [certify_shape_response.py](./certify_shape_response.py)
- Invocation: `uv run python research-scratch/fraser_structural_geometry/20261004-fraser-fm34-bridge/certify_shape_response.py`
- Python 3.14.6, NumPy 2.5.3, PCG64, seed `20261004`.
- One estimate from `1,200,000` pseudorandom four-dimensional uniform points.
- No QMC replicate uncertainty was used to construct the Hoeffding interval.
- Project backend preflight passed in this session.

This result concerns the one selected functional `B(A)` and the one selected
shape direction `h` at `kappa=0`. It does not show that all ancillaries
respond to shape, nor that the response is equal to a component of
`H^(alpha)`. An exact evaluation or a deterministic validated-integration
bound remains open.
