# Fraser 構造推論と FM-34 の条件付き接続

Date: 2026-10-04 15:16:49 +09:00  
Agent: GitHub Copilot in VS Code; underlying model version not exposed

## 範囲と結論

対象は既存 thread `fraser_structural_geometry` の bounded task とし、
構造表現 `X = F_beta(U)` から FM-34 の ambient alpha 第二基本形式へ
何が引き継がれるかを調べた。台帳、原稿、先行 FM-34 記録は変更しない。

接続は次の二段階で正確に書ける。

1. 構造輸送 `F_beta` は、誘導密度モデルの score を標本空間上の速度場から与える。
   score は統計モデルの Fisher 接ベクトルを定める。
2. ambient 統計モデルと immersion を別途指定すれば、その Fisher 接ベクトルを
   ambient alpha 接続で微分し、正規射影して FM-34 の第二基本形式を得る。

一方、Fraser の exact ancillary 条件は score の条件付き平均ゼロとして表せる。
これは Fisher 接空間と ancillary sigma-field の関係であって、
FM-34 の法束や第二基本形式そのものではない。構造方程式単独から
ambient 法束曲率・alpha 第二基本形式を決める一般定理は得られない。

## 1. 構造輸送から score への写像

`U ~ Q`、`F_beta: U -> X` を各 beta について微分同相とし、
`P_beta = (F_beta)_# Q` が共通測度 `dx` に関する正の滑らかな密度
`p_beta(x)` を持つとする。微分と積分の交換ができ、境界流束がないと仮定する。
固定した `u` に対する構造速度を

`v_a(F_beta(u)) = partial_a F(beta,u)`

と定める。密度の輸送方程式は

`partial_a p_beta + div_x(p_beta v_a) = 0`

である。従って score `s_a = partial_a log p_beta` は

`s_a(x) = -div_x v_a(x) - v_a(x) dot grad_x log p_beta(x)`.

したがって構造感度 `v_a` から score への写像は、Fisher 計量

`g_ab = E_beta[s_a s_b]`

と統計モデル内の接ベクトル `partial_a p_beta = p_beta s_a` を決める。
ただし写像 `v_a -> s_a` は単射ではない。`div(p_beta w)=0` を満たす速度場 `w`
を加えても score は変わらない。よって Fraser の標本空間上の輸送方向と、
統計モデル上の Fisher 接ベクトルは関連するが、同一の幾何対象ではない。

## 2. Exact ancillary の Fisher 条件

`A:X -> Y` をパラメータに依存しない統計量とする。微分可能性の下で、
任意の有界可測関数 `phi` について

`partial_a E_beta[phi(A(X))] = E_beta[phi(A(X)) s_a(X)]`.

従って、`A` の分布が beta に依存しないための局所条件は

`E_beta[s_a | sigma(A)] = 0`  (全ての `a`)

である。逆に、`B` が連結で、上の条件が全点で成り立ち、期待値の微分が正当化
されるなら、各 `E_beta[phi(A)]` は `B` の道に沿って一定であり、`A` は exact
ancillary である。この条件は「score の `A` 可測成分がゼロ」という主張である。

特に `X=F_beta(U)` に対して `A(F_beta(u))=A(u)` が全ての beta と Q-a.e. の u
で成立すれば、`A(X)` の分布は `A(U)` の分布と一致し exact ancillary となる。
これは群作用の不変量でしばしば使える十分条件であり、一般の ancillary の定義
より強い条件である。

## 3. FM-34 を適用する ambient 幾何

統計モデル `beta -> P_beta` を、次元 `k` の指定済み ambient 統計多様体
`M` に immersion `i:B -> M` で埋め込む。ambient Fisher 計量 `g`、三次テンソル
`T`、計量正規射影 `Pi_N` を固定し、

`nabla^(alpha) = nabla^(0) - alpha*T^sharp/2`

とする。同じ射影で定義した

`H^(alpha)(X,Y) = Pi_N(nabla_tilde^(alpha)_(di X) di Y)`

は、定義から

`H^(alpha) = H^(0) - alpha/2 * Pi_N(T^sharp(di X,di Y))`

を満たす。構造輸送によって `di(X)` に対応する score 接ベクトルは得られる。
しかし `Pi_N` と `T^sharp` の正規成分を評価するには、ambient nuisance/shape
方向、その score、ambient Fisher 計量および交差三次モーメントが必要である。
これらは `F_beta` が指定する部分モデルだけからは決まらない。

このため条件付き接続は次のとおり。

`structural map -> pushforward density -> score/Fisher tangent`

`(score/Fisher tangent) + (chosen ambient model and immersion)
 -> H^(alpha) and normal curvature`.

第二の矢印は ambient 選択を要する追加構造であり、第一の矢印から自動ではない。
部分モデル自体を ambient と取れば余次元ゼロとなり、非自明な法束はない。

## 4. 具体例: location-scale logistic と ancillary

`U_1,...,U_n` を独立な標準 logistic とし、

`X_i = mu + exp(tau) U_i`

とする。`n >= 2` で

`A_i(X) = (X_i - mean(X)) / sqrt(sum_j (X_j-mean(X))^2)`

とおけば、分母ゼロ事象は連続分布の下で確率ゼロであり、
`A(mu + c X) = A(X)` (`c>0`) なので `A(X)=A(U)`。従って `A` は
`(mu,tau)` に関する exact ancillary である。既存 location-scale pilot の記法
`u_i=(x_i-mu)exp(-tau)` では score は

`s_mu = exp(-tau) sum_i tanh(u_i/2)`,

`s_tau = -n + sum_i u_i*tanh(u_i/2)`.

上記 ancillary 条件から
`E[s_mu | A]=E[s_tau | A]=0` が直ちに従う。これは構造表現・誤差変数・exact
ancillary・Fisher score を明示的に接続する結果である。

ただし、この二次元 location-scale family 自身を ambient `M` とすれば
余次元ゼロである。ここから `H^(alpha)` や法束ホロノミーの非自明な値は出ない。

### codimension-one ambient 拡張の明示例

正規方向を具体化する一つの局所 ambient 候補を次のように定められる。
標準 logistic 密度を `f(u)=1/(4 cosh^2(u/2))` とし、
`y(u)=tanh(u/2)`、`h(y)=y^3-(3/5)y`、
`C(kappa)=log integral f(u) exp(kappa*h(y(u))) du` と置く。

`p(x;mu,tau,kappa) = exp(-tau) f(u)
 exp(kappa*h(y(u))-C(kappa))`,
`u=(x-mu)exp(-tau)`.

For the `n`-observation pilot, take the product density
`prod_i p(x_i;mu,tau,kappa)`; the displayed one-observation score functions
then add over observations.

`h` は有界なので正規化積分は有限であり、`kappa=0` は location-scale logistic
model である。`Y=tanh(U/2)` は一様 `(-1,1)` なので
`E[Y^2]=1/3`, `E[Y^4]=1/5`、従って
`E[Y h(Y)]=1/5-(3/5)(1/3)=0`。また `h` は奇関数、scale score
`2Y atanh(Y)-1` は偶関数である。よって `kappa=0` では shape score `h(Y)` は
location score と scale score の双方に直交する。各スコアの分散は正であり、
この三つのスコアは線形独立なので Fisher 計量は点 `(mu,tau,0)` で正定値。
滑らかさにより、十分小さい `|kappa|` の近傍に三次元正則 ambient family が得られる。

この ambient で `S={kappa=0}` とすれば、location-scale Fraser model は
余次元一の immersed submodel となり、`H^(alpha)` を定義できる。
`A` の beta-directionでの ancillary 性は維持される一方、shape direction の score
`s_kappa` に対して

`partial_kappa E[phi(A)] = E[phi(A) s_kappa]
 = E[phi(A) E(s_kappa|A)]`

である。右辺は ambient shape 摂動に対する ancillary 分布の一次感度である。
したがってこの具体例では、Fraser ancillary は `S` の score と直交し、
ambient 正規 shape score は ancillary 分布が shape に応答するかを測る候補となる。
しかし `E(s_kappa|A)` が非零であること、または `H^(alpha)` が非零であることは
ここでは主張しない。後者は ambient alpha 接続係数の計算を別途要する。

## 5. ここまでの証拠と未解決点

- `proved/agent`：連続の方程式からの score 輸送式、および exact ancillary と
  `E[s_a|A]=0` の同値性（連結性・微分交換等の明記した条件下）。
- `proved/agent`：FM-34 の alpha 第二基本形式恒等式（固定 ambient、計量、正規射影の下）。
- `proved/agent`：location-scale logistic の standardized residual の exact ancillarity。
- 正則 ambient 例：上記 tilt family の正規化可能性と Fisher 正定値性を
  `kappa=0` で解析的に確認。接続係数・第二基本形式・法束曲率は未計算。
- `open`：Fraser の ancillary に付随する標本空間方向と、ambient Fisher 法束を
  一般に対応づける canonical な構成は得ていない。今回の結論は一般の同一視を否定し、
  score を介した条件付き対応だけを与える。
- `open`：具体 ambient 例で `E[s_kappa|A]`、`H^(alpha)` と法束曲率を計算し、
  ancillary 分布の shape 感度との関係を調べること。

この screen は `F=0` と `R_perp != 0` の同時実現、exact ancillary の存在と
法束平坦性の含意、または Fraser 推論の有限標本条件付き有意水準を証明しない。

## 文献調査記録

検索日: 2026-10-04。ローカルカタログを先に検索したところ、
`uv run python tools/reference_lookup.py --keyword "information geometry" --json`
および `--grep "alpha connection"` は空結果だった。以下の外部検索は
question-driven 検索を行った後、ローカル参考文献を使う別経路で行った。
provider検索ページで確認できた範囲のみを記す。

### 独立した question-driven pass

| 検索軸 | query | arXiv | SpringerLink | SIAM |
|---|---|---|---|---|
| exact | `Fraser structural inference ancillary sample space model connection geometry` | 結果なし表示 | HTTP 406、結果を閲覧できず | HTTP 403、結果を閲覧できず |
| 用語変種 | `ancillary tangent exponential model information geometry sample space transport` | 結果なし表示 | HTTP 406、結果を閲覧できず | HTTP 403、結果を閲覧できず |
| 障害・反例 | `exact ancillary statistic geometric curvature obstruction nonexistence` | 結果なし表示 | HTTP 406、結果を閲覧できず | HTTP 403、結果を閲覧できず |

### ローカル文献からの別経路

ローカル種は `tem.md` References (Fraser & Reid 1995, 2001;
Davison & Reid 2022, arXiv:2106.10496; Amari & Nagaoka 2000) と
`ancillary_holonomy_paper_revised_md.md` References/Sections 2–3
(Efron 1975)。

- 各題名・著者を arXiv、SpringerLink、SIAM で個別検索した。
  SpringerLink は全検索 HTTP 406、SIAM は HTTP 403。arXiv は
  *Ancillaries and third order significance*, *Ancillary information for
  statistical inference*, *Methods of Information Geometry* の各表現では
  結果なし表示だった。
- Davison & Reid の *The Tangent Exponential Model* は arXiv 検索で
  **arXiv:2106.10496** と著者が一致する記録を確認した。arXiv HTML の
  Section 6.2 “No nuisance parameters” と周辺記述では location model の
  location-invariant estimator と location ancillary に条件付ける構成、
  および一般モデルでの sufficient directions による conditional distribution
  の議論を確認した。出典: Davison & Reid (2022), arXiv:2106.10496,
  <https://arxiv.org/html/2106.10496>, §6.2 (検索ページ:
  <https://arxiv.org/abs/2106.10496>)。このレビューは Fraser/TEM の
  条件付き推論の背景を支えるが、本記録の alpha 法束恒等式や ancillary-normal
  同一視を確立するものではない。
- Efron 1975 はローカル草稿内の書誌記載のみを検索種として使用し、
  一次論文本文・正確な locator は確認できていない。

SpringerLink/SIAM 結果を取得できず、arXiv検索も網羅検索ではなく、
該当文献の有無を結論できない。後方・前方引用追跡も未実施である。
文献レビューと新規性評価は **incomplete**。

## 次の最小識別テスト

上記三次元 tilt ambient で `kappa=0` における全 Fisher 計量と alpha 接続の
Christoffel 記号を score moment から計算し、`H^(alpha)` の法方向成分を出す。
同時に `E[s_kappa|A]`（または全有界 test function に対する積分）を解析または
適切な積分で調べる。これで、ancillary の ambient shape 感度と第二基本形式が
同じ量なのか、異なる情報を持つのかを初めてこの明示モデル上で判定できる。
