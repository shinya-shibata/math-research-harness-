"""Exact transport along arbitrary loops in the OP-3 explicit model.

This script uses the fixed connection
    omega = exp(-tau) M dmu,
    omega_tau = 0,
with
    M = [[0, -28/45], [9/4, 0]].

If the path is gamma(s) = (mu(s), tau(s)), then the matrix ODE is
    Y'(s) = exp(-tau(s)) M mu'(s) Y(s),
which has the exact solution
    Y(s) = exp(M * int_0^s exp(-tau(r)) mu'(r) dr).
Hence any loop with zero net mu-displacement has identity transport.
"""

from __future__ import annotations

import math

import numpy as np
import sympy as sp
from scipy.linalg import expm

M = np.array([[0.0, -28.0 / 45.0], [9.0 / 4.0, 0.0]], dtype=float)


def transport_along_path(mu_fn, tau_fn, t_grid=None, n=4000):
    if t_grid is None:
        t_grid = np.linspace(0.0, 1.0, n)
    mu_vals = np.array([mu_fn(t) for t in t_grid], dtype=float)
    tau_vals = np.array([tau_fn(t) for t in t_grid], dtype=float)
    dm = np.gradient(mu_vals, t_grid)
    integral = np.trapezoid(np.exp(-tau_vals) * dm, t_grid)
    return expm(integral * M), integral


def rect_loop(mu0: float, tau0: float, h: float, k: float):
    def mu_fn(t):
        if t <= 0.25:
            return mu0 + h * (4.0 * t)
        if t <= 0.5:
            return mu0 + h
        if t <= 0.75:
            return mu0 + h * (1.0 - 4.0 * (t - 0.5))
        return mu0

    def tau_fn(t):
        if t <= 0.25:
            return tau0
        if t <= 0.5:
            return tau0 + k * (4.0 * (t - 0.25))
        if t <= 0.75:
            return tau0 + k
        return tau0 + k * (1.0 - 4.0 * (t - 0.75))

    return mu_fn, tau_fn


def symbolic_general_formula():
    s = sp.symbols("s", real=True)
    mu, tau = sp.symbols("mu tau", cls=sp.Function)
    M_sym = sp.Matrix([[0, -sp.Rational(28, 45)], [sp.Rational(9, 4), 0]])
    integral = sp.integrate(sp.exp(-tau(s)) * sp.diff(mu(s), s), (s, 0, 1))
    return {
        "general_integral": str(integral),
        "matrix_exponential_form": str(sp.exp(integral * M_sym)),
    }


def main():
    print("OP-3 exact general-loop transport in the explicit model")
    print("=" * 88)
    print("Connection: omega = exp(-tau) M dmu,  omega_tau = 0")
    print("M =", M)
    print()

    # rectangular loop exact comparison
    for params in [(0.0, 0.3, 1e-3, 1e-3), (0.0, 0.7, 2e-3, 2e-3), (0.5, 0.7, 1e-2, 1e-2)]:
        mu0, tau0, h, k = params
        mu_fn, tau_fn = rect_loop(mu0, tau0, h, k)
        transport, integral = transport_along_path(mu_fn, tau_fn, n=40000)
        exact_coeff = h * (math.exp(-tau0) - math.exp(-(tau0 + k)))
        expected = expm(exact_coeff * M)
        diff = np.linalg.norm(transport - expected, ord="fro")
        print(f"params: mu0={mu0}, tau0={tau0}, h={h}, k={k}")
        print(f"  integral = {integral:.12e}")
        print(f"  exact =\n{expected}")
        print(f"  computed =\n{transport}")
        print(f"  Frobenius diff = {diff:.3e}")
        print()

    print("Symbolic summary")
    print("-" * 88)
    for key, value in symbolic_general_formula().items():
        print(f"{key}: {value}")
    print()
    print("Interpretation:")
    print("- For any path with mu'(s) nonzero, the transport is exp(M * ∫ exp(-tau(s)) mu'(s) ds).")
    print("- Any loop with zero net μ-displacement, especially a tau-only loop, has identity holonomy.")
    print("- Thus the local curvature is nonzero, but the period contribution is determined by the loop integral and may vanish on noncontractible tau-loops.")


if __name__ == "__main__":
    main()
