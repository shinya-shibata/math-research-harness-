# FM-14: Same Marginals, Distinct Global Flows

- Date: 2026-10-04 (JST)
- Agent: GitHub Copilot
- Scope: Construct two distinct global flows on a concrete smooth density path. This is an explicit example, not a classification of all gauge fields.
- Evidence status: `proved/agent`
- Related audit: `research-scratch/fraser_structural_geometry/20261004-2133-fm14-audit.md`

## Construction

Let `T^2 = (R / 2 pi Z)^2` with coordinates `(x,y)` and reference measure `dx dy`. Fix `0 < epsilon, delta < 1` and constants `a != 0`, `c != 0`. Define the normalized positive density

`q(x,y) = (1 + epsilon cos(x))(1 + delta cos(y)) / (4 pi^2)`

and the time-dependent density path

`p_t(x,y) = q(x - a t, y)`.

The initial law has density `p_0 = q`. Since `q` is smooth and strictly positive on compact `T^2`, every `p_t` is smooth and bounded above and away from zero, uniformly in `t`.

Consider the two smooth time-dependent velocity fields

`v^(1)_t(x,y) = (a, 0)`

and

`v^(2)_t(x,y) = (a, c / p_t(x,y))`.

They are distinct because `c != 0`. Both satisfy the continuity equation for the same density path:

`partial_t p_t = -a partial_x p_t`,

`div(p_t v^(1)_t) = a partial_x p_t`,

`div(p_t v^(2)_t) = partial_x(a p_t) + partial_y(c) = a partial_x p_t`.

Thus `partial_t p_t + div(p_t v^(j)_t) = 0` for `j=1,2`. Equivalently, the difference `w_t = v^(2)_t - v^(1)_t = (0,c/p_t)` is a nonzero weighted-divergence-free field:

`div(p_t w_t) = div(0,c) = 0`.

## Global flows and distinctness

For the first velocity, the flow is explicit:

`Phi^(1)_t(x_0,y_0) = (x_0 + a t, y_0) mod 2 pi`.

For the second velocity, the ODE is

`x_dot = a`, `y_dot = c / p_t(x,y)`.

Along a trajectory starting at `x_0`, one has `x(t)=x_0+a t` and

`p_t(x(t),y) = q(x_0,y)`.

Consequently its second coordinate solves

`y_dot = c / q(x_0,y)`.

This is a smooth vector field on the circle for each `x_0`. More explicitly, on a real lift of the circle, put

`H_x(y) = integral_0^y q(x,s) ds = (1 + epsilon cos(x))(y + delta sin(y)) / (4 pi^2)`.

Then `H_x` is strictly increasing, satisfies `H_x(y+2 pi) = H_x(y) + (1+epsilon cos(x))/(2 pi)`, and the second coordinate is uniquely specified on the lift by

`H_(x_0)(y(t)) = H_(x_0)(y_0) + c t`.

This defines a global flow for every real `t`, descending to the circle. It is a smooth diffeomorphism at each time. Alternatively, global existence and uniqueness follow because each velocity field is smooth on a compact manifold, and the backward-time flow supplies the inverse.

The two flows have the same initial map but different initial velocities at every point:

`d/dt Phi^(1)_t(x_0,y_0)|_(t=0) = (a,0)`,

`d/dt Phi^(2)_t(x_0,y_0)|_(t=0) = (a,c/q(x_0,y_0))`.

Since `c != 0`, the flows are distinct for all sufficiently small nonzero times. Their pushforwards of the common initial law both have density `p_t`: each flow's pushforward density solves the classical continuity equation above, whose solution is unique for a smooth velocity field.

## Conclusion and scope

This resolves the existential question in item 1 of `open problems.md`: a smooth positive nonconstant density path on a compact sample space can be transported from the same initial law by distinct smooth global flows, with identical one-time marginal densities. Each selected velocity field nevertheless generates its own unique flow; nonuniqueness is across different admissible velocity fields, not failure of ODE uniqueness for either field.

This example does not show that the flows induce the same path-space law, nor does it construct an exact ancillary or imply anything about normal-bundle curvature. The choice of `c` is a genuine circulation around the periodic `y` direction. Boundary conditions on noncompact or bounded domains and a classification of all admissible weighted-divergence-free fields remain separate questions.
