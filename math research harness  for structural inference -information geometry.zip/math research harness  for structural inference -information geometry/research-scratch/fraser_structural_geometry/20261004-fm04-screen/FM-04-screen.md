# FM-04: Orbit quotients, maximal invariants, and exact ancillarity

Date: 2026-10-04 21:20:56 +09:00
Agent: GitHub Copilot in VS Code; underlying model version not exposed

## Scope and result

This is a follow-up screen of the single generated candidate FM-04 in
`research-scratch/fraser_structural_geometry/20260930-231402/candidates.jsonl`.
It completes the candidate-specific search attempt requested there and tests
the candidate's location-scale example. The original batch, thread ledger, and
manuscript are unchanged.

**Evidence:** `proved/agent` for the precisely stated result below. The
literature review is `incomplete`; this is not a novelty assessment.

The candidate is correct under a measurable formulation of “regular
quotient,” but its converse is a factorization statement, not a new ancillary
criterion. It does **not** say that every exact ancillary is a function of a
maximal invariant.

## Precise statement

Let a group `G` act measurably on a standard Borel sample space `X`. Let
`T:X -> Z` be a Borel maximal invariant into a standard Borel space `Z`,
meaning `T(g x)=T(x)` and `T(x)=T(y)` exactly when `x` and `y` lie in the
same `G`-orbit. Let the model be

`P_theta = (g_theta)_# P_U`, with `g_theta in G` and a fixed probability law
`P_U`.

Then:

1. `T` is an exact ancillary, and every Borel statistic `h(T)` is an exact
   ancillary.
2. Every standard-Borel-valued statistic measurable with respect to
   `sigma(T)` factors as `h(T)`. For completed sigma-fields, this factorization
   holds almost surely under the measure used for the completion.

For the first part, `T(g_theta x)=T(x)` pointwise, so
`T#P_theta = T#P_U` for every `theta`; applying any fixed measurable `h`
preserves equality of distributions. For the second part, apply the
measurable factorization theorem (Doob-Dynkin) to `sigma(T)`.

The exact ancillary conclusion applies directly to a representative defined
as `h(T)` everywhere. If a statistic is only equal to `h(T)` `P_U`-almost
surely, that alone need not transfer the equality to every `P_theta` when
the measures have different null sets; a common null-set condition or an
invariant version is then needed. Transitivity of the parameter orbit is not
needed for this result. What matters is that every transformation used to
index the family belongs to the acting group and that the quotient is
measurably represented by `T`.

## First test: normal location-scale sample

For `X=(X_1,...,X_n)`, `n >= 3`, under
`X_i = mu + sigma U_i`, `sigma > 0`, with iid standard normal `U_i`, set

`T(x) = (x - mean(x)*1) / ||x - mean(x)*1||`

when the denominator is nonzero. The exceptional constant-sample set has
probability zero. For every nonconstant `x`,

`T(mu*1 + sigma*x) = T(x)`.

Moreover, `T(x)=T(y)` holds exactly when
`y = a*1 + b*x` for some `a in R`, `b > 0`: equality of the normalized
centered residuals gives
`y-mean(y)*1 = (||y-mean(y)*1|| / ||x-mean(x)*1||)
 (x-mean(x)*1)`.
Thus `T` separates the location-scale orbits on the nonexceptional set.
Consequently `T(X)=T(U)` and its law does not depend on `(mu,sigma)`;
all quotient-measurable statistics are functions of `T` and are exact
ancillaries. The proposed first test passes.

This example verifies only the stated quotient-measurable class. It does not
settle whether other exact ancillaries in a given model are quotient
measurable.

## Literature search record (2026-10-04)

The local catalog was queried before external searching:
`uv run python tools/reference_lookup.py --keyword ancillary --json` and
`uv run python tools/reference_lookup.py --grep "orbit quotient" --json`;
both returned an empty result. FM-04 listed no local-reference seeds. The
candidate seed paper's bibliography was also checked for directly relevant
Fraser/ancillary works; the supplementary title/author searches below are
kept separate from the question-driven searches.

### Candidate-specific question-driven searches

The following three exact query strings from FM-04 were submitted separately
to each provider:

1. `orbit quotient maximal invariant exact ancillary exact claim`
2. `orbit quotient maximal invariant exact ancillary alternate terminology structural inference`
3. `orbit quotient maximal invariant exact ancillary contrary result counterexample obstruction`

| Provider | Result for all three queries |
|---|---|
| arXiv | Each native search page reported zero results. |
| SpringerLink | All three requests failed with HTTP 406; no result pages were inspectable. |
| SIAM | All three requests failed with HTTP 403; no result pages were inspectable. |

Native query pages:

- arXiv: [Q1](https://arxiv.org/search/?query=orbit+quotient+maximal+invariant+exact+ancillary+exact+claim&searchtype=all&abstracts=show&order=-announced_date_first), [Q2](https://arxiv.org/search/?query=orbit+quotient+maximal+invariant+exact+ancillary+alternate+terminology+structural+inference&searchtype=all&abstracts=show&order=-announced_date_first), [Q3](https://arxiv.org/search/?query=orbit+quotient+maximal+invariant+exact+ancillary+contrary+result+counterexample+obstruction&searchtype=all&abstracts=show&order=-announced_date_first).
- SpringerLink: [Q1](https://link.springer.com/search?query=orbit%20quotient%20maximal%20invariant%20exact%20ancillary%20exact%20claim), [Q2](https://link.springer.com/search?query=orbit%20quotient%20maximal%20invariant%20exact%20ancillary%20alternate%20terminology%20structural%20inference), [Q3](https://link.springer.com/search?query=orbit%20quotient%20maximal%20invariant%20exact%20ancillary%20contrary%20result%20counterexample%20obstruction).
- SIAM: [Q1](https://epubs.siam.org/action/doSearch?AllField=orbit%20quotient%20maximal%20invariant%20exact%20ancillary%20exact%20claim), [Q2](https://epubs.siam.org/action/doSearch?AllField=orbit%20quotient%20maximal%20invariant%20exact%20ancillary%20alternate%20terminology%20structural%20inference), [Q3](https://epubs.siam.org/action/doSearch?AllField=orbit%20quotient%20maximal%20invariant%20exact%20ancillary%20contrary%20result%20counterexample%20obstruction).

Additional arXiv terminology searches were used to avoid treating those
overloaded generated query strings as a complete search: `"maximal
invariant" ancillary` returned one inspected result, Milson and Valiquette,
*Point Equivalence of Second-Order ODEs: Maximal Invariant Classification
Order* (2014), which is unrelated to statistical ancillarity;
`maximal invariant group action ancillary statistic` and
`location scale maximal invariant ancillary` each reported zero results.
The corresponding arXiv pages were
[quoted-phrase query](https://arxiv.org/search/?query=%22maximal+invariant%22+ancillary&searchtype=all&abstracts=show&order=-announced_date_first),
[group-action query](https://arxiv.org/search/?query=maximal+invariant+group+action+ancillary+statistic&searchtype=all&abstracts=show&order=-announced_date_first),
and [location-scale query](https://arxiv.org/search/?query=location+scale+maximal+invariant+ancillary&searchtype=all&abstracts=show&order=-announced_date_first).
These are search outcomes, not evidence that no relevant literature exists.

### Supplementary local-reference route

The seed paper bibliography includes Fraser, *The Structure of Inference*
(1968); Fraser and Reid, “Ancillaries and third order significance” (1995);
and Fraser and Reid, “Ancillary information for statistical inference”
(2001). The corresponding title/author queries were submitted directly to
each of arXiv, SpringerLink, and SIAM.

- arXiv: the 1968 query returned one result, Taraldsen and Lindqvist,
  [“Conditional fiducial models,” arXiv:1711.00912](https://arxiv.org/abs/1711.00912v1).
  Its inspected abstract mentions Fraser's structural group models, but does
  not state or establish the FM-04 factorization claim. The 1995 and 2001
  queries returned zero results.
- SpringerLink: all three searches failed with HTTP 406.
- SIAM: all three searches failed with HTTP 403.

The supplementary query strings were `Fraser The Structure of Inference
1968`, `Fraser Reid Ancillaries and third order significance 1995`, and
`Fraser Reid Ancillary information for statistical inference 2001`, sent
through the [arXiv search](https://arxiv.org/search/),
[SpringerLink search](https://link.springer.com/search), and
[SIAM search](https://epubs.siam.org/action/doSearch) pages.

No candidate-specific local-reference title search was marked complete at
either inaccessible provider. The review is therefore incomplete; no
literature match, absence claim, or novelty claim is made. The arXiv hits
above are discovery results only, not literature verification of the
proposition.

## Classification and remaining limits

- `work_status`: screened (this follow-up only; the original batch record is
  preserved as generated).
- `evidence_status`: `proved/agent` for the standard-Borel group-action
  formulation above.
- Literature: `incomplete` because SpringerLink and SIAM could not be
  inspected, and the accessible arXiv results did not verify the exact
  proposition.
- The original phrase “regular quotient” must be replaced by explicit Borel
  quotient/maximal-invariant and null-set hypotheses before using this as a
  general theorem. Smoothness alone is not a substitute for those
  measurability assumptions.
- Best next discriminating step: if the research aim is broader than this
  characterization, specify a model and test whether an exact ancillary
  exists outside the maximal-invariant sigma-field. FM-04 as currently
  restricted does not address that question.
