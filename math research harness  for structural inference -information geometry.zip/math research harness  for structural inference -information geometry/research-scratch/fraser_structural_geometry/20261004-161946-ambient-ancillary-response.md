# Ancillary response in the codimension-two logistic-tilt ambient

Date: 2026-10-04 16:19:46
Agent: GitHub Copilot in VS Code; underlying model version not exposed
Status: bounded model-specific investigation; literature review incomplete

## Question and scope

In the explicit two-shape logistic ambient from the FM-34 bridge, how does
the distribution of the exact location-scale ancillary respond to the two
normal shape directions, and what can that response say about its
Fisher-normal curvature?

Fix the four-observation model and base submodel `k1=k2=0`. Let
`Y_i=tanh(U_i/2) iid Uniform(-1,1)`,
`U_i=2*atanh(Y_i)`, and

`h1(y)=y^3-3y/5`,
`h2(y)=y^4-14y^2/15+1/9`.

The ambient is the product logistic shape tilt
`p(x;mu,tau,k1,k2) = exp(-tau) f(u)
 exp(k1*h1(y)+k2*h2(y)-C(k1,k2))`,
where `u=(x-mu)exp(-tau)`, `y=tanh(u/2)`, and
`C=log integral f(u) exp(k1*h1(y)+k2*h2(y)) du`.
Both h-functions are bounded; the existing exact checks establish that
the Fisher metric is positive definite on the submodel and that the
codimension-two normal connection curvature at `alpha=0` is

`R_perp,mu,tau^(0) = exp(-tau)*[[0,-28/45],[9/4,0]]`.

The parameter-free statistic is the centered, normalized residual
configuration

`A_i(X)=(X_i-mean(X))/sqrt(sum_j (X_j-mean(X))^2)`.

It is well-defined almost surely for `n=4`. Under `k1=k2=0`,
`A(X)=A(U)`, so it is exact ancillary for `(mu,tau)`.

## Candidate relation and estimands

For a bounded function `B(A)` and shape coordinate `k_j`, differentiation
of the normalized tilt at `(k1,k2)=(0,0)` gives

`D_j(B) = partial_(k_j) E_(k1,k2)[B(A)]|_(0,0)
        = E_0[B(A) * S_j]`,

where `S_j=sum_(i=1)^4 h_j(Y_i)` is the shape score. This is the
distributional first derivative of the selected ancillary functional.
It is distinct from the second fundamental form and from the normal
curvature endomorphism.

Use the bounded test functions `B3(A)=sum_i A_i^3` and
`B4(A)=sum_i A_i^4`. The tested 2-by-2 response matrix has rows `(B3,B4)`
and columns `(k1,k2)`.

## Exact deductions

1. `B3` is odd under `Y -> -Y`; `h2` and `S_2` are even. Therefore
   `D_2(B3)=0` exactly.
2. `B4` is even; `h1` and `S_1` are odd. Therefore
   `D_1(B4)=0` exactly.
3. The derivative in the `k1` direction is unchanged if the two-shape
   ambient is restricted to `k2=0`: the submodel density and its `k1`
   score are exactly the same as in the prior one-shape tilt.
4. The one-shape ambient has zero normal curvature along the
   location-scale submodel for every alpha, while the two-shape ambient
   has the nonzero Levi-Civita curvature matrix displayed above. Adding
   the second shape direction leaves `D_1(B3)` unchanged but changes the
   normal-bundle curvature. Thus that scalar ancillary response cannot
   determine whether the chosen ambient normal transport is flat.

The response matrix and curvature matrix do not have the same intrinsic
tensor type. The response rows depend on selected test functions and can
be changed by replacing them; no invariant matrix equality is proposed.
The exact comparison above is only the one-way restriction in `k1` and
the stated ambient extensions.

## Bounded numerical test

The script
`.research-scratch/fraser_structural_geometry/20261004-161700-shape-response/shape_response.py`
generated 2,000,000 pseudorandom iid base points from the product
`Uniform(-1,1)^4` law using NumPy PCG64 seed `20261004`. At each point it
formed `A`, `B3`, `B4`, `S_1`, and `S_2` and averaged all four products.

Since `sum A_i^2=1`, both `|B3|<=1` and `|B4|<=1`. On `[-1,1]`,
`|h1|<=2/5` and `|h2|<=8/45`. Thus the product integrands lie in
`[-8/5,8/5]` for either `k1` entry and in `[-32/45,32/45]` for either
`k2` entry. Applying Hoeffding to each entry with component
`delta=0.0025` and Bonferroni gives at least 99% joint coverage under the
ideal independent-draw model.

| Test function | Direction | Estimate | 99% simultaneous interval |
|---|---|---:|---:|
| `B3` | `k1` | 0.0423815 | [0.0382447, 0.0465182] |
| `B3` | `k2` | -0.0000288 | [-0.0018674, 0.0018098] |
| `B4` | `k1` | 0.0000328 | [-0.0041039, 0.0041695] |
| `B4` | `k2` | 0.0027941 | [0.0009555, 0.0046326] |

The off-diagonal zero values are exact by parity; their intervals are only
sampling checks. The two diagonal responses have positive one-sided
Hoeffding lower bounds at the stated joint confidence level, conditional
on ideal iid sampling. Because the run uses a seeded pseudorandom generator,
the probabilistic guarantee invokes the usual pseudorandom-sampling
assumption; it is not a deterministic integration certificate or a formal
proof that the exact integrals are positive.

Consequently the selected ancillary distribution responds to both
orthogonal shape perturbations in the two tested functionals, to the
stated probabilistic evidence level. It remains exact ancillary for the
location-scale tangent submodel, but not for the full four-parameter
ambient if either exact derivative is indeed nonzero.

## Interpretation and proof boundary

- Exact: the score identity for `D_j(B)`, the two parity cancellations,
  and equality of the `k1` derivative in the one- and two-shape
  restrictions.
- Existing exact model result: nonzero `R_perp^(0)` in the
  codimension-two ambient and zero `R_perp^(alpha)` in the one-shape
  ambient.
- `verified-computationally` at finite scope: the four response
  expectations for `n=4`, with the confidence and PRNG qualifications
  above. This is not an exact integral evaluation.
- Refuted for this comparison: a rule that the `k1` response of this
  ancillary functional alone determines flatness of the normal
  connection independently of the chosen ambient extension.
- Not established: an equality, proportionality, or general functional
  relationship between `D_j(B)`, `h^(alpha)`, and `R_perp^(alpha)`.
  A curvature tensor is a normal-bundle endomorphism; `D_j(B)` is a
  scalar response depending on the chosen measurable test function.
- Still open: an exact or deterministically certified value for the
  nonzero response integrals; the full conditional function
  `E[S_j|A]`; and a useful relation under a separately motivated
  canonical ambient construction.

## Reproduction

From repository root:

`uv run python .research-scratch/fraser_structural_geometry/20261004-161700-shape-response/shape_response.py`

Environment: Python 3.14.6 and NumPy 2.5.3. The project computational
preflight had passed earlier in this session. Existing exact normal
curvature calculation was reproduced with:

`uv run python research-scratch/fraser_structural_geometry/20261004-fraser-fm34-bridge/codim2_curvature.py`

It returned the displayed exact matrix and all nine exact moment/positivity
checks true. The two routines share the project Python/NumPy/SymPy
environment; this is reproduction, not an independent implementation.

## Literature record (2026-10-04)

The local catalog was queried before external searching for `ancillary` and
`logistic`; it returned no items. Independent, question-driven searches:

- arXiv `all:"ancillary statistic" AND all:"score function" AND all:conditional`:
  12 results; inspected result titles were mostly unrelated conditional
  inference work. No direct ancillary/shape-score/Fisher-normal result
  was identified in this query.
- arXiv `all:"shape derivative" AND all:ancillary AND all:Fisher`: 0
  results.
- arXiv `all:ancillary AND all:"normal curvature" AND all:statistical`:
  broad query returned 512 results; top results included Fraser et al.,
  arXiv:1011.5779, which concerns sample-space ancillary contours but not
  Fisher-normal curvature.
- Candidate-specific arXiv query `all:logistic AND all:ancillary AND
  all:"shape tilt"`: 0 results.
- SpringerLink searches for `ancillary statistic conditional score shape
  perturbation Fisher geometry`, `ancillary normal curvature holonomy
  statistical manifold`, and the candidate-specific logistic shape-tilt
  query returned HTTP 406. SIAM searches for the same three query families
  returned HTTP 403. No access controls were bypassed.

The local bibliography route was then checked against
`connection-bridge.md` (sections 2, 4, 5, and 7), `calculation-results.md`
(sections “Second fundamental form” and “Ancillary distribution response
to shape”), `integrable-structural-nonflat-normal.md` (“Exact normal
connection and curvature”), and the Fraser/TEM references in `tem.md`.
Fraser, Fraser, and Staicu, “Second Order Ancillary: A Differential View
from Continuity,” arXiv:1011.5779v1, Section 1, was inspected at
https://arxiv.org/html/1011.5779v1. It supports the distinction between
exact ancillaries and approximate sample-space contours, not a
normal-curvature identity. Relevant title/author searches at SpringerLink
and SIAM remained inaccessible; the local files contain no verified
primary source establishing the proposed ancillary/normal-curvature
relationship. Literature review is `incomplete`; no novelty claim is made.

## Best next discriminating step

Compute or rigorously bound `E[S_j|A]` as a function on the normalized
residual configuration space for the same `n=4` model. An exact
conditional-score function would distinguish response of these two test
functionals from the full ancillary-distribution derivative. Any further
comparison with normal curvature must fix an explicit, motivated pairing
between that function and a normal-bundle quantity; the present model
provides no canonical pairing.
