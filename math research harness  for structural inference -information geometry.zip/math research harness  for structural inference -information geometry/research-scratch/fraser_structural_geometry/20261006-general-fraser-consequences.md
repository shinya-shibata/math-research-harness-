# General Fraser consequences: what is actually justified

Date: 2026-10-06
Agent: GitHub Copilot in VS Code
Scope: bounded boundary statement for the general Fraser theory candidate.
Status: `open` as a theorem; `proved/agent` for the negative boundary only.

## The only general consequences presently justified

The records support the following general statements, each under the stated
regularity conditions for the model under discussion:

1. If a smooth structural pushforward `F_beta` induces a regular density family
   `p_beta`, then the continuity equation
   `partial_a p_beta + div(p_beta v_a) = 0`
   gives the score-transport identity for the induced score field. This is a
   structural identity of the transported density, not a theorem about a
   canonical ambient normal connection.

2. Exact ancillarity is a conditional distribution statement, e.g.
   `E[s | A] = 0` under the relevant regularity assumptions (or the exact
   parameter-free invariance criterion in the chosen model). This does not by
   itself determine a normal bundle or a connection on that bundle.

3. Once a chosen ambient Fisher manifold and an immersion are fixed, the
   second fundamental form and normal connection are defined, and the affine
   identity
   `H^(alpha) = H^(0) - alpha * Pi_N(T^sharp|_{TS x TS}) / 2`
   is a valid conditional formula under the stated convention. This identity
   does not create a universal bridge from a structural law to a uniquely
   selected ambient normal geometry.

4. Structural integrability (`F=0`, or involutivity of the sample-space
   structural distribution) is a property of the selected structural fields in
   the chosen sample-space model. It is not equivalent to flatness of an
   ambient normal connection unless the ambient and the connection are fixed in
   advance and a corresponding theorem is proved for that class.

## What is not justified as a general theorem

The current evidence rules out the following unrestricted Fraser-style
statements:

- `F=0 => R_perp^(alpha)=0` as a general theorem.
- `exact ancillary => flat normal transport` as a general theorem.
- `approximate ancillary choice => canonical ambient normal bundle` as a general
  theorem.
- `ancillary response function => curvature tensor` as a general equality.

The reason is direct and model-specific: the codimension-two logistic tilt
constructed in
`research-scratch/fraser_structural_geometry/20261004-fraser-fm34-bridge/integrable-structural-nonflat-normal.md`
exhibits

`[v_mu, v_tau] = v_mu`,

but also

`R_perp,mu,tau^(0) = exp(-tau) * [[0, -28/45], [9/4, 0]] != 0`.

Therefore nonzero normal curvature can coexist with an integrable structural
transport distribution in a fixed ambient model.

## The strongest general claim now available

The strongest responsible statement is a negative boundary theorem:

> A general Fraser theory cannot infer a canonical normal geometry or flat
> holonomy from the structural transport equation or an ancillary law alone.
> To obtain a well-posed curvature/holonomy statement, one must specify the
> ambient statistical manifold, the immersion, the metric, the chosen alpha
> connection, and the class of admissible normal bundles.

This is a theorem boundary, not a proof of an affirmative Fraser-global theory.
The connection between exact or approximate ancillary statistics and the chosen
normal connection still requires extra structure, such as a fixed ambient
extension, a chosen gauge, a projection rule, or a canonical intertwinor.

## The correct positive theorem under fixed ambient + fixed connection

Once those geometric data are fixed, the valid theorem is not a universal Fraser
claim but the following conditional local statement:

> For a fixed ambient manifold `\tilde M`, a fixed immersion `i: M -> \tilde M`,
> a fixed metric and `alpha`-connection, and a fixed metric-orthogonal normal
> bundle `\nu M`, the induced normal connection `\nabla^\perp` is well defined.
> On any contractible coordinate neighborhood, the curvature `R^\perp` governs
> the first nontrivial term of small-loop parallel transport, and therefore
> curvature and infinitesimal holonomy agree to the expected order.

This is the precise positive theorem that remains valid after OP-3.
It is local, conditional, and excludes any global claim unless topology and
bundle selection are added as separate hypotheses.

## Minimal sufficient structure for a positive theorem

A positive theorem would need at least the following ingredients:

1. a fixed ambient model `M_tilde` with a smooth immersion `i: M -> M_tilde`;
2. a regular Fisher metric and a specified alpha-connection on `M_tilde`;
3. a metric-orthogonal normal bundle and a chosen normal projection;
4. a precise class of admissible ancillary or approximate-ancillary score
   directions;
5. a proof that the selected directions remain in the normal bundle and yield a
   smooth, constant-rank normal-frame field;
6. either an exact identity or a controlled approximation theorem relating the
   induced bundle connection to the chosen ancillary statistic.

Without these, the resulting normal curvature is not defined, or it is defined
but gauge-dependent and not canonical.

## Consequence for the research program

The research program should therefore target a conditional theorem of the form:

> For a fixed ambient Fisher metric and a fixed immersion, and under a chosen
> rank-regular approximate-ancillary bundle, the induced alpha-normal connection
> has curvature equal to the projected cubic tensor plus the ambient curvature
> term. In this class, local curvature is meaningful, but global holonomy
> requires extra topological and period control.

This is the correct level of generality for the current evidence. It is not a
statement about all Fraser structural models, and it is not a universal
ancillary-to-holonomy correspondence.
