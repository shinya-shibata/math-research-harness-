# OP-3: general-theory implication language

Date: 2026-10-06
Agent: GitHub Copilot in VS Code
Scope: bounded conversion of the explicit OP-3 model into the language of general Fraser implications.
Status: `open` as a general theorem; `verified-computationally` for the explicit ambient model.

## The correct general language

The explicit OP-3 model establishes the following restriction, not a universal
Fraser theorem:

> For a fixed ambient Fisher manifold and a fixed immersion, structural
> integrability of the sample-space distribution does not imply flatness of the
> induced normal connection. In the codimension-two logistic ambient, the
> structural directions are Frobenius-integrable while the Levi-Civita normal
> connection has nonzero curvature.

A second correct statement is:

> Exact location-scale ancillarity does not by itself determine a canonical
> normal bundle or a canonical normal connection. The same exact ancillary law
> can coexist with different ambient normal geometries, including a flat and a
> nonflat choice for the induced normal connection.

A third correct statement is:

> Local curvature and small-loop transport agree in the explicit model, but a
> nonzero local curvature does not imply a nontrivial full holonomy group in the
> chosen connection. The period contribution depends on the topology of the base
> and on the integral of the connection one-form around the relevant loop.

These three statements are the valid general-language consequences of the OP-3
model. They are strictly weaker than any general Fraser theorem, and they do not
assert a canonical ancillary-to-holonomy correspondence.

## What the OP-3 model does not justify

The following claims remain unjustified as general Fraser statements:

- `F=0 => R_perp^(alpha)=0` for all structural models;
- `exact ancillary => flat normal transport` in all ambient models;
- `approximate ancillary => canonical ambient normal bundle`;
- `local curvature => global nontrivial holonomy` without topology and period
  control.

The reason is that the OP-3 model shows only that one fixed ambient family can
support a nonflat normal connection while the structural distribution is
integrable. This is a counterexample to the naive general implication, not a
replacement for a universal theorem.

## The correct theorem boundary

The strongest justified general statement is therefore:

> A general Fraser theorem must specify the ambient Fisher manifold, the
> immersion, the metric, the chosen alpha-connection, the normal projection, and
> the class of admissible ancillary or approximate-ancillary score directions.
> Without these extra structures, the normal connection is not canonically fixed,
> and the relation between structural integrability, ancillary law, curvature,
> and holonomy cannot be read off from the structural equations alone.

This is the proper general-language translation of the OP-3 investigation.
