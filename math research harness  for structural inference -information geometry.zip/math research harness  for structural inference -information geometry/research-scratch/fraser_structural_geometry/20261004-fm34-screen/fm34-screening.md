# FM-34 Screening: Affine Dependence of the Second Fundamental Form

Date: 2026-10-04 15:09:23 +09:00  
Agent: GitHub Copilot in VS Code; underlying model version not exposed

## Scope

This is a bounded follow-up screen of candidate FM-34 from
`research-scratch/fraser_structural_geometry/20260930-231402/candidates.jsonl`.
It leaves that generated batch, the thread ledger, and the manuscript unchanged.
The literature review is incomplete; this record makes no novelty claim.

## Candidate and assumptions

FM-34 proposes that for an immersion `i:S -> M`, a fixed ambient Fisher metric
`g`, its associated metric normal projection `Pi_N`, and the convention

`nabla^(alpha) = nabla^(0) - alpha*T^sharp/2`,

the ambient-connection second fundamental form

`H^(alpha)(X,Y) = Pi_N(nabla_tilde^(alpha)_(di X) di Y)`

satisfies

`H^(alpha) = H^(0) - alpha*Pi_N(T^sharp(di X,di Y))/2`.

Here `T^sharp` is the ambient vector-valued tensor obtained by raising one
index of the cubic tensor with `g`. The same metric, normal bundle, and
projection must be used for every `alpha`. This is a conditional identity:
an ambient manifold, immersion, and the stated connection family are input
data, not consequences of a structural representation or of non-exponentiality.

## First discriminating test: chart derivation

For any local immersion `f(u)` with coordinate components `f^i`, write
`f_a^i = partial_a f^i` and let `P^i_k` denote the fixed metric projection
onto the normal space. Applying the connection convention and projecting gives

`H^(alpha)i_ab = P^i_k*(partial_a partial_b f^k
  + Gamma^(0)k_lm*f_a^l*f_b^m)
  - alpha/2*P^i_k*T^sharpk_lm*f_a^l*f_b^m`.

The first parenthesis is `H^(0)`; the last projected tensor is independent of
`alpha`. Thus the proposed identity holds for every smooth model and every
such immersion, including a non-exponential statistical model. No use of
exponential coordinates, a likelihood formula, or a logistic-family
calculation is needed for this implication.

Equivalently, taking `kappa = Pi_N(T^sharp|_{TS x TS})` gives
`H^(alpha) = H^(1) + (1-alpha)*kappa/2`. This is the same affine identity
under the stated convention. Outside the setting where `H^(1)` has the
appropriate canonical-exponential interpretation, it should not automatically
be called Efron curvature.

**Mathematical evidence:** `proved/agent`, conditional on the definitions and
assumptions above. The proposed failure condition is impossible if those
assumptions hold. This establishes an elementary connection-level identity,
not a result about exact ancillaries, normal holonomy, or Fraser's structural
equation.

**Candidate disposition:** `screened`. The original test's particular
two-dimensional logistic submodel was not separately instantiated: the chart
calculation proves the identity without model-specific input. A concrete
logistic example could illustrate the formula but would not discriminate this
claim further.

## Literature review

Search date: 2026-10-04. Queries below were submitted independently to the
named provider search pages; they are not exhaustive searches of those
collections.

### Independent, question-driven pass

| Search family | Query | arXiv | SpringerLink | SIAM |
|---|---|---|---|---|
| Exact claim | `nonexponential alpha connection second fundamental form affine exact claim` | Page returned no results. | Fetch failed with HTTP 406; no result page inspected. | Fetch failed with HTTP 403; no result page inspected. |
| Terminology | `nonexponential alpha connection second fundamental form affine alternate terminology structural inference` | Page returned no results. | Fetch failed with HTTP 406; no result page inspected. | Fetch failed with HTTP 403; no result page inspected. |
| Contrary result | `nonexponential alpha connection second fundamental form affine contrary result counterexample obstruction` | Page returned no results. | Fetch failed with HTTP 406; no result page inspected. | Fetch failed with HTTP 403; no result page inspected. |

Additional arXiv query, `information geometry statistical submanifold alpha
connections second fundamental form`, returned no results. A separate
`alpha-connection statistical manifold submanifold` query also returned no
results. These are search-page outcomes only, not proof that no relevant
literature exists.

### Local-reference route, after the independent pass

The local catalog was checked first with:

- `uv run python tools/reference_lookup.py --author "Amari" --json` — empty
  result.
- `uv run python tools/reference_lookup.py --title "Methods of Information Geometry" --json`
  — empty result.

Relevant bibliography seeds were then taken from
`ancillary_holonomy_paper_revised_md.md`, sections 2–3 and its references
(Amari & Nagaoka, 2000, *Methods of Information Geometry*; Efron, 1975,
“Defining the curvature of a statistical problem”), and `tem.md`, references
(Amari & Nagaoka, 2000). The title/author searches were submitted to all three
providers:

| Local seed and derived query | arXiv | SpringerLink | SIAM |
|---|---|---|---|
| Amari & Nagaoka (2000), `Methods of Information Geometry Amari Nagaoka` | Page returned no results. | HTTP 406; no result page inspected. | HTTP 403; no result page inspected. |
| Efron (1975), `Defining the curvature of a statistical problem Efron` | Page returned no results. | HTTP 406; no result page inspected. | HTTP 403; no result page inspected. |

No primary source was inspected and no backward/forward citation closure was
completed. SpringerLink and SIAM coverage is unavailable in this run.
Accordingly, the literature review and novelty assessment remain
**incomplete**; no `proved/literature` or “no match” conclusion is warranted.

## Remaining ambiguity and next step

The identity is settled at the conditional algebraic level. To test a
substantive extension beyond that identity, one would need a separately
specified non-exponential ambient statistical family and immersion, then
compute its `H^(0)` and projected cubic tensor. That is not needed to establish
FM-34 and is outside this screen. Literature follow-up should retry the
unavailable provider searches and inspect primary sources before making any
novelty or source-equivalence assessment.
