# Conditional ancillary score and Fisher-normal response

Date: 2026-10-04 16:23:49
Agent: GitHub Copilot in VS Code; underlying model version not exposed
Status: bounded model-specific result; literature review incomplete

Sign-structure investigation update: 2026-10-04 16:50:28 +09:00
Agent: GitHub Copilot in VS Code; underlying model version not exposed

Normal-holonomy investigation update: 2026-10-04 16:55:08 +09:00
Agent: GitHub Copilot in VS Code; underlying model version not exposed

Intrinsic ancillary-connection investigation update: 2026-10-04 17:01:57 +09:00
Agent: GitHub Copilot in VS Code; underlying model version not exposed

Fraser-contour / alpha-normal-geometry update: 2026-10-04 17:06:36 +09:00
Agent: GitHub Copilot in VS Code; underlying model version not exposed

Contour-jet / alpha-curvature identifiability update: 2026-10-04 17:11:36 +09:00
Agent: GitHub Copilot in VS Code; underlying model version not exposed

Structural-transport selection-rule update: 2026-10-04 17:17:39 +09:00
Agent: GitHub Copilot in VS Code; underlying model version not exposed

## Question

Continue the four-observation, codimension-two logistic-tilt investigation by
(i) characterizing the full conditional shape score given the exact
location-scale ancillary, (ii) giving a canonical relation between
distributional ancillary response and normal score directions, and
(iii) testing whether that relation determines normal curvature.

The ambient and statistic are fixed as in
`20261004-161946-ambient-ancillary-response.md` and
`20261004-fraser-fm34-bridge/connection-bridge.md`. No canonical ledger or
paper is changed.

## Exact conditional-score formula

For one observation `Y=tanh(U/2) ~ Uniform(-1,1)`, the base error density
is the standard logistic density

`f(u)=1/(4*cosh(u/2)^2)`.

For a sample `U=(U_1,...,U_4)`, write

`m=(U_1+...+U_4)/4`,
`r=||U-m*1|| > 0`,
`a=(U-m*1)/r`.

Then `sum_i a_i=0`, `sum_i a_i^2=1`; hence `a` lies on the unit sphere
`S^2` in the three-dimensional subspace `1^perp`. The event `r=0` has
probability zero. Orthogonal center/radius/sphere coordinates have
Lebesgue volume element equal to a constant times `r^2 dm dr d sigma(a)`.
The constant cancels from conditional densities.

For `j=1,2`, put

`h1(y)=y^3-3y/5`,
`h2(y)=y^4-14y^2/15+1/9`,
`H_j(m,r,a)=sum_(i=1)^4 h_j(tanh((m+r*a_i)/2))`,
`W(m,r,a)=r^2 * product_(i=1)^4 f(m+r*a_i)`.

The full conditional score given the ancillary `A=a` is therefore the
following exact function (defined wherever the denominator is finite and
positive):

`J_j(a) = E[S_j | A=a]
        = integral_(r>0,m in R) W(m,r,a)*H_j(m,r,a) dm dr
          / integral_(r>0,m in R) W(m,r,a) dm dr`.

This is not merely a moment identity: it specifies a version of the
conditional score on the ancillary sphere by two absolutely convergent
integrals wherever the denominator is finite. Since `|H_j|` is bounded,
the numerator is absolutely dominated by a constant times the
denominator. The denominator is positive, and it is finite for
`P_A`-almost every `a`, because its integral over the sphere is finite.
Conditional expectations are only defined up to `P_A`-null sets. The
formula gives a route to deterministic quadrature at selected ancillary
values; it does not provide a closed elementary expression for `J_j(a)`.

For every bounded measurable `B` on the sphere,

`partial_(k_j) E_k[B(A)]|_(k=0) = E_0[B(A) J_j(A)]`.

Thus the full derivative of the pushforward law of `A` is represented by
the signed density `J_j` relative to its base law. In particular, the
distribution of `A` is locally insensitive to direction `k_j` at the
base point iff `J_j=0` almost surely. It is invariant along a finite
shape path only if the analogous conditional-score vanishing holds at
every point of that path (with regularity permitting integration).

## Canonical score-projection map

At a fixed base point, let `N` be the Fisher-orthogonal normal space to the
location-scale tangent space. For `xi in N`, let `s_xi` be its ambient
score. Define

`J_A : N -> L^2_0(P_A)`,
`J_A(xi)=E[s_xi | sigma(A)]`.

Here `L^2_0(P_A)` is the space of square-integrable, mean-zero functions
of the ancillary under its base distribution. This map is linear and
canonical once the ambient model, base point, Fisher metric, and statistic
`A` are fixed. The conditional-score identity says that, for every
bounded `B(A)`,

`D_xi E[B(A)] = <B-E B, J_A(xi)>_(L2(P_A))`.

Conditional expectation is an orthogonal projection in `L^2(P)`, so

`||J_A(xi)||^2_(L2(P_A)) <= E[s_xi^2] = ||xi||^2_Fisher`.

Consequently

`I_A(xi,xi) := ||J_A(xi)||^2_(L2(P_A))`

is the Fisher information about that shape perturbation retained by the
distribution of `A`; it is positive semidefinite and bounded above by the
ambient Fisher information. It vanishes exactly when the ancillary law
has zero first derivative in that direction. This is a canonical
ancillary-to-normal **score** relation, but it does not use the normal
connection or curvature.

## Pointwise conditional-score evaluation

At the generic unit direction

`a=(-6,-1,2,5)/sqrt(66)`,

nested SciPy `quad_vec` integration in `m` and `r`, after correcting the
log-density implementation to
`log f(u)=u-2*logaddexp(0,u)`, returned

`J_1(a) ~= -0.0686328366`,
`J_2(a) ~= -0.00522798745`.

At tolerances `1e-7` and `2e-9`, the estimates were
`(-0.0686328365,-0.00522798735)` and
`(-0.0686328366,-0.00522798745)`. At the opposite direction `-a`, the
tighter run returned `(0.0686328366,-0.00522798745)`, in agreement with
the exact parity `J_1(-a)=-J_1(a)`, `J_2(-a)=J_2(a)`.

The original exploratory script used an incorrect logistic log-density
expression and its earlier point values were wrong; those values are
superseded here. The corrected adaptive calculation is still only a
sanity check: its outer error estimate does not include accumulated inner
quadrature error. The rigorous pointwise result is recorded below.

## Validated interval enclosure at the representative point

The ratio was enclosed using `python-flint` Arb ball arithmetic
(`python-flint 0.9.0`, 128-bit midpoint precision). The domain was split
into dyadic rectangles of width `1/8` on `[-16,16] x [0,48]`. For each
rectangle, the integral was enclosed by its midpoint value plus the
two-dimensional midpoint-rule remainder. The remainder used Arb interval
enclosures of the pure second derivatives and the bound

`area*(width_m^2*sup|F_mm| + width_r^2*sup|F_rr|)/24`,

obtained by applying the one-dimensional midpoint error bound successively
in the two coordinates. The integrands were `W`, `W*H_1`, and `W*H_2`.
The derivative enclosures include the exact derivatives of the logistic
density and of both shape polynomials.

Both omitted tails were bounded analytically, using a bound uniform over
all centered unit directions `a`. For `x=m*1+r*a`,
`||x||_1 >= |sum_i x_i|=4|m|` and
`||x||_1 >= ||x||_2 >= r`. Hence
`sum_i |m+r*a_i| >= 2|m|+r/2`. Since `f(u)<=exp(-|u|)`,

`integral_outside W <= exp(-2M)*16`
`                  + exp(-R/2)*(2R^2+8R+16)`,

with `M=16`, `R=48`. Arb enclosed this denominator tail by
`1.890589406041461e-7`. The numerator tails use
`|H_1|<=8/5` and `|H_2|<=32/45`.

The resulting outward-rounded conditional-score enclosures are

`-0.070805 <= J_1(a) <= -0.066469`,
`-0.007068 <= J_2(a) <= -0.003396`.

In particular, both scores are rigorously negative at this selected point.
The midpoint sums were respectively `0.03925380780950317`,
`-0.002694100178571631`, and `-0.000205218414570428` for denominator,
first numerator, and second numerator; their finite-rectangle absolute
error bounds were `8.436784e-5`, `7.898189e-5`, and `7.148090e-5`.
The denominator enclosure excludes zero. The corrected adaptive values
above lie inside the Arb ratio enclosures and serve only as an independent
numerical sanity check, not as the certificate.

This certifies only the two values at the stated direction and model. It
does not certify a global sign or a curvature identity.

## Exact symmetry and finite-scope lower bounds

The parity statements from the preceding card extend to the full
conditional score:

`J_1(-a)=-J_1(a)`,
`J_2(-a)= J_2(a)`.

Indeed `W(m,r,-a)=W(-m,r,a)` after substituting `m -> -m`, while `h1`
is odd and `h2` is even. This implies exactly
`E[B3(A)J_2(A)]=0` and `E[B4(A)J_1(A)]=0`, where
`B3=sum_i a_i^3` and `B4=sum_i a_i^4`.

Use the preceding seeded PCG64 run (`2,000,000` draws, seed `20261004`)
and its joint 99% Hoeffding-Bonferroni intervals. Because `E[B3]=0` and
`|B3|<=1`, Cauchy-Schwarz implies

`||J_1||_(L2(P_A)) >= |E[B3 J_1]| > 0.03824`

at the stated simultaneous confidence level under the ideal-iid
interpretation of that run.

Since `1/4 <= B4 <= 1`, its standard deviation is at most `3/8`.
Therefore

`||J_2||_(L2(P_A))
 >= |E[(B4-E B4)J_2]| / ||B4-E B4||_2
 >= (8/3)*|E[B4 J_2]|
 > 0.00254`

at the same confidence level, again conditional on the ideal independent
sampling model. These are probabilistic finite-computation lower bounds,
not exact integral proofs and not deterministic quadrature certificates.
The off-diagonal zero moments are exact by parity.

For the four-observation model, the two normal score norms are exactly

`||S_1||_2=sqrt(16/175)`,
`||S_2||_2=sqrt(256/10125)`.

Thus the simulation suggests that a strictly positive, but small, fraction
of shape Fisher information is visible in the ancillary distribution for
each direction. No global claim is made beyond this selected model and
statistic.

## Curvature comparison

The one-shape ambient obtained by restricting to `k2=0` has the same base
model, the same statistic `A`, and the same direction `h1`. The score
`S_1` and thus the entire function `J_1(a)` are exactly the same under
that restriction. The earlier exact calculation gives zero normal
curvature for the one-shape ambient for all alpha. In the two-shape
ambient, the exact calculation gives

`R_perp,mu,tau^(0) = exp(-tau)*[[0,-28/45],[9/4,0]] != 0`.

Therefore the same ancillary and same selected normal score response
`J_1` occur with different normal curvature, solely by changing the
ambient extension with an additional shape direction. This refutes a
rule that the ancillary's `k1` score-response function, or its tested
scalar moment, determines whether normal transport is flat independent
of the ambient.

What is established at this stage is a local response map `J_A`, not an
ambient-independent curvature map. Curvature differentiates the normal
connection and records its noncommutativity/holonomy; `J_A` is a
conditional projection of scores onto functions of a chosen statistic.
The model-specific connection comparison, after fixing the ancillary
Hilbert bundle and its natural flat connection, is given in
“Ancillary score marking and normal holonomy in the fixed ambient”
below. Ancillary response alone still does not determine curvature
independently of the ambient normal connection.

## Evidence status and remaining work

- Exact conditional integral representation for `J_j(a)`: `proved/agent`
  by the center/radius/polar-coordinate change of variables and the score
  identity.
- Orthogonal projection contraction
  `||J_A(xi)||_2 <= ||s_xi||_2`: `proved/agent`.
- Full parity relations for `J_1,J_2`: `proved/agent`.
- Positive lower bounds on `||J_1||` and `||J_2||`: `verified-computationally`
  only for this `n=4` model, seed, sample count, bounded integrands,
  and stated simultaneous Hoeffding coverage under the ideal-iid
  interpretation; not exact-sign proofs.
- Same `J_1` with zero versus nonzero ambient normal curvature:
  `proved/agent` for the two explicit ambient extensions, since their
  restricted `k1` model and score agree identically while the existing
  exact curvature calculations differ.
- General relationship between `J_A` and normal curvature:
  `open`; ambient-independent determination is refuted by the comparison.
- `J_1` and `J_2` at `a=(-6,-1,2,5)/sqrt(66)`: `verified-computationally`
  by the specified Arb interval enclosure, including both tails and a
  certified denominator lower bound. This does not extend to other `a`.
- `J_2` is sign-changing on the full ancillary sphere, with nonempty open
  positive and negative regions and a zero on the stated path:
  `proved/agent`, using continuity, full support, exact symmetries, and
  the verified Arb witness intervals. The location and topology of the
  complete nodal set and the full chamber sign regions remain open.
- The result is not `proved/owner-checked`; no ledger or manuscript
  update is authorized here.

## Reproduction

Shape-response calculation:

`uv run python .research-scratch/fraser_structural_geometry/20261004-161700-shape-response/shape_response.py`

Pointwise conditional-score quadrature:

`uv run python .research-scratch/fraser_structural_geometry/20261004-161700-shape-response/conditional_score_quad.py`

Validated Arb enclosure, exact invocation:

`uv run --with python-flint python .research-scratch/fraser_structural_geometry/20261004-161700-shape-response/certify_conditional_score.py --step-power 3 --m-limit 16 --r-limit 48`

This invocation used Python 3.14.6, `python-flint 0.9.0`, Arb ball
arithmetic at 128-bit midpoint precision, and no changed dependency
manifest. The certificate is reproducible from the script and the
specified finite partition and analytic tail formula. The run date was
2026-10-04; no machine-readable artifact was retained.

The other certified direction invocations were:

`uv run --with python-flint python .research-scratch/fraser_structural_geometry/20261004-161700-shape-response/certify_conditional_score.py --step-power 3 --m-limit 16 --r-limit 48 --direction -3,1,1,1`

`uv run --with python-flint python .research-scratch/fraser_structural_geometry/20261004-161700-shape-response/certify_conditional_score.py --step-power 4 --m-limit 16 --r-limit 48 --direction -31,-1,16,16`

`uv run --with python-flint python .research-scratch/fraser_structural_geometry/20261004-161700-shape-response/certify_conditional_score.py --step-power 4 --m-limit 16 --r-limit 48 --direction -15,-1,8,8`

All used the same uniform analytic tail estimate and Arb interval
remainder. No dependency manifest was changed.

## Global sign structure of `J_2`

The direction domain is the unit sphere in `1^perp`. For every direction,
the denominator and numerator defining `J_2` are finite, and the
denominator is strictly positive. To see uniform integrability, set
`x=m*1+r*a`. Then `||x||_1 >= 4|m|` and
`||x||_1 >= ||x||_2 >= r`, so
`W(m,r,a) <= r^2*exp(-2|m|-r/2)` for every centered unit `a`.
Since `H_2` is bounded, dominated convergence makes both integrals
continuous in `a`; their ratio `J_2` is continuous as well.

The base ancillary law has density proportional to the positive
denominator with respect to surface measure. It therefore has full
sphere support. Also,

`E[J_2(A)] = E[S_2] = 4*E[h_2(Y)] = 0`,

where `Y` is uniform on `[-1,1]` and
`h_2(y)=y^4-14*y^2/15+1/9` has mean zero. Direct symmetries give
`J_2(-a)=J_2(a)` and invariance under every coordinate permutation.
Thus the sign pattern is determined on the ordered chamber
`a_1<=a_2<=a_3<=a_4`, and replicated by these symmetries.

Two interval-certified points in that chamber have opposite signs:

- At `a=(-3,1,1,1)/sqrt(12)`,
  `0.0500479 < J_2(a) < 0.0556564`.
- At `a=(-6,-1,2,5)/sqrt(66)`,
  `-0.0070676 < J_2(a) < -0.0033962`.

Consequently `{J_2>0}` and `{J_2<0}` are nonempty open sets, each of
positive ancillary probability. The zero set is nonempty. A narrower
certified crossing follows along the path

`a(t)=((1-t)*(-3,1,1,1)+t*(-1,-1,1,1)) / norm(...)`.

At `t=17/32`, the direction is proportional to
`(-31,-1,16,16)` and Arb gives
`0.0025873 < J_2(a(t)) < 0.0032141`. At `t=9/16`, it is proportional
to `(-15,-1,8,8)` and
`-0.0034484 < J_2(a(t)) < -0.0028274`. Continuity therefore gives at
least one zero for `17/32 < t < 9/16`. These intervals were computed
with the same uniform tail bound and Arb method; the two path endpoints
used cell width `1/16`, the other witnesses width `1/8`.

This resolves the global sign question in the sense that `J_2` is
sign-changing, not of one weak sign. The exact location, number, and
topology of its zero curves and the complete positive/negative regions
inside the symmetry chamber remain open. Numerical quadrature suggests
the path crossing is near `t=0.54`, but that location is not certified.
The sign result itself asserts no curvature relation; the fixed-ambient
comparison is given below.

Exact codimension-two curvature:

`uv run python research-scratch/fraser_structural_geometry/20261004-fraser-fm34-bridge/codim2_curvature.py`

Backend preflight passed on Python 3.14.6, SymPy 1.14.0, NumPy 2.5.3,
and SciPy 1.18.1. The response script uses double-precision NumPy
PCG64 Monte Carlo; the curvature script uses exact rational SymPy
integration. No independent second implementation was run.

## Literature record (2026-10-04)

Before external discovery, local catalog queries for `Fisher information`,
literal `conditional score`, and `ancillary` returned no matches.
Independent question-driven arXiv API searches included:

- `all:"conditional expectation of the score" AND all:statistic`:
  163,825 broad results; the first returned items were unrelated, so the
  search did not isolate a relevant primary source.
- `all:"Fisher information" AND all:statistic AND all:score AND
  all:conditional AND all:expectation AND all:data AND all:processing`:
  broad search syntax returned mostly unrelated items; no directly
  relevant source was certified.
- `all:ancillary AND all:score AND all:projection AND all:curvature AND
  all:normal AND all:bundle`: broad results included the Fraser
  second-order ancillary paper but no identified normal-score projection
  theorem.
- `all:"shape derivative" AND all:ancillary AND all:Fisher`: 0 results.

SpringerLink searches for “conditional expectation of the score Fisher
information statistic” and “ancillary score projection normal curvature
bundle” returned HTTP 406. SIAM searches for the same exact/neighboring
query families returned HTTP 403. These provider failures were not
bypassed. After the independent searches, local discovery seeds were
`connection-bridge.md` (section 2, exact ancillary score criterion),
`calculation-results.md` (sections “Second fundamental form” and
“Ancillary distribution response to shape”), and `tem.md` (Fraser/TEM
references). The local cited Fraser, Fraser, and Staicu source,
“Second Order Ancillary: A Differential View from Continuity,”
arXiv:1011.5779v1, Section 1, was already inspected at
https://arxiv.org/html/1011.5779v1; it treats exact ancillaries and
approximate sample-space contours, not the present Fisher projection
operator or a normal-curvature relation. No exact primary source for
the operator statement was certified. Literature status is `incomplete`;
no novelty claim is made.

## Ancillary score marking and normal holonomy in the fixed ambient

Fix the two-shape, four-observation logistic ambient from
`20261004-fraser-fm34-bridge/integrable-structural-nonflat-normal.md`,
its location-scale submanifold `S`, and its exact ancillary `A`. This
section uses the Levi-Civita normal connection (`alpha=0`) and makes no
claim across ambient extensions.

For each `p=(mu,tau)` in `S`, let
`H_p=L^2_0(P_A)` be the mean-zero square-integrable functions of `A`.
The ancillary law is exactly independent of `p`; hence these fibers form
the constant Hilbert bundle `H=S x H_0` with its natural flat connection
`d`. Let `E=N S` be the rank-two Fisher normal bundle and define the
conditional-score marking

`J_p:E_p -> H_0`,
`J_p(xi)=E_p[s_xi | A]`.

For the coordinate normal frame `e_j=partial_(k_j)`,
`J(e_j)=J_j(A)`. These two functions do not depend on `mu` or `tau`,
because the standardized errors have a fixed law and `A` is invariant
under location-scale transformations.

The map `J_p` is injective at every `p`. Indeed, `J_1,J_2` are continuous,
the base ancillary law has full sphere support, `J_1` is odd and `J_2`
is even under `a -> -a`, and the certified intervals at
`a_0=(-6,-1,2,5)/sqrt(66)` exclude zero for both values. If
`c_1J_1+c_2J_2=0` in `H_0`, continuity and full support make this
identity pointwise. Evaluating at `a_0` and `-a_0` then gives
`c_1=c_2=0`.

This provides a precise, model-specific connection to normal geometry:
the two-dimensional span `V=span{J_1,J_2}` in the ancillary score
Hilbert space faithfully marks the normal fibers. Transporting the
normal connection through `J` defines a connection on the fixed vector
space `V` by

`nabla^J_X(J xi)=J(nabla_perp^(0)_X xi)`.

In the constant basis `(J_1,J_2)`, it has the same connection matrices
as the normal frame:

`omega_mu^J = exp(-tau)*[[0,-28/45],[9/4,0]]`,
`omega_tau^J = 0`.

Thus

`R^J_(mu,tau) = exp(-tau)*[[0,-28/45],[9/4,0]] != 0`,

and normal holonomy acts faithfully on the marked score plane `V`.
For example, parallel transport around a sufficiently small oriented
rectangle in the `(mu,tau)` plane changes which linear combination of
`J_1,J_2` marks a transported normal direction; its leading holonomy
term is the displayed curvature matrix times the signed area, up to the
parallel-transport sign convention.

This is **not** curvature of the ancillary law or of its natural Hilbert
bundle: that bundle is constant and flat because `P_A` does not vary on
`S`. The transported connection `nabla^J` is imported from the chosen
ambient normal connection. In particular, `J` is not parallel from the
normal bundle to the natural flat ancillary bundle. In the convention
`nabla_perp e_j=e_i omega^i_j`,

`(nabla^Hom_mu J)(e_1)=-(9/4)exp(-tau)*J_2`,
`(nabla^Hom_mu J)(e_2)= +(28/45)exp(-tau)*J_1`,
`nabla^Hom_tau J=0`.

The no-go statement is exact: if this injective `J` were parallel into
the natural flat bundle, curvature compatibility would imply
`J R_perp=R^H J=0`; injectivity would force `R_perp=0`, contradicting
the displayed exact curvature. So the ancillary score plane can
faithfully *represent* normal holonomy after transporting the chosen
normal connection, but the ancillary distribution alone does not
select that connection and does not have this holonomy.

### The connection determined by the score plane itself

There is a different, canonical construction which does not import the
normal connection. Let `S` be connected, let an exact ancillary have
constant law `Q`, and put `H=L^2_0(Q)` with its constant flat connection
`d`. For a chosen ambient and immersion, suppose the conditional-normal-
score maps `J_p:E_p -> H` vary smoothly and have constant rank. Their
images `V_p=im(J_p)` form a subbundle `V` of `S x H`. Orthogonal
projection in `H` defines

`nabla^A_X v = Pi_V(d_X v)`, for sections `v` of `V`.

This is the connection induced by the movement of the conditional-score
plane. It is basis-independent and metric-compatible with the metric on
`V` inherited from `H`. If `J` is injective, it pulls back to a
connection on the normal bundle; if not, it exists only on the score
image (or a suitable constant-rank quotient), not on all normal
directions.

Let `B_X:V -> V^perp` be the second fundamental form of the subbundle
`V` in the flat Hilbert bundle, defined by
`d_X v=nabla^A_X v+B_X v`. Flatness of `d` gives the exact Gauss
identity

`R^A(X,Y)=B_X^* B_Y-B_Y^* B_X`.

Thus there is a genuine curvature canonically induced by variation of
the ancillary score subspace. It measures rotation of that subspace
inside `L^2_0(Q)`. It is not, in general, Fisher-normal curvature.
When `J` is injective, let `nabla^J=J^{-1}nabla^A J` and
`C=nabla_perp^(0)-nabla^J`. The two connections satisfy

`R_perp^(0)=R^J+d^(nabla^J)C+C wedge C`.

Consequently, identifying their curvatures requires the additional
compatibility condition `C=0`, or other independently justified data
that determine `C`. Exact ancillarity alone supplies neither.

In the two-shape logistic ambient above, both `J_1` and `J_2` are
independent of `(mu,tau)`, so `V` is a fixed plane in `H` and
`nabla^A` is flat: `R^A=0`. The normal connection is nevertheless
nonflat, with
`R_perp^(0)=exp(-tau)*[[0,-28/45],[9/4,0]]`. Here `nabla^J` is the
trivial connection in the fixed basis `(J_1,J_2)`, and `C` is exactly
the displayed nonzero normal connection one-form. This separates the
score-plane connection from the imported-normal-connection
construction in the preceding subsection.

### Same ancillary law, rank-two normal bundles, different curvature

The ambient dependence can be shown while keeping normal rank two in
both examples. Example I is the two-shape logistic ambient already
defined above; its submanifold is `k_1=k_2=0`, and its ancillary is
`A=A(X)`. Its normal rank is two and its Levi-Civita normal curvature
is the nonzero matrix above.

For Example II, take independent pairs `(X_i,Z_i)`, `i=1,...,4`, and
the four-parameter product family

`p(x,z;mu,tau,kappa,eta)
 = p_logistic-tilt(x;mu,tau,kappa) * phi(z-eta)`,

where `p_logistic-tilt` is the existing one-shape (`h_1`) logistic
ambient and `phi` is the standard normal density. Let
`S` again be `kappa=eta=0` and use the same statistic `A(X)` based only
on the four `X_i`. On `S`, its distribution is exactly the same as in
Example I, and it is ancillary for `(mu,tau)`. The model is regular:
the normal shape score is orthogonal to the location-scale scores by
the existing moment checks, while the independent Gaussian location
score is orthogonal to the entire logistic block and has positive
Fisher norm. Its codimension is also two.

The ambient Fisher metric and Levi-Civita connection are product
geometries. The `kappa` normal line has the existing one-shape
connection `omega=0` at `alpha=0`; the independent Gaussian normal
line has a constant metric and zero connection. There is no mixing
between the factors. Hence Example II has
`R_perp^(0)=0`.

The ancillary law is identical in the two examples, and both have
codimension-two regular ambients, yet the normal curvature is zero in
Example II and nonzero in Example I. This proves that no rule depending
only on the exact ancillary distribution on `S` can recover or determine
the ambient Fisher-normal curvature. The normal score marking also
records why the score-plane construction cannot always repair this:
in Example II, `J(e_eta)=E[Z|A]=0`, so `J` has a kernel and does not
identify the full rank-two normal bundle.

### Evidence and limits

- `J_p` is a well-defined continuous, fiberwise injective marking in
  this fixed model: `proved/agent`, using the conditional-score formula,
  uniform domination, exact parity, full support, and the Arb-certified
  nonzero values at `a_0`.
- The natural ancillary Hilbert bundle over `S` is flat:
  `proved/agent`, since `P_A` is constant over `S`.
- The transported connection on `V` has the stated nonzero curvature:
  `proved/agent` from the exact normal-connection matrix in
  `integrable-structural-nonflat-normal.md` and the fiberwise injection
  of `J`. Existing verification is
  `uv run python research-scratch/fraser_structural_geometry/20261004-fraser-fm34-bridge/codim2_curvature.py`
  with exact SymPy rational arithmetic.
- The score-plane-induced connection `nabla^A` and its Gauss identity:
  `proved/agent` under the stated smooth constant-rank assumptions, by
  orthogonal projection of the flat Hilbert connection.
- `nabla^A` is flat while the two-shape Fisher-normal connection is
  curved: `proved/agent` for the fixed logistic model, since `J_1,J_2`
  are constant over `S` and the normal curvature matrix is exactly
  nonzero.
- Same exact ancillary law and codimension two with zero versus nonzero
  normal curvature: `proved/agent` for Examples I and II, from the
  product decomposition and previously verified one-/two-shape
  curvature calculations.
- This is not an ambient-independent theorem, not an equality between
  ancillary-law curvature and normal curvature, and not a theorem that
  the statistic `A` uniquely selects normal directions. The intrinsic
  score-plane connection measures movement of conditional-score
  subspaces; the imported connection represents the chosen normal
  transport. They agree only under extra compatibility.
- Literature review remains `incomplete`; no priority or novelty claim
  is made.

### Literature search record for this link (2026-10-04)

Question-driven arXiv API query families were:

- `all:ancillary AND all:"normal connection" AND all:Fisher` (0 hits);
- `all:"conditional score" AND all:"normal bundle" AND all:curvature`
  (0 hits);
- `all:"statistical manifold" AND all:ancillary AND all:holonomy`
  (0 hits);
- neighboring terminology:
  `all:"Fisher information" AND all:"conditional expectation" AND
  all:score AND all:statistic` (1 displayed result,
  arXiv:2103.02755v2, unrelated mixture of Markov jump processes);
- `all:pushforward AND all:ancillary AND all:score` (0 hits);
- `all:"Fisher metric" AND all:"normal curvature" AND all:statistical`
  (0 hits).

SpringerLink focused searches for conditional ancillary-score/normal
curvature, statistical-manifold normal bundle/ancillarity, and
conditional-score pushforward all returned HTTP 406. SIAM searches for
the corresponding conditional-score/normal-connection, Fisher normal
bundle, and ancillary pushforward topics all returned HTTP 403. These
access failures were not bypassed.

After that independent pass, local bibliography discovery used `tem.md`
sections 1 and 4 and its references: Amari and Nagaoka (2000), Fraser and
Reid (1995, 2001), Fraser, Reid and Sartori (2016), Efron (1975), and
Skovgaard (1985). Catalog lookups by the first/last authors and exact
Fraser 2010 title found no locally registered records. The prior
identified arXiv source Fraser, Fraser and Staicu, “Second order
ancillary: A differential view from continuity,” arXiv:1011.5779v1,
Section 1, concerns exact/approximate ancillary contours and Frobenius
compatibility; it does not supply the conditional-score marking or its
connection comparison. Exact-title searches for that source at Springer
and SIAM were also blocked as above. Literature coverage is therefore
incomplete.

### Best next discriminating step

The distribution-only reconstruction question is now refuted by
Examples I and II. A remaining, narrower problem is to characterize
which additional assumptions force the score-plane-induced connection
`nabla^A` to coincide with Fisher-normal transport (equivalently, make
`J` parallel), and whether any such assumption is natural in Fraser
ancillary constructions rather than imposed to encode the desired
connection.

### Additional literature search record for the induced connection

Question-driven arXiv API searches on 2026-10-04 used:

- `all:"conditional score" AND all:"normal bundle"` (0 hits);
- `all:ancillary AND all:"induced connection" AND all:curvature`
  (0 hits);
- `all:"Hilbert bundle" AND all:ancillary AND all:statistical`
  (0 hits).

SpringerLink searches with those same three focused query families each
returned HTTP 406. SIAM searches for each returned HTTP 403. No access
controls were bypassed. The local catalog was checked before this pass
for “Second order ancillary” and the keyword “Fisher geometry”; both
returned no records. The subsequently consulted local bibliography was
`tem.md` sections 1 and 4, including Amari–Nagaoka (2000), Fraser–Reid
(1995, 2001), Fraser–Reid–Sartori (2016), Efron (1975), and Skovgaard
(1985). The relevant Fraser et al. arXiv:1011.5779v1 source is discussed
above; it does not establish the score-plane connection identity or
equate it to Fisher-normal transport. Review status remains
`incomplete`; no novelty claim is made.

## Fraser approximate ancillary contours and alpha-normal geometry

### Objects and candidate connection

Fix a regular dominated model `p_theta(y)` with a smooth quantile
representation `y=y(x;theta)` driven by a parameter-free reference
variable `X`. Fraser's observed second-order contour through
`y^0=y(x^0;theta^0)` is the image

`A^0 = { y(x^0;t) : t near theta^0 }`.

Its parameter velocity and acceleration are
`v_a=partial_a y(x^0;theta)` and
`w_ab=partial_a partial_b y(x^0;theta)`. The vector fields' Lie brackets
and their Frobenius residual describe whether the corresponding
sample-space distribution is integrable as an exact contour; Fraser,
Fraser and Staicu show that for vector parameters a contour can retain
second-order ancillary properties even when full Frobenius conditions
fail. This is a statement in sample space and an order-of-approximation
statement.

For a chosen statistical ambient `(M,g,nabla^(alpha))` and an immersion
`i:S -> M`, the alpha second fundamental form is instead

`H^(alpha)(X,Y) = (bar_nabla^(alpha)_X di(Y))^perp`,

and the alpha normal curvature is the curvature of the projected normal
connection `nabla_perp^(alpha)`. The types already differ:
the contour acceleration is sample-space valued, `H^(alpha)` is
normal-bundle valued, and `R_perp^(alpha)` is an
`End(N S)`-valued two-form on parameter space.

### The exact common interface: quantile velocity to score

The quantile map transports the fixed reference law to `p_theta`.
Under differentiation and no-boundary-flux conditions its velocity
satisfies

`partial_a p_theta + div_y(p_theta v_a)=0`,

so the ordinary score is

`s_a = partial_a log p_theta
     = -div_y(v_a) - v_a dot grad_y(log p_theta)`.

This gives an exact interface from Fraser's first-order sample-space
velocity to the Fisher tangent score. The Fisher metric is
`g_ab=E[s_a s_b]`. Differentiating this score with the selected alpha
connection and projecting into a selected ambient normal bundle yields
`H^(alpha)`; differentiating the projected normal connection yields
`R_perp^(alpha)`. These latter steps require the ambient normal score
directions, metric, cubic score tensor and immersion. They are not
determined by the quantile velocity or its contour alone.

In particular, `w_ab` is a second derivative of the quantile map, not
the alpha-covariant derivative of the Fisher tangent score. It may
contribute to the score derivative through the transport equation,
but replacing `H^(alpha)` by a normal projection of `w_ab` would mix
two different connections and is unjustified without an explicit
intertwining theorem.

### Fixed logistic pilot: exact contour, nonzero alpha-normal curvature

For the four-observation location-scale logistic model,

`y(x;z,mu,tau)=mu*1+exp(tau)*z`,

with fixed standardized residual vector `z`, the configuration
`A=(X-mean(X)*1)/||X-mean(X)*1||` is exact ancillary. Its observed
contour is the location-scale orbit generated by

`v_mu=1`, `v_tau=x-mu*1`.

With bracket convention `[V,W]=DW[V]-DV[W]`,
`[v_mu,v_tau]=v_mu`, so the Frobenius residual
`[v_mu,v_tau]-v_mu` is exactly zero. In affine `(mu,sigma)` coordinates
the contour map has zero second derivative; in `tau=log(sigma)`
coordinates its `tau,tau` second derivative is `exp(tau)*z`, as expected
for a coordinate-dependent acceleration. The contour itself and its
Frobenius integrability are independent of alpha and of any ambient
extension.

Now retain the same location-scale model, same quantile map, and same
ancillary, but choose the two-shape logistic ambient
`(mu,tau,k1,k2)` from
`integrable-structural-nonflat-normal.md`. For the convention
`Gamma^(alpha)=Gamma^(0)-alpha*T^sharp/2`, its exact normal
connection matrices in the frame `(partial_k1,partial_k2)` are

`omega_mu^(alpha)=exp(-tau)*
 [[0,-4*alpha/45-28/45],
  [9/4-9*alpha/28,0]]`,

`omega_tau^(alpha)=diag(-alpha/2,-alpha/7)`.

The verified curvature coefficient is

`R_perp,mu,tau^(alpha)=exp(-tau)*
 [[0,-2*alpha^2/63-14*alpha/45-28/45],
  [45*alpha^2/392-9*alpha/8+9/4,0]]`.

At `alpha=0` this is
`exp(-tau)*[[0,-28/45],[9/4,0]]`, which is nonzero, even though the
Fraser contour is exact and its Frobenius residual vanishes. For the
one-shape logistic ambient with the same contour, the Levi-Civita normal
connection is flat. Thus neither exact nor second-order ancillary
contour integrability determines alpha-normal curvature; even holding
the contour and base model fixed, changing the ambient changes the
curvature.

This supplies the sharp model-specific connection currently justified:
the contour velocity determines the tangent score through continuity;
once an ambient is separately chosen, score geometry determines
`H^(alpha)` and `R_perp^(alpha)`. It is a conditional construction, not
a direct identity between Frobenius defect and normal curvature.

### Evidence classification and open bridge

- Quantile-velocity continuity equation and score formula:
  `proved/agent` under the stated smoothness and boundary-flux
  assumptions, by the continuity equation.
- Logistic location-scale contour and zero Frobenius residual:
  `proved/agent` by the displayed affine quantile map and exact bracket.
- Alpha-normal connection/curvature matrices:
  `verified-computationally` by exact SymPy rational algebra using
  `uv run python research-scratch/fraser_structural_geometry/20261004-fraser-fm34-bridge/codim2_curvature.py`.
- No implication from contour Frobenius integrability to
  `R_perp^(alpha)=0`, and no determination from contour data alone:
  `proved/agent` for this pilot and its two ambient extensions.
- A natural extra condition that makes quantile-contour acceleration
  intertwine with the alpha second fundamental form remains `open`.
  A candidate must specify a map from sample-space tangent/acceleration
  data to ambient normal scores, preserve reparameterization behavior,
  and be tested under a change of ambient extension.

### Literature record for Fraser contour / alpha geometry (2026-10-04)

Before local bibliography use, question-driven searches were made.
arXiv API queries:

- `all:"second order ancillary" AND all:Frobenius` returned one source,
  Fraser, Fraser and Staicu, “Second order ancillary: A differential
  view from continuity,” arXiv:1011.5779v1.
- `all:"alpha connection" AND all:ancillary AND all:curvature`
  returned 0 hits.
- `all:"normal curvature" AND all:ancillary AND all:statistical`
  returned 0 hits.

The arXiv HTML primary source was inspected:
https://arxiv.org/html/1011.5779v1, Section 1 (Introduction). Section 1
defines the second-order observed contour as the trajectory of a
fixed reference/scoring vector under the vector quantile map, describes
the location-scale configuration as an exact ancillary contour, and
explains that for vector parameters failure of full Frobenius
integrability need not prevent construction of a surface with
second-order ancillary properties. This source does not formulate an
alpha-normal connection or equate it with the sample-space contour
bracket.

SpringerLink searches for `“second order ancillary” Frobenius normal
curvature`, `“conditional score” “normal bundle”`, and
`ancillary “induced connection” curvature` returned HTTP 406. SIAM
searches for the first exact topic, the conditional-score/normal-bundle
topic, and the ancillary induced-connection topic returned HTTP 403.
No access controls were bypassed.

After the independent pass, local bibliography discovery used `tem.md`
and the local Fraser/TEM and FM-34 bridge notes. The local catalog
returned no entry for the exact Fraser 2010 title or keyword “Fisher
geometry”; previously cited local works include Amari–Nagaoka (2000),
Fraser–Reid (1995, 2001), Fraser–Reid–Sartori (2016), Efron (1975),
and Skovgaard (1985). They are search leads only for this specific
connection. Coverage remains `incomplete`; no novelty claim is made.

### Best next discriminating step

For a genuinely approximate (non-exact) Fraser contour, derive its
order-`n^-1` ancillary defect from the quantile expansion and compare
it with the fixed-ambient `H^(alpha)` and `R_perp^(alpha)` in one
specified model. The comparison must keep the contour defect,
alpha-dependent normal curvature, and approximation order as separate
quantities; the exact logistic pilot already rules out identifying them
without additional structure.

## What contour jets do and do not determine about alpha curvature

### A conditional coordinate formula

Let `ell=log p`, `s_a=partial_a ell`, and let `n_r` be an ambient score
direction normal to the chosen submodel at a base point. In any regular
dominated ambient where score differentiation is justified, the lowered
alpha-connection coefficient is

`Gamma^(alpha)_{ab,r}
 = E[(partial_a s_b)*s_r]
   + (1-alpha)/2 * E[s_a*s_b*s_r]`.

After metric raising and normal projection, these coefficients contribute
to `H^(alpha)`. The alpha-normal curvature then requires parameter
variation and commutators of the resulting normal-connection matrices.
The formula exposes the missing information: the second-order quantile
contour gives sample-space jets `v_a=partial_a Q_theta` and
`w_ab=partial_a partial_b Q_theta`; even when these determine the
tangent density scores and their tangent derivatives, they do not
specify the ambient normal scores `s_r`, their Fisher metric, or the
mixed moments displayed above. Hence no formula from the Fraser
second-order contour jet alone to `H^(alpha)` or `R_perp^(alpha)` is
well-typed without an additional map from sample-space directions to
ambient normal score directions.

This is a conditional bridge rather than an equality: quantile
transport determines the tangent score; a chosen ambient supplies the
normal scores and the mixed moments; the alpha connection then gives
the second fundamental form and normal curvature. The contour
acceleration is not itself the alpha-covariant acceleration.

### Non-identifiability theorem from identical contour data

The exact ancillary contour is a special case of a contour having
second-order ancillary accuracy. The existing two ambient extensions
give the following sharper counterexample to any proposed universal
map from contour jets to alpha-normal curvature.

**Claim (`proved/agent`).** There exist two regular codimension-two
ambient statistical models that induce the same exact location-scale
configuration ancillary and the same observed ancillary contour on the
location-scale submodel, but whose alpha-normal curvature differs for
every real `alpha`.

**Example I.** Use the two-shape logistic ambient
`(mu,tau,k1,k2)` with `k1=k2=0` as the submodel. The exact
configuration ancillary is the normalized centered residual vector
`A(X)`. Its alpha-normal curvature is

`R_perp,mu,tau^(alpha)=exp(-tau)*
 [[0, -2*(alpha+7)*(5*alpha+14)/315],
  [9*(alpha-7)*(5*alpha-14)/392, 0]]`.

The two off-diagonal entries have disjoint real root sets
`{-7,-14/5}` and `{7,14/5}`. Thus this normal curvature is nonzero
for every real `alpha`.

**Example II.** Observe independent pairs `(X_i,Z_i)`, with the `X`
coordinates in the one-shape logistic ambient `(mu,tau,kappa)` and
`Z_i` standard normal shifted by an ambient mean parameter `eta`.
Take the submodel `kappa=eta=0` and the same statistic `A(X)` as in
Example I. The law of `A(X)` and the full `X` quantile contour are
identical in Examples I and II; the `Z` coordinates are fixed along
that contour. The two normal directions are the logistic shape
direction and the Gaussian mean direction. The model is a regular
codimension-two product ambient. The one-shape logistic normal
connection is `-(alpha/2)d tau`, which is flat for every `alpha`; the
independent Gaussian normal connection along `(mu,tau)` is zero for
every `alpha`. The product has no cross-factor connection terms.
Consequently `R_perp^(alpha)=0` in Example II for every real `alpha`.

The same exact contour data therefore coexist with zero curvature for
all `alpha` in Example II and nonzero curvature for all `alpha` in
Example I. In particular, even the complete contour (not merely its
second-order jet) cannot determine alpha-normal curvature. Any
universal contour-to-curvature claim fails before considering
approximation error.

### Consequence for Fraser approximate contours

Fraser's second-order ancillary property weakens exact ancillarity; it
does not add the missing ambient normal score data. Therefore it cannot
restore identifiability of `R_perp^(alpha)` from contour jets alone.
What remains viable is a model-conditional theorem whose hypotheses
include an explicit ambient extension and a specified intertwiner from
the quantile/contour jet to normal scores. Such a theorem must state
how it transforms under changes of parameterization and ambient
extension. No such natural intertwiner is established here.

### Evidence, verification, and scope

- The score-moment formula for `Gamma^(alpha)`:
  `proved/agent` under the regularity assumptions in the preceding
  general-geometry report; its dependence on mixed normal score moments
  proves that the contour jet is insufficient as standalone input.
- The two-shape curvature factorization and disjoint root sets:
  `verified-computationally` with exact rational SymPy arithmetic,
  cross-checked by factoring the two displayed polynomials; exact
  invocation:
  `uv run python research-scratch/fraser_structural_geometry/20261004-fraser-fm34-bridge/codim2_curvature.py`.
- The one-shape-plus-independent-Gaussian product has zero normal
  curvature for all `alpha`:
  `proved/agent` from the one-shape normal connection
  `-(alpha/2)d tau`, the constant Gaussian Fisher metric and product
  splitting. This argument is analytic; no added package is needed.
- The non-identifiability counterexample applies to all real `alpha`
  for the two specified models and to any rule using only the common
  ancillary/contour data. It does not rule out an explicitly
  ambient-dependent conditional formula.
- Fraser source: Fraser, Fraser and Staicu, “Second order ancillary:
  A differential view from continuity,” arXiv:1011.5779v1. The HTML
  source at `https://arxiv.org/html/1011.5779v1`, Section 1, was
  inspected for the quantile contour and second-order scope. It
  contains no alpha-normal curvature construction.
- Literature review is `incomplete`: arXiv query
  `all:"approximate ancillary" AND all:"alpha connection"` returned
  0 hits; SpringerLink exact-topic query returned HTTP 406; SIAM
  exact-topic query returned HTTP 403. Local catalog search by exact
  title `"Second order ancillary"` returned no record. Local
  bibliography was then checked via `tem.md` and the existing Fraser
  and alpha-geometry notes. No novelty claim is made.

### Disposition

The request for a direct, general contour-jet-to-alpha-curvature law
has a negative resolution under the stated information boundary:
such a law cannot exist without ambient-dependent extra structure.
The score/quantile-to-Fisher-tangent map is the valid common interface;
the subsequent normal geometry is conditional on the ambient. The next
meaningful problem is not to seek a universal identity, but to propose
and justify a specific ambient-dependent intertwiner and derive its
transformation and approximation-order properties.

## Structural-transport selection rule: ancillary-marginal extension

### Rule

Let `X` have a regular dominated model `P_theta`, and let
`A=A(X)` be a parameter-free exact ancillary on connected `Theta`, with
common law `Q`. Assume a regular conditional distribution
`P_theta(dx|A=a)` exists and the score/derivative identities hold.
Structural invariance, for example `A(F_theta(u))=A(u)`, is a
sufficient way to establish this exact ancillarity.

Select the ancillary-measurable normal score sector

`N_A = L^2_0(Q)`,

embedded into `L^2_0(P_theta)` by `g -> g(A)`. This is a canonical
selection relative to the specified ancillary sigma-field: replacing
`A` by a one-to-one measurable recoding leaves the subspace unchanged.
For each finite family of bounded functions
`g_1,...,g_d in L^2_0(Q)`, define the ambient extension

`dP_(theta,eta)(x)
 = exp(eta^j*g_j(A(x))-psi(eta)) dP_theta(x)`,

where
`psi(eta)=log E_Q[exp(eta^j*g_j(A))]`.
Boundedness makes `psi` finite and smooth for all finite `eta`.
Since `Q` is independent of `theta`, the normalizer is independent of
`theta`. The original model is the submanifold `eta=0`; the normal
score at zero is `g_j(A)`.

The rule selects the *whole ancillary-measurable sector* rather than a
preferred finite basis. A finite-dimensional ambient is obtained only
after an additional choice of a finite subspace of `N_A`; that choice
is not canonical. Bounded mean-zero functions are dense in `L^2_0(Q)`,
so these finite-dimensional tilt families realize a dense set of
directions in the selected maximal score sector. The claim is about the
Fisher score sector and its finite-dimensional regular realizations; no
global infinite-dimensional statistical-manifold structure is assumed.

### Orthogonality and alpha-normal transport

For each tangent score `s_a=partial_a log p_theta`, exact ancillarity
gives

`E_theta[s_a | A]=0`.

Therefore

`E_theta[s_a*g_j(A)]=0`,

so the selected normal scores are Fisher-orthogonal to the structural
tangent scores. More strongly, under the tilted extension the joint law
factors as

`Q_eta(da) P_theta(dx|A=a)`.

This is generally not a product statistical model, since the
conditional kernel `P_theta(dx|A=a)` can depend on both `theta` and
`a`. However, the normal connection along the `theta` submodel can be
computed directly. The eta-scores are
`s_j=g_j(A)-E_(Q_eta)[g_j]`; hence `partial_a s_j=0` and

`E[s_a*s_j*s_k]
 = E_(Q_eta)[s_j*s_k * E_theta[s_a|A]] = 0`.

The general score formula therefore gives
`Gamma^(alpha)_(a j,k)=0` for every real `alpha`. The normal metric
`E_(Q_eta)[s_j s_k]` is also independent of `theta`. In this fixed
normal frame the induced alpha-normal connection over the original
`theta` model is zero, and so is its curvature:

`R_perp^(alpha)=0` for every `alpha`.

The associated score-projection of tangent scores into `N_A` is also
identically zero. This is a useful selection rule when the goal is to
make an exact ancillary itself the chosen normal sector. It does not
recover the normal bundle of an independently supplied ambient model.

### Logistic pilot instantiation

For the four-observation logistic location-scale model, take

`A=(X-mean(X)*1)/||X-mean(X)*1||`.

Its distribution is parameter-free by location-scale invariance.
Two explicit bounded centered ancillary functions are
`g_1(A)=sum_i A_i^3` and
`g_2(A)=sum_i A_i^4-E[sum_i A_i^4]`. They are linearly independent
in `L^2(Q)`: at `a_1=(-3,1,1,1)/sqrt(12)`, `sum_i a_(1,i)^3 =
-1/sqrt(3)`, while at `-a_1` it is `+1/sqrt(3)`; the second function
is even and nonconstant because `sum_i a_(1,i)^4=7/12`, whereas
`sum_i a_(2,i)^4=1/4` for `a_2=(-1,-1,1,1)/2`. The base ancillary
law has full sphere support, so these pointwise distinctions imply
linear independence in `L^2(Q)`. Tilting the ancillary marginal by
these two functions constructs a regular codimension-two ambient with the same
location-scale submodel, the same ancillary contour, and zero normal
curvature for every alpha. Its normal bundle is the selected
two-dimensional subspace of `N_A`; it is not asserted to agree with
the previous two-shape logistic ambient.

In particular, the same structural transport and exact ancillary admit
both this flat, ancillary-selected extension and the earlier
two-shape logistic extension with nonzero curvature at `alpha=0`.
The selection rule therefore resolves the choice only after adopting
the criterion “use ancillary-measurable scores as normal scores.” It is
a conventionally selected ambient, not a forced consequence of the
structural equation.

### Precise scope and limitations

- The selected score subspace `N_A`, its invariance under one-to-one
  recoding of `A`, and its Fisher orthogonality to tangent scores:
  `proved/agent` under the exact ancillary and score regularity
  assumptions above.
- The finite-dimensional exponential-tilt extension and conditional
  factorization `Q_eta(da)P_theta(dx|A=a)`: `proved/agent` for bounded
  `g_j(A)`.
- Flat alpha-normal transport along the base `theta` submodel for this
  selected extension: `proved/agent` for every real `alpha`, by the
  vanishing mixed score coefficients and theta-constant normal metric.
- For a merely approximate ancillary, `P_theta(A)` varies with
  `theta`; the factorization fails, the conditional tangent score need
  not vanish, and this rule does not define an orthogonal normal
  extension without a further projection/gauge choice. No approximation
  order claim is made here.
- The rule does not determine the finite subspace or basis of
  `L^2_0(Q)`, does not make the selected ambient unique among all
  statistical extensions, and does not imply that its zero curvature
  describes Fraser's original ambient normal geometry.

### Literature search record for the selection rule (2026-10-04)

The local reference catalog was checked first with
`uv run python tools/reference_lookup.py --grep "ambient normal score ancillary"`
and returned no matches. Independent, question-driven arXiv API searches
were:

- `all:ancillary AND all:"exponential tilt" AND all:Fisher` (0 hits);
- `all:ancillary AND all:"nuisance parameter" AND all:"score function"`
  (0 hits);
- `all:"ancillary statistic" AND all:"information geometry" AND
  all:curvature` (0 hits).

SpringerLink searches for the corresponding ancillary exponential-tilt/
Fisher-score-subspace, nuisance-normal-bundle, and information-geometric
extension query families each returned HTTP 406. SIAM searches for each
family returned HTTP 403. No access restrictions were bypassed.
After that pass, local bibliography discovery used `tem.md` and the
Fraser/TEM and FM-34 bridge notes. The Fraser–Fraser–Staicu source
arXiv:1011.5779v1 was inspected above for the location-scale ancillary
contour but does not formulate this ambient-selection rule. Review is
`incomplete`; no novelty claim is made.

### Best next test

For a genuinely approximate ancillary, quantify
`E_theta[s_a|A]` and the variation of `Q_theta` at the claimed order
`n^-1`; then determine whether its orthogonalized score sector has a
parameterization-invariant connection. That is the first setting where
the exact product argument above ceases to apply.

## A non-exact second-order contour statistic in an ellipse model

This section carries out that test in a concrete Gaussian nonlinear-regression
model. It defines a scalar statistic whose level curves agree locally with
Fraser's translated approximate contours through second order. It is a
model-specific construction, not a claim that Fraser prescribes this unique
contour label.

Let `Y_1,...,Y_n` be independent `N_2(gamma(theta), I_2)` observations, where
`gamma(theta)=(cos(theta), 2 sin(theta))`, and use their sufficient statistic
`Ybar`, whose law is `N_2(gamma(theta), I_2/n)`. Write `sigma=n^-1/2`.
The full-sample score equals the sufficient-statistic score
`s_theta=n (Ybar-gamma(theta)) dot gamma_theta(theta)`.
Let `t_hat` be the nearest-point maximum-likelihood fit of `Ybar` on the
ellipse, use its arclength coordinate, and write tubular coordinates
`Ybar=gamma(t_hat)+a N(t_hat)`. Here `N` is the inward Frenet normal and
`kappa>0` is the curvature, so the tube Jacobian is `1-kappa a`.

In a fixed tube of radius smaller than the ellipse's reach, define

`B_n = a + sigma^2 kappa(t_hat)/2`.

Extend this measurably outside the tube, for example by setting `B_n=1`
there; this does not affect its density for `b=O(sigma)` for all sufficiently
large `n`. Its level curves are a local second-order Fraser contour
representation. Indeed, through an observed point with fitted coordinate
`t0` and residual `a0=O(sigma)`, Fraser's translated curve is
`gamma(t)+a0 N(t0)`. The parallel curve `gamma(t)+a0 N(t)` differs from it,
after a tangential reparameterization, by `O(a0 |t-t0|^2)=O(n^-3/2)` when
`|t-t0|=O(sigma)`. The curvature correction in `B_n` changes the normal
offset over this window by only `O(n^-3/2)`. Thus the statistic labels a
partition of the local tube and captures the Fraser contour to the
`O(n^-1)` moderate-deviation order. It is not the full plug-in residual
vector `Ybar-gamma(t_hat)`, which Fraser et al. warn can fail even as an
approximate ancillary.

For `b=sigma z`, the density can be computed from the tube map with
`a(t)=b-sigma^2 kappa(t)/2`. A local Laplace expansion about the true
arclength parameter gives, uniformly for `theta` in a compact regular
portion of the ellipse and bounded `z`,

`p_{B_n}(b|theta) = phi(z)/sigma * {1 + sigma^2 kappa(theta)^2 (1-z^2)/4 + O(sigma^3)}`,

where `phi` is the standard normal density. The order-`sigma` term cancels
because of the curvature correction. Differentiating the density (the
statistic itself is parameter-independent) yields

`E_theta[s_theta(Y_1,...,Y_n) | B_n=b]`
`= d_theta log p_{B_n}(b|theta)`
`= kappa(theta) kappa_theta(theta) (1-z^2)/(2n) + O(n^-3/2)`.

For an auditable local expansion, let `s0` be the arclength coordinate
corresponding to the ellipse angle `theta`, and set `t=s0+sigma u`. In the
following expansion, `kappa` and `kappa_s` are evaluated at `s0`. The squared
residual and tube Jacobian expand as

`||gamma(t)+a(t)N(t)-gamma(theta)||^2/sigma^2`
`= u^2+z^2 - sigma*kappa*z*(u^2+1)`
`  + sigma^2*[kappa^2*(1/4+u^2/2-u^4/12)`
`               - kappa_s*z*(u+2u^3/3)] + O(sigma^3)`,

`1-kappa(t)a(t)`
`= 1-sigma*kappa*z + sigma^2*(kappa^2/2-kappa_s*u*z)+O(sigma^3)`.

Expanding the Gaussian exponential and integrating against the standard
normal density in `u` cancels the order-`sigma` term. At order `sigma^2`,
the coefficient is `kappa^2*(1-z^2)/4`; terms odd in `u`, including those
involving `kappa_s`, integrate to zero. The Laplace tail outside a growing
local window is exponentially small, uniformly for bounded `z` and `theta`
in a compact regular arc.

This is a nonzero conditional score in general, of order `n^-1`, and the
distribution of `B_n` varies with `theta` at that order. Thus this particular
Fraser-compatible contour is second-order approximate, not exactly ancillary;
the exact-ancillary identity `E[s_theta|A]=0` does not apply.

At `theta0=pi/4`, the ellipse has
`kappa=2/(5/2)^(3/2)` and
`kappa_theta=9/(5/2)^(5/2)`. For `z=1/2`, the leading term is exactly
`108/(625 n)`, approximately `0.1728/n`.

### Numerical evaluation and reproducibility

The tube density integral and its score-weighted numerator were evaluated
directly over the full ellipse, using the exact Gaussian likelihood and tube
Jacobian; their ratio is `E[s_theta|B_n=b]`. The script is
`.research-scratch/fraser_structural_geometry/20261004-approx-ancillary/ellipse_conditional_score.py`.
From the repository root, the command was:

`uv run python tools/computation_preflight.py`
`uv run python .research-scratch/fraser_structural_geometry/20261004-approx-ancillary/ellipse_conditional_score.py`

The preflight passed with Python 3.14.6, SymPy 1.14.0, NumPy 2.5.3, and
SciPy 1.18.1. The SciPy `quad_vec` evaluation used double-precision
floating-point arithmetic, with `theta0=pi/4`, `z=1/2`, and `n` in `{25,100,400}`.
It returned conditional scores, respectively,
`0.0112541610`, `0.00221947907`, and `0.000491580304`; the corresponding
`n`-scaled values are `0.2813540`, `0.2219479`, and `0.1966321`, trending
toward the asymptotic coefficient `0.1728`. This is a finite numerical
sanity check, not interval certification; the asymptotic conclusion comes
from the local density expansion, not from extrapolating these three values.

The model-specific expansion is `proved/agent` under the stated smooth
tubular-coordinate and compact-parameter conditions, pending owner review.
The numerical values are `verified-computationally` only for the three listed
sample sizes, parameter, and ancillary level. No ledger or manuscript was
changed. The literature review remains `incomplete`: Fraser, Fraser, and
Staicu, “Second order ancillary: A differential view from continuity,”
arXiv:1011.5779v1, Section 5's nonlinear-regression circle example, gives an
exact radial ancillary and warns against the plug-in residual-vector
statistic; SpringerLink and SIAM searches remain unavailable as recorded
above. The ellipse statistic and its conditional-score expansion are derived
here, not attributed to that source.

### Remaining limitation

The calculation fixes one explicit contour-label convention. It does not
show that the `n^-1` coefficient is invariant under other second-order
equivalent contour labels, nor does it identify this conditional score with
an alpha-normal or ancillary holonomy invariant. That comparison requires a
separately specified ambient score extension and connection.

Date: 2026-10-04
Agent: GitHub Copilot

## Stability of the selected score line under a second-order label change

This follow-up compares the selected normal score subspace and its induced
alpha-normal connection for the following two contour labels:

`B_n = a + kappa(t_hat)/(2n)`,
`B_n^q = B_n + n^(-3/2)*sin(t_hat)`.

For each label use the bounded feature `phi_n(B)=tanh(sqrt(n)*B)`, center
it under `P_theta`, and project it orthogonally off the one-dimensional base
score `s_theta` in `L^2(P_theta)`. This gives one-dimensional normal score
lines `V_n` and `V_n^q`. The modified feature, written in the common tube
coordinates `B_n=sigma*u`, is

`phi_n(B_n^q) = tanh(u + sin(t_hat)/n)`.

Thus for every sample point,
`|phi_n(B_n^q)-phi_n(B_n)| <= 1/n`, since `tanh` is 1-Lipschitz and
`|sin(t_hat)|<=1`. Centering and orthogonally projecting are contractions
in `L^2(P_theta)`, so the corresponding projected normal scores also differ
in norm by at most `1/n`. If their norms are bounded below by a positive
constant, this gives an `O(n^-1)` upper bound on the angle between the
selected lines. It predicts asymptotic stability, but not exact equality at
finite `n`. It does not by itself bound derivatives of the score frame or
the induced connection.

### Numerical comparison

At `theta=pi/4`, the projected-score principal angle and the unit-normal
alpha-connection coefficient along `partial_theta` were computed for
`alpha=-1,0,1`. The modified and baseline labels use the same sample points
and base law; their score lines are compared using the baseline `L^2(P_theta)`
inner product. Each connection coefficient is expressed in the oriented
unit frame obtained by normalizing its own projected feature residual
`nu=u-I^(-1)Cov(s_theta,u)s_theta`, with the positive coefficient of the
feature score fixing the orientation. Connection one-forms are frame
dependent, so this explicit gauge is part of the comparison.

| n | angular / normal quadrature | principal angle between normal score lines | `alpha=1` connection, baseline | `alpha=1` connection, shifted | shift |
|---:|---:|---:|---:|---:|---:|
| 400 | 384 / 120 | 0.000879430 rad (0.05039 deg) | 0.00026394646 | 0.00022384613 | -0.00004010034 |
| 400 | 768 / 120 | 0.000879430 rad (0.05039 deg) | 0.00026394646 | 0.00022384613 | -0.00004010034 |
| 1600 | 768 / 120 | 0.000219808 rad (0.01259 deg) | 0.00006629411 | 0.00006118570 | -0.00000510841 |
| 1600 | 1536 / 120 | 0.000219808 rad (0.01259 deg) | 0.00006629412 | 0.00006118570 | -0.00000510841 |

Doubling the angular grid did not change the displayed quantities at the
reported precision. The angle multiplied by `n` is approximately `0.35177`
at `n=400` and `0.35169` at `n=1600`, consistent with the analytic
`O(n^-1)` stability bound in this example.

The absolute connection-coefficient shift is approximately `4.0100e-5` at
`n=400` and `5.1084e-6` at `n=1600`. Multiplication by `n^(3/2)` gives
approximately `0.3208` and `0.3269`. These two finite values are consistent
with a decaying, label-dependent connection correction, but do not prove an
`O(n^-3/2)` theorem. At `alpha=-1` the shift has the opposite sign and same
magnitude to the displayed precision. At `alpha=0`, both unit-normal
connection coefficients are numerically zero (absolute values below
`1.2e-11`), as required by metric compatibility of the Levi-Civita
connection on a rank-one normal bundle.

The two Fisher determinants are positive at both tested sample sizes:
approximately `394.2363` and `1577.1198` for the baseline, and
`394.2357` and `1577.1196` for the shifted label. The residual normal-score
variances are approximately `0.3942363` and `0.39427994` for the baseline,
and `0.3942357` and `0.39427991` for the shifted label. Thus neither selected
line degenerates at the tested points.

### Interpretation

For this bounded feature and this specific label change:

- The normal-score subspace is **not exactly invariant** at finite `n`; its
  principal angle is positive.
- It is **asymptotically stable in subspace angle** at the analytic
  `O(n^-1)` bound, and the two computed sample sizes support that scale.
- The induced alpha-normal connection is also label-sensitive at finite `n`.
  Its coefficient shift tends to zero in the tested sequence, but no
  general rate for connection stability is established here.
- Equality of the alpha-zero coefficients is special to the
  metric-compatible Levi-Civita connection in this rank-one normal setting;
  it does not remove the alpha-nonzero gauge dependence.

Therefore the selection rule is locally constructible and asymptotically
stable under this `O(n^-3/2)` contour displacement in the weak sense of
subspace angle, but it is not a canonical finite-sample rule. The connection
requires more control than convergence of the subspaces: one must also
control parameter derivatives of the projected score frame and the ambient
score-moment tensors. A natural next theorem would give such derivative
bounds under a uniform lower bound on the residual Gram eigenvalue and
uniform smoothness of the label perturbation.

### Reproducibility and evidence scope

The updated script is
`.research-scratch/fraser_structural_geometry/20261004-approx-ancillary/approx_score_normal_connection.py`.
From the repository root run:

`uv run python tools/computation_preflight.py`
`uv run python .research-scratch/fraser_structural_geometry/20261004-approx-ancillary/approx_score_normal_connection.py`

The project preflight passed with Python 3.14.6, SymPy 1.14.0, NumPy 2.5.3,
and SciPy 1.18.1. The comparison uses double-precision NumPy arithmetic,
384/768/1536 midpoint angle points, 120-point Gauss-Legendre quadrature on
the scaled normal interval `[-8,8]`, `n=400,1600`, and `theta=pi/4`.
It is a bounded numerical computation; the tails and finite-difference
connection derivatives are not interval-certified.

The pointwise feature bound and projected-score norm bound are
`proved/agent` under the stated `L^2` setup. Positive residual variance and
the displayed finite values are `verified-computationally` only at the
listed model points and quadrature resolutions. No canonical file or
manuscript was changed.

Date: 2026-10-04
Agent: GitHub Copilot

## Two-parameter curvature and holonomy check

Date: 2026-10-04 18:23:15 +09:00
Agent: GitHub Copilot in VS Code; underlying model version not exposed
Status: `verified-computationally` for the finite model and quadrature scope;
literature review remains `incomplete`

Because the label-dependent score directions do not define a canonical
selection, retain the label as gauge data. Extend the Gaussian ellipse
construction to the base cylinder `S^1 x R` with

`Ybar ~ N_3((cos(theta), 2 sin(theta), lambda), I/n)`, `n=400`.

Compare the Fraser-compatible tube label
`B_n = a + kappa(t_hat)/(2n)` with

`B_n^q = B_n + n^(-3/2)*sin(t_hat)*tanh(Ybar_3)`.

Use `tanh(sqrt(n)*B_label)` as the bounded statistic, center it, Fisher
project away the two base scores, and realize that residual as a local
exponential-tilt normal score. The convention is
`Gamma^(alpha)=Gamma^(0)-alpha*T^sharp/2`. The selected normal rank is one.
At `(theta,lambda)=(pi/4,0.7)`, the base Fisher determinant is
`399999.9999968` for both labels and the projected normal-score variances
are `0.3942362789` (baseline) and `0.3942360678` (shifted), both positive.
These are pointwise numerical checks; local constant rank follows only
where the smooth residual variance remains positive.

The curvature is computed as
`partial_theta omega_lambda - partial_lambda omega_theta`, with centered
finite differences. The shifted-label `alpha=1` estimates were
`2.64116357e-5` at difference step `0.04` and
`2.64107015e-5` at step `0.02`; the baseline estimates were zero to
floating-point precision. Repeating at quadrature orders
`(96,48,24)` and `(128,64,32)` for local tangent, scaled normal, and
independent Gaussian coordinates changed the `h=0.02` shifted estimate
from `2.64106576e-5` to `2.64107015e-5`.

For positively oriented rectangles of side `0.08` and `0.04`, the shifted
connection integrals divided by area were `2.59690193e-5` and
`2.61936554e-5`, respectively, approaching the local curvature estimate.
The scalar parallel transport is `exp(-integral omega)`, so the
corresponding log-holonomy per area has the opposite sign. The baseline
loop integrals were zero to numerical precision. For the noncontractible
theta-circle, 8- and 16-point periodic sums gave shifted-label holonomies
`0.99999999999960` and `1.00000000000022`; baseline values were
`0.99999999999925` and `0.99999999999826`. Treat these as numerically
indistinguishable from identity, not as an exact vanishing period or a
classification of full holonomy. The local nonzero curvature and sampled
global period are distinct observations.

Reproduce from the repository root with

`uv run python .research-scratch/fraser_structural_geometry/20261004-approx-ancillary/curvature_holonomy_2d_base.py --angle-count 128 --normal-count 64 --gaussian-count 32`

The project preflight passed with Python 3.14.6, NumPy 2.5.3, and SciPy
1.18.1. The computation uses double-precision finite differences,
Gauss-Legendre quadrature on the local tangent and scaled normal windows
`[-8,8]`, and normalized Gauss-Hermite quadrature on the independent
Gaussian coordinate. It is not tail-certified or interval arithmetic.
The label remains part of the selected gauge; the computation does not
establish a canonical label, a general Fraser-to-curvature theorem, or an
exact global holonomy result. No canonical ledger or manuscript was
changed.

## Selecting an approximate-ancillary score sector and inducing its alpha-normal connection

This section tests whether an approximate ancillary can select an actual
finite-dimensional normal score sector and whether that sector can carry the
ambient alpha-normal connection. The answer is conditional but constructive:
the sector and a regular ambient extension can be built locally; its induced
alpha-normal connection is then compatible by definition and obeys the
standard alpha-duality formula. Neither construction is canonical, and the
connection is not generally metric-compatible for nonzero alpha.

### Selection rule

Let `P_theta` be a regular dominated model with score vector
`s=(s_a)` and nonsingular Fisher matrix `I_ab=E[s_a s_b]`. Let `A_n` be a
parameter-free approximate ancillary statistic, and choose finitely many
bounded, parameter-free functions `phi_j(A_n)`. Center them at the base
model, `u_j=phi_j(A_n)-E_theta[phi_j(A_n)]`. Their tangent-score projection
and residual normal scores are

`c_j^a = I^(ab) E_theta[s_b u_j]`,
`nu_j = u_j - c_j^a s_a`.

The normal-score Gram matrix is the Schur complement

`G_perp,ij = E[u_i u_j] - E[u_i s_a] I^(ab) E[s_b u_j]`.

If this matrix has constant positive rank on a parameter neighborhood, its
columns define a smooth finite-rank subbundle of the Fisher-orthogonal
complement of the base tangent score space. This projection is essential:
for approximate `A_n`, `E[s|A_n]` is usually nonzero, so raw
`A_n`-measurable scores are not already normal.

The rule is realized, rather than merely specified as a score-space
selection, by the local exponential-tilt ambient

`p_(theta,eta)(x) = p_theta(x) *`
` exp{eta^j phi_j(A_n(x)) - psi(theta,eta)}`,

`psi(theta,eta)=log E_theta exp{eta^j phi_j(A_n)}`.

Boundedness makes the normalizer finite near `eta=0`. At `eta=0` the
additional coordinate scores are exactly `u_j`; the normal bundle of the
base immersion `eta=0` is exactly their Fisher-orthogonalized span `nu_j`,
provided `G_perp` is positive definite. This constructs a regular
finite-dimensional ambient extension locally. It does not assert that this
is Fraser's unique or original ambient.

The marginal score of the statistic is
`r_theta(A_n)=E_theta[s|A_n]=partial_theta log p_theta(A_n)`.
For every selected `phi_j`,

`E_theta[s_a u_j] = E_theta[r_theta(A_n) u_j]`
`                 = partial_a E_theta[phi_j(A_n)]`.

Thus the correction `c_j^a s_a` removes exactly the tangent component
measured by the approximate ancillary's distributional response. For an
exact ancillary this covariance is zero, recovering the previous exact
selection rule. For an approximate ancillary it need not vanish.

### Compatibility with the alpha-normal connection

Fix the convention `nabla^(alpha)=nabla^(0)-alpha*T^sharp/2` and use the
same Fisher metric and normal projection for every alpha. On the constructed
ambient, define the selected normal connection by

`D_perp^(alpha)_X nu = Pi_perp(nabla^(alpha)_X nu)`.

It is an alpha-normal connection on the selected bundle. If `t` and `nu`
are unit tangent and normal fields, then

`g(nu,D_perp^(alpha)_t nu) = -alpha*T(t,nu,nu)/2`.

Indeed, the Levi-Civita normal connection preserves the metric, so
`g(nu,D_perp^(0)_t nu)=0` for a unit section; the displayed difference is
the normal projection of the tensorial connection change. This is the
appropriate compatibility statement. For `alpha != 0`, the normal
connection generally does not preserve the normal metric; the failure is
the displayed cubic-tensor contraction. Compatibility does not imply that
the connection is flat or that its curvature determines an ancillary.

### Concrete test in the ellipse model

Use the previous `B_n` in the Gaussian curve model, now at `n=400` and
`theta=pi/4`. Set `phi(B_n)=tanh(sqrt(n)*B_n)`, extended boundedly outside
the fixed tubular neighborhood. On the full `n`-observation experiment,
`B_n` is computed from `Ybar`; the orthogonal Gaussian contrasts are
parameter-free and independent of `Ybar`.

The ambient extension is explicitly

`p_(theta,eta)(y_1,...,y_n) proportional to`
` p_theta(y_1,...,y_n) * exp{eta*tanh(sqrt(n)*B_n(Ybar))}`.

The base theta score has variance `I_theta_theta=1000`. The tilt score has
variance approximately `0.394236276`, with covariance
`Cov(s_theta,u)=5.22270068e-5`. The Fisher determinant is approximately
`394.236276>0`, and the projected normal score variance is approximately
`0.394236276>0`. Thus the proposed nuisance direction is genuinely
independent of the tangent score, and the local two-parameter ambient
extension is regular at the tested point. Analytically, strict positivity
also follows because the bounded nonconstant function `tanh(sqrt(n)B_n)`
cannot equal an affine function of the unbounded Gaussian curve score
almost surely on the full-support sample space.

The normal connection was computed in the coordinates `(theta,eta)` from
the alpha score-moment coefficients of this actual tilted density. For a
unit normal section, the coefficients along the coordinate direction
`partial_theta` were:

| alpha | projected connection coefficient | `-alpha*sqrt(I_theta_theta)*T(t,nu,nu)/2` |
|---:|---:|---:|
| -1 | -0.0002639464420 | -0.0002639464518 |
| 0 | 0.000000000010 | 0 |
| 1 | 0.0002639464616 | 0.0002639464518 |

The maximum absolute discrepancy was `9.81e-12` in this numerical
calculation. The nonzero `alpha=+-1` values verify that the projected
approximate-ancillary sector can carry the alpha-normal connection with
the expected nonmetricity; the `alpha=0` value is numerically zero as
required by metric compatibility. The base has one dimension, so its
normal curvature two-form vanishes identically; this calculation tests
connection compatibility, not nonzero normal curvature.

### Reproducibility and limitations

Run from repository root:

`uv run python tools/computation_preflight.py`
`uv run python .research-scratch/fraser_structural_geometry/20261004-approx-ancillary/approx_score_normal_connection.py`

The preflight reported Python 3.14.6, SymPy 1.14.0, NumPy 2.5.3, and
SciPy 1.18.1. The moment calculation used NumPy double precision, a
384-point midpoint rule around the ellipse, and 120-point Gauss-Legendre
quadrature for the scaled normal coordinate in `[-8,8]`. The tail outside
this local tube was not interval-certified; the table is a numerical
verification at `n=400, theta=pi/4`, not a rigorous finite-n certificate.
The positivity and alpha-connection identity are analytic conditional
statements under the stated regularity and rank hypotheses.

The local source catalog was checked first with
`uv run python tools/reference_lookup.py --grep "approximate ancillary score subspace alpha normal connection"`
and returned no matches. Independent arXiv API searches for (i)
`"approximate ancillary" AND score AND connection`, (ii)
`"conditional score" AND ancillary AND "normal bundle"`, and (iii)
`"exponential tilt" AND ancillary AND "Fisher orthogonal"` each reported
zero results. SpringerLink searches for these query families returned HTTP
406 and SIAM searches returned HTTP 403; no access controls were bypassed.
After that pass, the local bibliography route used `tem.md` and the
manuscript references, including Amari and Nagaoka, *Methods of Information
Geometry*, and Fraser, Fraser, and Staicu, “Second order ancillary: A
differential view from continuity.” The exact-title Amari query returned
zero arXiv results; SpringerLink and SIAM again returned HTTP 406 and 403.
The Fraser source arXiv:1011.5779v1 was already inspected in the preceding
section for its contour construction, but does not establish this
score-projection rule. Literature review remains `incomplete`; no novelty
claim is made.

**Status:** the finite-dimensional score projection and exponential-tilt
realization are `proved/agent` under the stated regularity and
constant-rank assumptions. The alpha-normal compatibility identity is
`proved/agent` from the fixed connection convention. The numerical
coefficient check is `verified-computationally` only at the stated model,
parameter, sample size, and quadrature settings. This resolves local
constructibility and compatibility for one explicit approximate ancillary,
but not canonicality, label invariance, nonzero curvature, or a general
Fraser-to-holonomy theorem. No ledger or manuscript was changed.

Date: 2026-10-04
Agent: GitHub Copilot

## Label sensitivity and normal-bundle comparison

The `n^-1` coefficient is not invariant under all labels whose local contours
agree through second order. Keep the ellipse model, tube, and `B_n` above, put
`sigma=n^-1/2`, and let `q` be any smooth function on the ellipse. Define

`B_n^q = B_n + sigma^3 q(t_hat)`.

For a fixed observed label `b=sigma z`, its contour has signed normal distance
from the `B_n=b` contour exactly `-sigma^3 q(t)` at footpoint `t`.
Thus the contour displacement is `O(n^-3/2)`: the two contour families agree
through the `n^-1` term, although they need not define the same conditioning
sigma-field. Since the derivative of either label with respect to the tube
coordinate `a` is one, both define regular local partitions. This is distinct
from a one-to-one scalar recoding `g_n(B_n)`,
which preserves that sigma-field and hence preserves the conditional score
exactly (at corresponding values).

For the original `n` bivariate observations, the orthogonal Gaussian
contrasts `R_i=Y_i-Ybar` have a parameter-free joint law and are independent
of `Ybar`. The full score depends only on `Ybar`, so augmenting either
contour label by these exact-ancillary contrasts leaves the conditional score
unchanged. This lifts the local calculation to a full-sample contour
partition without treating the plug-in residual vector as ancillary.

In the density integral, the new normal offset is
`a(t)=sigma*z - sigma^2*kappa(t)/2 - sigma^3*q(t)`. The last term multiplies
the local Gaussian integrand by `1+sigma^2*z*q(theta)+O(sigma^3)`. Therefore

`p_{B_n^q}(sigma*z|theta) = phi(z)/sigma *`
`  {1 + sigma^2*[kappa(theta)^2*(1-z^2)/4 + z*q(theta)] + O(sigma^3)}`, and

`E_theta[s_theta | B_n^q=sigma*z]`
`= (1/n)*[kappa*kappa_theta*(1-z^2)/2 + z*q_theta] + O(n^-3/2)`.

The expansion is uniform for bounded `z`, smooth `q`, and `theta` in a compact
regular arc. The derivative is with respect to the model parameter theta;
the score is consequently a parameter one-form. In arclength `s`, its
coefficient is `[kappa*kappa_s*(1-z^2)/2 + z*q_s]/n`, making the
parameterization covariance explicit.

Choose the smooth, parameter-free contour function on footpoints
`q(p)=p_2/2`, where `p=(p_1,p_2)` lies on the ellipse; thus
`q(gamma(theta))=sin(theta)` and `q_theta=cos(theta)`. At
`theta=pi/4,z=1/2`, the baseline coefficient
is `0.1728`, while the equally second-order-equivalent label has coefficient
`0.1728 + (1/2)*cos(pi/4) = 0.5263533906`. The two predictions differ by
`0.3535533906/n`. This gives an analytic obstruction to label invariance,
not merely two different finite-sample numerical outputs.

### Conditional score versus normal curvature

Use the regular ambient statistical manifold of single-observation
`N_2(mu,I)` laws, `mu in R^2`, with its per-observation Fisher metric. In
mean coordinates that metric is Euclidean, the cubic tensor vanishes, and
all alpha connections coincide with the flat Levi-Civita connection. The
ellipse `gamma(theta)` is an immersed one-dimensional submanifold of this
two-dimensional ambient family. Its normal bundle has rank one. The unit
Frenet normal has zero normal covariant derivative along the curve, and the
normal-connection curvature is identically zero. Its second fundamental
form is nevertheless nonzero: with the inward-normal convention above,
`II(T,T)=kappa*N` for unit tangent `T`.

The baseline score coefficient depends on the derivative of the squared
second-fundamental-form magnitude, `d_theta(kappa^2)/4`, multiplied by
`1-z^2`; it is a contour-density/shape effect. The equally accurate label
adds `z*d_theta q`. In particular, at the stated point the conditional
score is nonzero for both labels while normal curvature is zero, and its
leading coefficient changes with the label. Thus, in this explicit
rank-one-normal example, the conditional score is not the normal curvature
or a normal-holonomy invariant. It is the parameter derivative of the
pushforward density of the chosen contour label, and the density expansion
can involve extrinsic second fundamental form data without determining the
normal connection.

This answers the connection question negatively at the level of a
label-independent identification: none follows from the approximate
contour geometry alone. A connection to a chosen ambient normal transport
would require extra structure specifying a label gauge and a map from
conditional-score variation to normal vectors; this model does not provide
such a canonical map.

### Numerical discrimination and literature scope

The existing quadrature script now evaluates both `B_n` and
`B_n+sin(t_hat)*n^(-3/2)` by direct integration with the same Gaussian
likelihood and tube Jacobian. Run from the repository root:

`uv run python .research-scratch/fraser_structural_geometry/20261004-approx-ancillary/ellipse_conditional_score.py`

For `theta=pi/4`, `z=1/2`, and `n={25,100,400}`, `n` times the baseline
conditional score was `{0.2813540, 0.2219479, 0.1966321}`; for the modified
label it was `{0.6096346, 0.5705830, 0.5490923}`. These double-precision
quadratures approach the respective asymptotic coefficients `0.1728` and
`0.5263534`; they are finite numerical checks, not interval certificates.
The script uses the project preflight-confirmed Python 3.14.6, NumPy 2.5.3,
and SciPy 1.18.1.

Question-driven literature searches were run before the bibliography route.
The local catalog command
`uv run python tools/reference_lookup.py --grep "Fraser contour curvature conditional score"`
returned no matches. arXiv API searches for (i) `"approximate ancillary" AND
curvature AND conditional score`, (ii) `"normal bundle" AND ancillary AND
curvature`, and (iii) `"ancillary contour" AND curvature` returned 0, 0,
and 0 results, respectively. The corresponding SpringerLink searches returned
HTTP 406; SIAM searches returned HTTP 403. For the separate local-bibliography
route, `tem.md` surfaced Efron (1975), “Defining the curvature of a
statistical problem”; exact-title arXiv search returned 0, and SpringerLink
and SIAM again returned HTTP 406 and 403. The Fraser–Fraser–Staicu exact-title
arXiv query found arXiv:1011.5779v1 (“Second order ancillary: A differential
view from continuity”), which was already inspected for the previous section;
SpringerLink and SIAM searches remained inaccessible. No access control was
bypassed. Literature review is `incomplete`; no novelty conclusion is drawn.

The label-dependence expansion and rank-one normal-bundle comparison are
`proved/agent`, conditional on the regular tube and Laplace expansion above,
pending owner review. The six finite quadrature values are
`verified-computationally` only for the specified model, labels, `theta`,
`z`, and sample sizes. No canonical ledger or manuscript was changed.

Date: 2026-10-04
Agent: GitHub Copilot
