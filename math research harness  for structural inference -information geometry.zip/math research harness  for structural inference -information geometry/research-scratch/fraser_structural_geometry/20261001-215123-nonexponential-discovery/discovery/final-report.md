# Final report: non-exponential structural models

Date: 2026-10-01
Status: incomplete literature review; theory candidates open

## 1. Formalized question

Given a parameter-free base variable U and a structural equation `X = theta(beta) * U`, with `*` interpreted as a specified measurable and preferably smooth action, determine which parts of Fraser-style structural inference extend beyond exponential families:

- existence of an exact ancillary;
- local tangent-exponential/TEM and higher-order likelihood inference;
- Fisher-metric, alpha-connection, normal-bundle, and holonomy descriptions.

The central separation is: an invariant of the structural action may be exact ancillary; a tangent model is local and approximate; information-geometric curvature requires a specified ambient statistical manifold and immersion. None implies the others without additional hypotheses.

## 2. Candidate theories

### NX-01: group-invariant exact ancillary

For a regular finite-dimensional group action, maximal invariants of the sample-space orbit are the leading exact ancillary candidates. The location-scale normalized-spacing calculation in `counterexamples.jsonl` supports the parameter-free part for a continuous non-exponential base law. Remaining obligations are measurability, maximality, quotient regularity, and the link between quotient directions and TEM ancillary directions.

### NX-02: local transport/TEM extension

For a regular C^3 structural map, sample-space derivatives at the fitted point can define a local tangent exponential model even when the global family is not exponential. The predicted benefit is higher-order local inference, not a global exact ancillary. The key missing result is an explicit remainder theorem and a parameterization-invariant construction for the selected non-exponential class.

### NX-03: statistical-manifold extension

A regular dominated non-exponential family has a Fisher metric and score-moment alpha-connections. Curvature and normal-bundle objects can be defined after choosing an ambient model and immersion. The exponential-family flat identities must not be copied: ambient curvature terms generally remain, and the dual shape-operator convention must be fixed. The relation of normal holonomy to actual ancillary choices is an additional theorem, not a definition.

### NX-04: obstruction to universality

No construction can guarantee a nontrivial exact ancillary for every non-exponential structural equation. One-observation location families provide a natural obstruction target; a precise completeness lemma remains pending. This boundary condition is necessary to prevent local TEM or normal holonomy from being mislabeled as exact ancillarity.

## 3. Literature and evidence

The independent arXiv search found Davison and Reid, *The Tangent Exponential Model*, arXiv:2106.10496 (v2, 2022), whose abstract identifies it as a review of higher-order approximations based on Fraser and co-workers' TEM. arXiv searches for combined Fraser/structural-equation terms produced no direct result, while transformation-model and structural-model searches produced either no direct match or unrelated items. The local paper's cited TEM and Fraser works were used as discovery seeds, not as verified evidence.

SpringerLink was attempted with the baseline, terminology-variant, and local-reference queries but redirected to an identity-provider authorization page. SIAM was attempted with the same query families but returned security verification/HTTP 403 or failed extraction. These providers are therefore incomplete, and no novelty claim is made.

The literature log records exact queries and failures. No candidate is marked `proved/literature`.

## 4. Strongest current conclusion

The most defensible architecture is conditional and layered:

1. Assume a regular group action when an exact ancillary is required; construct it from a maximal invariant.
2. Independently construct a local TEM/r* approximation from sample-space derivatives under regularity and explicit remainder control.
3. Independently define information geometry on a chosen ambient statistical manifold; retain ambient curvature terms and do not identify normal directions with ancillary directions without proof.
4. Treat the absence of a group quotient or exact ancillary as an obstruction, not as a failure of local higher-order inference.

This is a research result at the candidate level, not a theorem or novelty claim.

## 5. Best next discriminating test

Use the logistic location-scale structural model `X_i = mu + sigma U_i`, n>=3, with logistic U. Derive both:

- the exact maximal-invariant ancillary based on normalized order-statistic spacings; and
- the local TEM/r* construction from the likelihood derivatives.

Then check whether the local ancillary direction agrees with the quotient tangent direction to the claimed order. A mismatch would sharply separate exact group invariance from local TEM transport and would directly test the proposed extension.

## 6. Unresolved and incomplete work

- SpringerLink and SIAM candidate-specific searches remain unavailable.
- No exact Fraser theorem for the proposed non-exponential formulation was certified.
- The operation `*`, support conditions, group structure, and sample-space dimension must be fixed before a theorem can be stated.
- The one-observation location obstruction needs a formal completeness proof.
- The non-exponential ambient curvature and dual Ricci formulas need a concrete symbolic model.
- No ledger, manuscript, or canonical claim was changed.
