# Computation summary

No long-running computation was executed. The requested two-hour limit was respected.

## Analytic bounded check

For the location-scale structural model `X_i = mu + sigma U_i`, continuous non-exponential U, and n=3,

`(X_(2)-X_(1))/(X_(3)-X_(1)) = (U_(2)-U_(1))/(U_(3)-U_(1))`.

The right side has a distribution independent of `(mu,sigma)`. This is an exact invariance check for a candidate ancillary, not a proof of maximality, completeness, or a general Fraser theorem.

## Pending computational tests

1. Symbolic score, Fisher information, and third-order derivatives for a logistic location-scale model.
2. A concrete two-dimensional non-exponential ambient model with nonzero statistical curvature and a one-dimensional immersion.
3. A formal one-observation location-family obstruction to nontrivial exact ancillaries.
4. Comparison of local TEM/r* approximation with direct likelihood expansion under explicit remainder bounds.
