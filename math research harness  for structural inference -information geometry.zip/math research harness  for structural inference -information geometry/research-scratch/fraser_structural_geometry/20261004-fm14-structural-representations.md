# FM-14: Distinct Structural Representations of the Same Model

- Date: 2026-10-04 (JST)
- Agent: GitHub Copilot
- Scope: Compare two explicit structural maps for one identical smooth statistical model; analyze residuals and ancillary contours. This is a model-specific calculation, not a general Fraser/TEM theorem.
- Evidence status: `proved/agent`
- Related records:
  - `research-scratch/fraser_structural_geometry/20261004-2133-fm14-audit.md`
  - `research-scratch/fraser_structural_geometry/20261004-fm14-global-flows.md`

## Fixed error law and induced model

Use the flat torus `T^2=(R/2 pi Z)^2` and let the parameter range be a nonempty open interval `B` around zero, small enough to avoid the global location periodicity. Choose `0 < epsilon, delta < 1`, `a != 0`, and `c != 0`. Let the parameter-independent error variable `U=(Xi,Eta)` have density

`q(x,y) = (1 + epsilon cos(x))(1 + delta cos(y)) / (4 pi^2)`.

This density is smooth, strictly positive, and integrates to one. Write

`H_x(y) = integral_0^y q(x,s) ds = (1 + epsilon cos(x))(y + delta sin(y)) / (4 pi^2)`

on a real lift of the circle. It is strictly increasing and satisfies
`H_x(y+2 pi)=H_x(y)+m(x)`, where `m(x)=(1+epsilon cos(x))/(2 pi)>0`.

Define two structural maps for `beta in B`:

`F^1_beta(x,y) = (x + a beta, y)`,

`F^2_beta(x,y) = (x + a beta, Y)`, where `Y` is determined modulo `2 pi` by
`H_x(Y) = H_x(y) + c beta`.

The lift equation defines a unique `Y` modulo the period relation because `H_x` is strictly increasing and advances by `m(x)` per turn. Both maps are smooth diffeomorphisms of the torus and `F^1_0=F^2_0=id`.

For `F^2_beta`, the Jacobian determinant in coordinates `(x,y)` is
`partial_y Y = q(x,y)/q(x,Y)`. Hence the pushforward density at `(X,Y)` is
`q(x,y)/|det DF^2_beta(x,y)| = q(x,Y)`, with `x=X-a beta`. Therefore both structural representations induce exactly the same density

`p_beta(X,Y) = q(X-a beta,Y)`.

Equivalently, `F^1_beta(U)` and `F^2_beta(U)` have the same law for every beta. This is an equality of statistical models, not merely equality of their scores.

## Structural residuals

For an observation `(X,Y)`, the inverse residuals are

`U^1_beta(X,Y) = (X-a beta,Y)`,

`U^2_beta(X,Y) = (X-a beta,Eta_beta)`, where
`H_(X-a beta)(Eta_beta) = H_(X-a beta)(Y) - c beta` modulo the corresponding period.

Under the model at the true beta, both residuals have the same fixed law `q`, by construction. They are nevertheless beta-indexed residual coordinates, not parameter-free statistics of the observation. In particular, at beta zero,

`d Eta_beta / d beta |_(beta=0) = -c/q(X,Y)`,

so the second residual genuinely depends on beta. The first residual also has beta-dependent first coordinate.

## Structural curves and ancillary contour

Holding the error value `(x,y)` fixed, the first representation traces the curve
`beta -> (x+a beta,y)`. The statistic `A(X,Y)=Y` is constant along these curves and is an exact ancillary because the model density factors as
`[(1+epsilon cos(X-a beta))/(2 pi)] * [(1+delta cos(Y))/(2 pi)]`.

The second representation traces `beta -> F^2_beta(x,y)` with velocity at sample point `(X,Y)` equal to

`v^2_beta(X,Y) = (a, c/q(X-a beta,Y))`.

There is no nonconstant smooth common invariant of this full family of structural curves. Indeed, if a smooth `A(X,Y)` is constant along all such curves, then for every beta in `B`,

`a partial_X A(X,Y) + c/q(X-a beta,Y) partial_Y A(X,Y) = 0`.

For each fixed `(X,Y)`, the coefficient `q(X-a beta,Y)` is nonconstant on every open beta interval since `epsilon>0` and `a!=0`. Choosing two beta values with different coefficients and subtracting the equations gives `partial_Y A=0`, and then `partial_X A=0` since `a!=0`. Thus `A` is constant. This proves that the second structural family does not select a nontrivial smooth ancillary contour invariant, even though the model itself has the exact ancillary `Y`.

This is a statement about common smooth invariants of the chosen structural curves. It does not rule out nonsmooth ancillaries or other parameter-free ancillary statistics, and it does not identify structural residual coordinates with ancillary statistics.

## Implications for inference

- The likelihood, score, Fisher information, and any inference procedure depending only on the induced family `{p_beta}` are identical under `F^1` and `F^2`.
- Exact conditioning on the actual statistic `Y` is valid under this model and gives the same conditional distribution of `X` as its marginal distribution, because `X` and `Y` are independent for every beta.
- The second residual's `Eta_beta` coordinate is not an observable ancillary statistic: computing it requires the unknown beta. Treating it as a conditioning statistic would not be justified.
- Therefore this example exhibits representation dependence of structural curves and residual coordinates, but not a demonstrated numerical difference in a valid likelihood or ancillary-conditional inference procedure. No TEM `r*` or higher-order approximation has been computed.
- No normal-bundle or normal-curvature conclusion follows; no ambient statistical manifold or immersion has been specified.

## Conclusion and remaining scope

The same regular statistical model admits two different smooth Fraser-style pushforward representations with a common parameter-free error law. One representation has structural trajectories tangent to the exact ancillary levels `Y=constant`; the other has no nonconstant smooth common invariant along its structural trajectories. Both have beta-indexed residuals with the same fixed error distribution, but neither residual is itself a parameter-free statistic.

This resolves the existence part of the proposed concrete investigation and demonstrates that the induced likelihood alone does not determine structural trajectories. It does not establish that valid conditional inference or TEM approximations differ between representations. The next discriminating question is whether a representation-specific, fully justified higher-order construction (with all required sample-space derivatives and regularity assumptions fixed) changes under these two maps, or whether the standard construction is invariant after correct ancillary information is supplied.
