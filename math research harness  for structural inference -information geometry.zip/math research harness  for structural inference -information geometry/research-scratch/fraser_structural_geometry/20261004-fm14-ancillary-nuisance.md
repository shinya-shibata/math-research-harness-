# FM-14: Ancillary Choice and an Orthogonal Nuisance Parameter

- Date: 2026-10-04 (JST)
- Agent: GitHub Copilot
- Scope: Compare two exact ancillary conditionings in a smooth location model; append an independent nuisance parameter; derive the local scalar conditional r* expansions. This is a counterexample to blanket ancillary-choice invariance plus a restricted nuisance example, not a general nuisance-parameter theorem.
- Evidence status: `proved/agent` for the conditional-distribution distinction for the selected reduced statistic and the displayed local expansion coefficients, under the scalar convention below.
- Literature status: `incomplete`; no novelty claim.

## Question and conventions

The question is whether correctly conditioning on different exact ancillaries, or adding a nuisance parameter, forces conditional inference and r* to be invariant. Distinguish:

1. representation invariance with a fixed conditional experiment; and
2. invariance under changing the conditioning statistic itself.

Use the scalar local convention recorded in `tem.md`, Section 4.1:

`phi(mu) = partial_t ell_c(mu;t)`,
`q(mu) = [phi(hat mu)-phi(mu)] sqrt(j(hat mu)) / phi'(hat mu)`,
`r* = r + r^(-1) log(q/r)`.

All r* calculations below are local around the interior conditional MLE. Write `s=t-mu`, so `s>0` is the side on which `hat mu-mu > 0`. No global tail or coverage claim is made.

## Two exact ancillaries in a smooth location model

Let `X1=mu+U1`, `X2=mu+U2`, where `U1,U2` are independent standard logistic variables with density

`f(u) = 1 / [4 cosh^2(u/2)]`.

Define

`T = (X1+X2)/2`, `D = X1-X2`.

Then `D` is parameter-free and hence exact ancillary; so is the coarsening `B=1{D>0}`. The transformation from `(X1,X2)` to `(T,D)` has absolute Jacobian one. With `s=t-mu`,

`p_(T,D)(t,d;mu) = f(s+d/2) f(s-d/2)`.

For fixed `d`, the conditional density of `T-mu` is

`g_d(s) = f(s+d/2) f(s-d/2) / m(d)`,

where `m(d)` is its normalizing integral over `s`. This is smooth and strictly positive. Conditioning only on `D>0` instead gives

`g_+(s) = 2 integral_0^infinity f(s+d/2) f(s-d/2) dd`.

The factor 2 normalizes because `P_mu(D>0)=1/2`. The comparison is between two reduced conditional experiments for the scalar statistic `T`: observe `T` conditional on the full ancillary value `D=d`, or observe `T` conditional only on the coarsened ancillary `B=1` (integrating out the unobserved magnitude `D`). Both are valid statistic-level conditional reductions and regular local location families, but they are not the same experiment.

For example, their normalized likelihood ratios at displacement `s` are different. Writing `k=sinh^2(d/4)`, direct use of the hyperbolic cosine product identity gives

`g_d(s)/g_d(0) = [(1+k)/(cosh^2(s/2)+k)]^2`.

The sign-conditioned ratio `g_+(s)/g_+(0)` is the nondegenerate weighted mixture of these ratios over `d>0`, with weights proportional to `f(d/2)^2`. Thus the conditional distributions of the selected statistic `T`, and conditional tests based on `T`, differ between the two reductions.

Important qualification: if the entire original observation `(T,D)` is retained, conditioning its joint law on `B=1` rather than on `D=d` changes the likelihood only by parameter-free normalizing factors, since both statistics are ancillary. This result is not a claim that the full-data likelihood changes on conditioning. It compares different legitimate conditional reference distributions for the reduced statistic `T`; the amount of information conditioned upon differs.

## Local conditional r* distinguishes the two choices

For a smooth symmetric scalar location density `g(s)`, let

`J = - (log g)''(0) > 0`,
`K = (log g)''''(0)`.

The scalar convention above has `phi(mu)= (log g)'(s)`, `j(hat mu)=J`, and `phi'(hat mu)=J`. Taylor expansion around `s=0` yields

`r(s) = sqrt(J) s [1 - K s^2/(24 J) + O(s^4)]`,

`q(s) = sqrt(J) s [1 - K s^2/(6 J) + O(s^4)]`,

and hence

`r*(s) = [sqrt(J) - K/(8 J^(3/2))] s + O(s^3)`.

For the fixed-d conditional density, constants independent of `s` drop from log derivatives. Put `u=d/4` and `J_d=sech^2(u)`. Differentiating
`log f(s+d/2)+log f(s-d/2)` gives

`J_d = sech^2(d/4)`,
`K_d = -J_d + (3/2) J_d^2`.

As `d` decreases to zero, the r* slope tends to `1 - (1/2)/8 = 15/16`.

For the sign-conditioned mixture, compute derivatives under the integral at `s=0`. Its mixing weights are proportional to
`f(d/2)^2 dd`, which become proportional to `sech^4(u) du` for `u=d/4`. Using

`integral_0^infinity sech^4(u) du = 2/3`,
`integral_0^infinity sech^6(u) du = 8/15`,
`integral_0^infinity sech^8(u) du = 16/35`,

gives `E[J_d]=4/5`, `Var(J_d)=8/175`, and `E[K_d]=8/35`. Since the fourth derivative of a mixture's log density also includes `3 Var(J_d)`,

`J_+ = 4/5`,
`K_+ = E[K_d] + 3 Var(J_d) = 64/175`.

The local r* slope after conditioning on `D>0` is therefore

`sqrt(J_+) - K_+/(8 J_+^(3/2)) = 13 sqrt(5)/35`,

which is not `15/16`. By continuity in `d`, fixed-d conditioning for sufficiently small positive `d` also has a slope different from the sign-conditioned result. Thus the conditional scalar r* construction itself changes with the ancillary choice in this smooth example. This is not a comparison between structural representations; it is a comparison between two different, both legitimate conditional experiments.

## Add a nuisance parameter

Append an independent observation `Z ~ Normal(eta,1)`, where `eta` is a nuisance parameter. The full model is

`p_(mu,eta)(x1,x2,z) = f(x1-mu) f(x2-mu) varphi(z-eta)`.

Both `D` and `B=1{D>0}` remain exact ancillaries for the joint parameter `(mu,eta)`. For the same reduced statistic choice `(T,Z)`, conditional on either ancillary the reduced experiments factor as

`g_d(t-mu) varphi(z-eta)` or `g_+(t-mu) varphi(z-eta)`.

The nuisance component is independent and variation-independent: the restricted and unrestricted nuisance MLEs coincide, the likelihood and observed-information blocks are separate, and in the standard product construction of the nuisance adjustment the `eta` factor cancels. Consequently the interest-parameter conditional r* reduces to the scalar calculation above. The conditional r* slopes still differ between the two exact ancillary choices for these reduced experiments, now in a model that does contain a nuisance parameter.

This only treats an orthogonal, independent nuisance component. It does not settle coupled nuisance parameters, where the nuisance-adjusted sample-space derivative and determinant terms can interact with the conditioning choice.

## What is and is not representation-invariant

- If a statistical model, a particular exact ancillary `A`, and the conditional sample-space coordinates are fixed, then two structural maps inducing the same joint distribution give the same conditional likelihood. Any correctly calculated exact conditional likelihood procedure is identical.
- For r*, this invariance additionally requires using the same conditional experiment and transforming all sample-space derivative data covariantly. An arbitrary full structural velocity that moves across the fixed ancillary levels is not a valid substitute for the conditional tangent/sufficient direction.
- Changing the ancillary while also changing the conditional reduction can change the conditional reference distribution and its r* approximation, as the logistic example shows. Exact ancillarity alone does not select a unique reduced conditional procedure.
- For the full observation and an exact ancillary, the conditional likelihood is the original likelihood divided by a parameter-free ancillary density. Its likelihood ratios therefore do not change merely by conditioning; conditional calibration can still depend on the conditioning sigma-field and chosen test statistic.
- The earlier torus model's alternatives `A=Y` and `B=cos(Y)` do *not* change the conditional likelihood for `X`, because `X` is independent of `Y`; that special product structure explains its invariance.
- No result here establishes or refutes representation invariance for general coupled nuisance models or a general Barndorff-Nielsen nuisance r* construction.

## Literature record

Search date: 2026-10-04.

- Local catalog: `uv run python -X utf8 tools/reference_lookup.py "Tangent Exponential Model" --json` returned no entries.
- Supplementary local seed: `tem.md`, Section 4.1 and References, Davison & Reid (2022), *The Tangent Exponential Model*, arXiv:2106.10496. The arXiv HTML page `https://arxiv.org/html/2106.10496` was inspected at Section 6.2 (“No nuisance parameters”), which discusses scalar conditional reductions given ancillary statistics. It is relevant context, not a source for the ancillary-choice counterexample or the nuisance product calculation.
- arXiv exact/terminology/contrary searches attempted:
  - `"r*" ancillary nuisance parameter Fraser`
  - `Barndorff-Nielsen r-star ancillary sample-space derivative nuisance`
  - `ancillary choice different r-star inference counterexample`
  Result pages reported no hits for these exact queries. This is not a literature-wide absence claim.
- SpringerLink was queried with the same three query families; every request failed with HTTP 406, so the result pages and primary texts were unavailable.
- SIAM was queried with the same three query families; every request failed with HTTP 403, so the result pages and primary texts were unavailable.
- No citation closure was completed. Literature status remains `incomplete`; no novelty claim is made.

## Status and next discriminating test

Established for the stated models: (i) a fixed conditional experiment is unchanged by changing only the structural representation; (ii) distinct exact ancillaries can induce distinct conditional reference distributions for a selected reduced statistic and distinct local scalar r* expansions; (iii) this effect persists after adding an independent nuisance parameter.

Open: determine conditions under which two ancillary conditionings yield equivalent conditional experiments; test coupled nuisance parameters with a fully specified general nuisance r* formula and structurally distinct but distribution-equivalent transports. The next useful example should have a coupled nuisance parameter and an exact ancillary, and should compare the complete nuisance-adjusted r* ingredients rather than only the profile likelihood.
