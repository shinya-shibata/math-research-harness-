# Theorem-style counterexample to the general Fraser implication

Date: 2026-10-06
Agent: GitHub Copilot in VS Code
Scope: theorem-proof formulation of the strongest negative statement presently justified by the model-specific evidence.
Status: `refuted` as a general theorem; `verified-computationally` for the explicit ambient model and exact symbolic formulas below.

## Theorem

Let `F` denote the Frobenius curvature of a selected sample-space structural
distribution, and let `R_perp^(alpha)` denote the curvature of the induced normal
connection in a fixed Fisher ambient. Then the implication

`F = 0  =>  R_perp^(alpha) = 0`

is false in general.

More precisely, there exists a smooth, regular, codimension-two exponential-tilt
ambient in which the structural location-scale distribution is involutive, while
its induced Fisher-normal Levi-Civita connection has nonzero curvature.

## Ambient model

Consider the explicit codimension-two logistic-tilt ambient from
[20261004-fraser-fm34-bridge/integrable-structural-nonflat-normal.md](./20261004-fraser-fm34-bridge/integrable-structural-nonflat-normal.md):

`u=(x-mu)*exp(-tau)`,
`y=tanh(u/2)`,
`f(u)=1/(4*cosh(u/2)^2)`,
`h1(y)=y^3-3y/5`,
`h2(y)=y^4-14y^2/15+1/9`.

Define

`p(x;mu,tau,k1,k2)
 = exp(-tau) * f(u)
   * exp(k1*h1(y)+k2*h2(y)-C(k1,k2))`,

with `C(k1,k2)` the normalizing constant. The location-scale submodel is
`S={(mu,tau,k1,k2): k1=k2=0}`.

## Proof

On the submodel `S`, the sample-space structural velocity fields are

`v_mu(x)=(1,...,1)`,
`v_tau(x)=(x_1-mu,...,x_n-mu)`.

A direct differentiation yields

`[v_mu, v_tau] = v_mu`.

Hence the rank-two distribution `span{v_mu,v_tau}` is involutive. In the usual
Frobenius notation, the structural curvature is zero:

`F = 0`.

Now compute the induced normal connection on the codimension-two Fisher normal
bundle. The exact symbolic computation in
`research-scratch/fraser_structural_geometry/20261004-fraser-fm34-bridge/codim2_curvature.py`
shows that the normal Fisher Gram matrix is positive definite and the normal-score
fields are orthogonal to the tangent directions, while the Levi-Civita normal
connection coefficient satisfies

`R_perp,mu,tau^(0) = exp(-tau) * [[0,-28/45],[9/4,0]]`.

Since the off-diagonal entries are nonzero, this matrix is not the zero matrix:

`R_perp,mu,tau^(0) != 0`.

Therefore, in this explicit regular ambient, the structural distribution is
integrable but the induced normal connection is nonflat.

This contradicts the general implication

`F = 0  =>  R_perp^(alpha) = 0`.

Hence the implication is false without additional hypotheses fixing the ambient
model, immersion, metric, normal bundle, and connection.

QED.

## Corollary

The implication

`structural integrability => flat ambient normal transport`

cannot be used as a general Fraser theorem. A correct theorem must include the
ambient data and the selected connection as part of the statement.

## Minimality of the counterexample

This counterexample is minimal in the relevant sense:

1. it uses only the two tangent directions `(mu,tau)`;
2. the normal bundle has codimension two;
3. the offending implication is the single conditional claim
   `F=0 => R_perp=0`;
4. the result does not claim a universal theorem about all Fraser models or all
   ancillaries; it isolates a single false general implication.

## Evidence and verification

The computation was reproduced with

`uv run python research-scratch/fraser_structural_geometry/20261004-fraser-fm34-bridge/codim2_curvature.py`

and the script reports:

- `normal_scores_orthogonal = true`
- `positive_normal_fisher = true`
- `lc_curvature_nonzero = true`

Thus the theorem-style counterexample is established in the explicit ambient model
and its exact symbolic formulas are reproducible.

## Corrected general statement

The valid general statement is not a flatness theorem but a boundary theorem:

> Structural integrability alone does not determine the induced normal geometry.
> A curvature or holonomy statement requires a fixed ambient Fisher manifold,
> immersion, metric, and normal connection, together with explicit regularity and
> rank assumptions on the chosen normal bundle.
