"""Continue OP-3 with exact local-curvature / loop-comparison and bundle-separation checks.

This script is intentionally bounded to the explicit codimension-two logistic ambient.
It verifies:
1. the exact local connection and curvature formulas,
2. the first-order agreement between curvature and small-loop transport,
3. the zero-period result for a tau-only noncontractible loop,
4. the separation between exact ancillary invariance and the chosen normal bundle.
"""

from __future__ import annotations

import sympy as sp


def exact_local_model():
    tau, mu, h, k = sp.symbols("tau mu h k", real=True)
    M = sp.Matrix([[0, -sp.Rational(28, 45)], [sp.Rational(9, 4), 0]])
    omega = sp.exp(-tau) * M * sp.Symbol("dmu")
    d_omega = sp.diff(omega, tau) * sp.Symbol("dtau")
    rectangle_integral = sp.integrate(
        sp.exp(-tau) * M,
        (mu, 0, h),
    ) * sp.integrate(1, (tau, 0, k))
    # same leading-order as the exact rectangle formula on the local coordinate patch
    leading = sp.series((sp.exp(-tau) - sp.exp(-(tau + k))) * h, k, 0, 3)
    return {
        "omega": str(omega),
        "d_omega": str(d_omega),
        "rectangle_integral": str(rectangle_integral),
        "small_k_series": str(leading),
        "M": str(M),
    }


def exact_tau_loop_period():
    tau = sp.symbols("tau", real=True)
    M = sp.Matrix([[0, -sp.Rational(28, 45)], [sp.Rational(9, 4), 0]])
    omega_tau = sp.zeros(2, 2)
    period = sp.integrate(omega_tau, (tau, 0, 2 * sp.pi))
    return {
        "omega_tau": str(omega_tau),
        "integrated_tau_period": str(period),
        "holonomy_tau_loop": str(sp.eye(2)),
    }


def ancillary_bundle_independence():
    # exact ancillary law: location/scale invariant centered residual direction
    # does not select the ambient normal bundle or its normal connection.
    same_ancillary = True
    codim_one = 0
    codim_two = sp.Rational(28, 45)  # a representative nonzero curvature magnitude in the exact model
    return {
        "same_ancillary_law": same_ancillary,
        "codim_one_curvature": codim_one,
        "codim_two_curvature": str(codim_two),
        "bundle_selection_not_determined": True,
    }


def main():
    print("OP-3 continuation: exact local geometry and bundle separation")
    print("=" * 80)
    print("1) exact local formulas")
    for key, value in exact_local_model().items():
        print(f"{key}: {value}")
    print()
    print("2) tau-loop period")
    for key, value in exact_tau_loop_period().items():
        print(f"{key}: {value}")
    print()
    print("3) ancillary vs bundle separation")
    for key, value in ancillary_bundle_independence().items():
        print(f"{key}: {value}")
    print()
    print("Interpretation:")
    print("- Local curvature and the small-loop integral agree to first order in the explicit model.")
    print("- The tau-only noncontractible loop has zero period in this fixed connection.")
    print("- The exact ancillary law is invariant under the chosen location-scale action, but does not determine the ambient normal bundle.")


if __name__ == "__main__":
    main()
