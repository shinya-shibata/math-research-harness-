# OP-3: exact transport propositions for the explicit codimension-two model

Date: 2026-10-06
Agent: GitHub Copilot in VS Code
Scope: bounded continuation of the explicit OP-3 model.
Status: `verified-computationally` in the explicit ambient; not a general Fraser theorem.

## Setup

On the explicit codimension-two logistic-tilt ambient already verified in
[20261004-fraser-fm34-bridge/integrable-structural-nonflat-normal.md](./20261004-fraser-fm34-bridge/integrable-structural-nonflat-normal.md),
use the Levi-Civita normal connection on the location-scale submodel
`S={(mu,tau,k1,k2):k1=k2=0}`.

The induced normal connection form is

`omega = omega_mu dmu + omega_tau dtau`,

with

`omega_mu = exp(-tau) M`,
`omega_tau = 0`,

and

`M = [[0, -28/45], [9/4, 0]]`.

The curvature form is therefore

`R_perp = d omega + omega ∧ omega = exp(-tau) M dmu ∧ dtau`,

since `omega_tau=0` and `omega ∧ omega = 0` in this rank-one `dmu`-only connection.

## Proposition 1: exact rectangular-loop transport

Let `Γ_{h,k}` be the rectangle with corners

`(mu0,tau0) -> (mu0+h,tau0) -> (mu0+h,tau0+k) -> (mu0,tau0+k) -> (mu0,tau0)`.

Then the path-ordered transport matrix is exactly

`P(Γ_{h,k}) = exp(h (exp(-tau0) - exp(-(tau0+k))) M)`,

because the vertical edges have `dmu=0` and thus contribute identity, while the
horizontal edges contribute the matrix exponential of the accumulated `omega_mu`.

Expanding this exact expression for small `k` gives

`P(Γ_{h,k}) = I + h*k*exp(-tau0) M + O(h*k*(h+k))`.

But

`∬_{rectangle} R_perp
 = h*k*exp(-tau0) M + O(h*k*(h+k))`.

Hence the exact loop transport matches the local curvature term to first order.

### Proof sketch

The connection form along a horizontal edge has the form
`omega = exp(-tau) M dmu`, and the vertical edges have `dmu=0`.
Therefore the path-ordered transport reduces to the product of the two horizontal
edge transports, yielding the displayed matrix exponential. The expansion follows
from the matrix exponential series, and the curvature calculation is the direct
exterior derivative of `omega` on the rectangle.

## Proposition 2: zero period on a tau-only noncontractible loop

Let `γ(s) = (mu0, tau0 + 2π s)`, a loop around the `tau` direction on the
cylinder. Since `omega_tau=0` and `dmu=0` on this loop, we have

`omega(γ̇(s)) = 0` for all `s`.

Therefore the parallel transport is exactly identity:

`P(γ) = I`.

The corresponding period is zero in this connection.

Hence a nonzero local curvature does not by itself determine nontrivial global
holonomy in this explicit model.

## Proposition 3: ancillary law does not select the normal bundle

The exact location-scale ancillary

`A_i(X) = (X_i - mean(X)) / ||X - mean(X)||`

is parameter-free for `(mu,tau)` and remains invariant under the location-scale
action. However, this ancillary law does not determine the normal bundle or its
connection.

The same exact ancillary law can be embedded in two different ambient
extensions:

- codimension-one logistic ambient extension: the induced normal curvature is zero;
- codimension-two logistic ambient extension: the induced normal curvature is
  nonzero and equal to `exp(-tau) M` in the explicit calculation.

Thus the ancillary law is not a sufficient selector of the normal bundle, the
normal connection, or the resulting holonomy.

## Conclusion

For the explicit OP-3 model, the following are now exact:

- local curvature is nonzero;
- small-loop transport agrees with the local curvature to leading order;
- noncontractible `tau`-loops have zero period in the chosen connection;
- exact ancillary invariance does not determine the ambient normal bundle.

These statements are already enough to rule out the naive general Fraser claim
that structural integrability or exact ancillary status alone yields flat normal
transport. They do not yet identify a universal theorem, but they do isolate the
correct local/global distinction.
