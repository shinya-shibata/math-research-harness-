# FM-31 candidate review

Date: 2026-10-04
Agent: GitHub Copilot
Thread: `fraser_structural_geometry`
Review type: bounded audit of one existing candidate

## Outcome

- Work status: `screened` (candidate-specific queries attempted at all three
  required providers; review remains incomplete).
- Evidence status of the original statement: `refuted` when “usual local
  alpha-connection data” means smooth statistical-manifold geometry. The
  counterexamples below have pointwise differentiable log densities, finite
  score moments of every order, and positive Fisher information. They
  demonstrate discontinuous Fisher information, discontinuous cubic score
  despite a continuous metric, and discontinuous cubic score despite a
  constant metric. If the candidate means only pointwise moment arrays, that
  weaker reading does not assert a smooth affine connection.
- Evidence status of the corrected conditional statement below:
  `proved/agent`.
- Low-regularity continuation: `proved/agent` that `g` of class `C^1` and
  continuous `T` yield a continuous-coefficient dualistic alpha connection
  with distributional curvature; a further dominated family shows constant
  positive `g` and pointwise finite moments do not ensure that connection is
  continuous for `alpha != 0`.
- Literature review: `incomplete`; arXiv searches were inspected, but Springer
  and SIAM query pages were inaccessible to this session. No novelty claim is
  made.
- Canonical state and manuscript: unchanged.

## Candidate as generated

FM-31 states:

> For a dominated nonexponential family with differentiable log density,
> finite score second and third moments, and positive Fisher information,
> the Fisher metric and score cubic tensor define the usual local
> alpha-connection data.

The candidate leaves the regularity meant by “differentiable log density” and
“usual local alpha-connection data” unspecified. Finite pointwise second and
third score moments give a finite Fisher matrix and cubic score tensor at each
parameter value. They do not, by themselves, assert that these fields vary
smoothly enough to define a smooth metric and affine connection, or justify
any differentiation-under-the-integral identities used to express connection
coefficients in terms of log-density derivatives.

## Corrected conditional statement and derivation

Let the parameter space be a smooth finite-dimensional manifold. Suppose a
positive density family `p_theta` is dominated by one fixed measure, its score
`s_i = partial_i log p_theta` has finite second and third products, and
`g_ij = E_theta[s_i s_j]` is positive definite. In addition, require `g` and
`T_ijk = E_theta[s_i s_j s_k]` to have the regularity needed for the
Christoffel symbols and their coordinate transformations (smooth fields are a
sufficient condition). If formulae involving derivatives of `log p_theta`
are used, also require the corresponding differentiability, integrability,
and differentiation-under-the-integral conditions.

Then, in the convention fixed by the thread ledger,

`Gamma^(alpha) = Gamma^(0) - alpha*T^sharp/2`,

defines the usual one-parameter family of local alpha connections. Here
`Gamma^(0)` is the Levi-Civita connection of the Fisher metric, and
`T^sharp` is obtained by raising one index of the cubic tensor with `g`.
This is a construction from the regular statistical model's intrinsic
geometry and does not require an exponential-family representation.

The algebraic difference from `Gamma^(0)` is tensorial: `T` is a symmetric
covariant 3-tensor and raising an index with the metric gives a tensor of type
`(1,2)`. Consequently each `Gamma^(alpha)` is an affine connection whenever
the stated metric and tensor regularity holds. This does not provide an
ambient immersion, a second fundamental form, normal curvature, or any
Fraser-specific ancillary conclusion.

## Discriminating model check: logistic location-scale family

Take `X = mu + sigma*Z`, where `mu` is real, `sigma > 0`, and `Z` has the
standard logistic density. The family is dominated by Lebesgue measure on
the fixed support `R`. Write `z=(x-mu)/sigma` and `t=tanh(z/2)`. Direct
differentiation gives

`s_mu = t/sigma`, and `s_sigma = (z*t - 1)/sigma`.

The standard logistic tails decay exponentially, and `|t| <= 1`, so the
absolute value of either score is bounded by `(1+|z|)/sigma`. Every score
product of degree at most three is therefore integrable. Under the
transformation `t=2*F_Z(z)-1`, `t` is uniform on `(-1,1)`, giving

`g_mumu = 1/(3*sigma^2)`,
`g_musigma = 0`,
`g_sigmasigma = E[(Z*t-1)^2]/sigma^2 > 0`.

The final strict inequality holds because `Z*t-1` is not constant under a
continuous, nondegenerate distribution. Thus the Fisher metric is positive
definite. Standardizing by `z` shows that the entries of `g` and `T` are
constants times `sigma^-2` and `sigma^-3`, respectively, so these tensor
fields are smooth on `R x (0,infinity)`. Hence the corrected conditional
construction applies to this model.

This is a non-exponential family in the usual finite-dimensional
sufficient-statistic sense. For fixed `sigma`, its location score functions
are the translates `sigma^-1*tanh((x-mu)/(2*sigma))`. For distinct real
values of `mu`, these functions are linearly independent: in their
meromorphic continuations, the function indexed by `mu` has a pole at
`x=mu+i*pi*sigma` not shared by the functions indexed by other distinct
locations. A finite-dimensional exponential family would put all its score
functions in the finite-dimensional span of its sufficient statistics and a
constant. The location subfamily already violates that necessary condition.

This check establishes that exponentiality is not necessary for the
conditional metric/cubic-tensor/alpha-connection construction. It does not
validate the weaker regularity hypotheses in the original FM-31 wording for
every dominated family.

## Counterexample to the stated regularity sufficiency

This construction uses a countable sample space with counting measure and
parameter `theta` in `(-1,1)`. Outcomes are pairs `(k,y)`, where
`k=0,1,2,...` and `y` is either `-1` or `+1`. Set

`c = 1/2`, `w_n = 2^(-n)/4`, `q_n = w_n^2` for `n >= 1`, and
`q_0 = 1 - sum_(n>=1) q_n = 47/48`.

Choose a smooth bump `phi` supported in `(-1,1)`, with `|phi| <= 1`, and
choose `u_0` such that `phi(u_0) != 0` and `phi'(u_0) != 0`. Define
`b_0(theta)=c*theta`, `b_n(theta)=(1/2)*phi((theta-2^(-n))/w_n)`, and

`p_theta(k,y) = q_k*(1 + y*b_k(theta))/2`.

The support intervals of the nonzero `b_n` are disjoint, since they have
centers `2^(-n)` and radii `w_n=2^(-n)/4`. For every `theta`, at most one
`b_n(theta)` with `n>=1` is nonzero. Also `|b_k(theta)|<1`, so every atom has
positive probability. Summing over `y` gives `q_k`; hence the probabilities
sum to one. Each individual `p_theta(k,y)` is smooth in `theta`, so its log
density is pointwise differentiable (indeed smooth), and the family has a
common dominating measure.

This model is not a finite-dimensional exponential family. For each `n`,
the log probability ratio between outcomes `(n,+1)` and `(n,-1)` is
`2*artanh(b_n(theta))`. These are nonzero functions supported on pairwise
disjoint intervals, hence form an infinite linearly independent family.
In any finite-dimensional exponential family, all such log probability
ratios lie in the finite-dimensional span of the natural-parameter
coordinate functions and the constant function. The infinite independent
family contradicts that necessary condition.

For an active coordinate `k`, the score is
`s_theta(k,y)=y*b'_k(theta)/(1+y*b_k(theta))`. Its contribution to Fisher
information is

`q_k*b'_k(theta)^2/(1-b_k(theta)^2)`.

Consequently

`g(theta) = q_0*c^2/(1-c^2*theta^2)
          + sum_(n>=1) q_n*b'_n(theta)^2/(1-b_n(theta)^2)`.

At any fixed `theta`, the sum has at most one nonzero term. All score moments
of every finite order are therefore finite at each fixed parameter value:
there are only the two baseline atoms and at most one active pair, and all
their probabilities are positive. The baseline term also gives
`g(theta) >= q_0*c^2 > 0` everywhere.

Now let `theta_n=2^(-n)+w_n*u_0`. Then `theta_n -> 0` and the `n`th bump is
the only active bump there. Since `q_n=w_n^2`,

`q_n*b'_n(theta_n)^2
 = (1/4)*phi'(u_0)^2 > 0`.

Thus `g(theta_n)` stays above its baseline limit at zero by a fixed positive
amount, while all bumps and their derivatives vanish at zero and
`g(0)=q_0*c^2`. The Fisher metric is discontinuous at zero. In addition, the
third score moment contributed by the active pair is

`-2*q_n*b_n*b'_n^3/(1-b_n^2)^2`.

At `theta_n` its absolute value grows proportionally to `1/w_n`, so the cubic
score field is locally unbounded near zero, although it remains finite at
each individual parameter value.

Therefore common domination, pointwise differentiability of log density,
finite pointwise second and third score moments, and pointwise positive Fisher
information do not suffice for smooth Fisher metric and cubic-tensor fields.
In particular they do not suffice for the usual smooth affine-connection
package in which `Gamma^(0)` is the Levi-Civita connection of a smooth Fisher
metric. This does not refute the pointwise algebraic definitions of `g` and
`T`; it refutes the inference from the stated assumptions to smooth
statistical-manifold geometry.

## Stronger obstruction with continuous Fisher information

The preceding example makes `g` discontinuous. To test whether simply adding
continuity of the Fisher metric would repair FM-31, keep the same sample space,
parameter interval, bump functions, and definitions of `b_k`, but instead set

`w_n=2^(-n)/4`, `q_n=w_n^3`, and `q_0=1-sum_(n>=1)q_n=447/448`.

Use the explicit smooth bump
`phi(u)=exp(-1/(1-u^2))` for `|u|<1` and zero otherwise, with `u_0=1/2`.
It satisfies `0<phi(u_0)<1` and `phi'(u_0) != 0`; the support intervals
remain disjoint. Define `b_0(theta)=theta/2`,
`b_n(theta)=phi((theta-2^(-n))/w_n)/2`, and
`p_theta(k,y)=q_k*(1+y*b_k(theta))/2` as above. Normalization, positivity,
common domination, pointwise smoothness, finite pointwise moments of every
order, and the finite-dimensional non-exponential argument are unchanged.

Now the `n`th bump's Fisher contribution is

`q_n*b'_n(theta)^2/(1-b_n(theta)^2)
 = (w_n/4)*phi'(u)^2/(1-phi(u)^2/4)`,

where `u=(theta-2^(-n))/w_n`. The factor multiplying `w_n` is bounded on
`[-1,1]`; away from `theta=0`, only finitely many bump supports meet a
neighborhood, and the supremum of the active contribution near zero tends to
zero. Thus `g` is continuous at zero as well as elsewhere, and is bounded
below by the positive baseline `q_0/4`.

The active bump's third score moment is

`-2*q_n*b_n*b'_n^3/(1-b_n^2)^2
 = -phi(u)*phi'(u)^3 /
   (8*(1-phi(u)^2/4)^2)`.

At `theta_n=2^(-n)+w_n*u_0` this is a fixed nonzero value, independent of
`n`. At `theta=0`, every bump and its derivative vanishes, and the baseline
third moment is also zero because `b_0(0)=0`. Hence `T(theta_n)` does not
converge to `T(0)`: the score cubic is discontinuous at zero despite
continuity and positive definiteness of `g`.

This sharper example shows that continuity of the Fisher metric, together
with pointwise finite score moments, still does not ensure continuity of the
cubic tensor. Under the smooth statistical-manifold convention, it therefore
still does not supply the regularity required by
`Gamma^(alpha)=Gamma^(0)-alpha*T^sharp/2`.

## Explicit sufficient regularity condition

The corrected geometric assertion can be stated without presuming that
pointwise moments automatically vary smoothly. On a parameter chart, assume
the family is positive and dominated by a fixed measure, and define
`s_i=partial_i log p_theta`,
`g_ij(theta)=integral p_theta*s_i*s_j`, and
`T_ijk(theta)=integral p_theta*s_i*s_j*s_k`. Suppose `g` is positive
definite and both `g_ij` and `T_ijk` are smooth functions of `theta`.
Then `T` is a symmetric covariant 3-tensor: under a smooth coordinate change
the score transforms by the Jacobian, and its third product transforms by
three copies of that Jacobian. Raising an index with the smooth metric gives
a smooth tensor `T^sharp`; the Levi-Civita connection `Gamma^(0)(g)` is
smooth. Therefore

`Gamma^(alpha) = Gamma^(0)(g) - alpha*T^sharp/2`

is a smooth affine connection for every real `alpha`. This proves the
conditional geometric statement, without requiring an exponential-family
representation.

A concrete sufficient route to the smoothness premise is local dominated
differentiation: for each compact parameter subset and every multi-index
`gamma`, require the parameter derivatives of the integrands
`p_theta*s_i*s_j` and `p_theta*s_i*s_j*s_k` to exist pointwise and be
dominated by an integrable envelope independent of `theta` in that subset.
Dominated convergence then makes the moment fields smooth. This envelope
condition is sufficient, not claimed necessary; the counterexample violates
the resulting continuity of the moment fields.

## Literature search record

### Independent question-driven baseline

The pre-generation baseline was performed on 2026-09-30 and is documented in
the [candidate-batch manifest](../20260930-231402/batch-manifest.md), under
“Generation-Before-Candidates Literature Pass.” It searched arXiv,
SpringerLink, and SIAM independently before consulting local bibliographies.
That pass found incomplete Springer result snapshots and SIAM 403/Cloudflare
responses; it is not treated as an FM-31 candidate screen.

### Candidate-specific questions (2026-10-04)

Queries were submitted directly to each provider. Provider results are not
global-corpus coverage.

| Family | arXiv query and inspected outcome | SpringerLink query and outcome | SIAM query and outcome |
|---|---|---|---|
| Exact claim | [`nonexponential dominated model Fisher metric score cubic alpha connection exact claim`](https://arxiv.org/search/?searchtype=all&abstracts=show&order=-announced_date_first&query=nonexponential+dominated+model+Fisher+metric+score+cubic+alpha+connection+exact+claim); search page inspected, 0 results reported. | `nonexponential dominated model Fisher metric score cubic alpha connection` ([query page](https://link.springer.com/search?query=nonexponential%20dominated%20model%20Fisher%20metric%20score%20cubic%20alpha%20connection)); HTTP 406, no results inspectable. | Same terms ([query page](https://epubs.siam.org/action/doSearch?AllField=nonexponential%20dominated%20model%20Fisher%20metric%20score%20cubic%20alpha%20connection)); HTTP 403, no results inspectable. |
| Terminology variant | [`Fisher metric cubic tensor alpha connection statistical model`](https://arxiv.org/search/?searchtype=all&abstracts=show&order=-announced_date_first&query=%22Fisher+metric%22+%22cubic+tensor%22+alpha+connection+statistical+model); search page inspected, 0 results reported. | [Same query](https://link.springer.com/search?query=%22Fisher%20metric%22%20%22cubic%20tensor%22%20alpha%20connection%20statistical%20model); HTTP 406. | [Same query](https://epubs.siam.org/action/doSearch?AllField=Fisher%20metric%20cubic%20tensor%20alpha%20connection%20statistical%20model); HTTP 403. |
| Contrary result / assumptions | [`statistical alpha connection third score moment regularity counterexample`](https://arxiv.org/search/?searchtype=all&abstracts=show&order=-announced_date_first&query=statistical+alpha+connection+third+score+moment+regularity+counterexample); search page inspected, 0 results reported. | [Same query](https://link.springer.com/search?query=statistical%20alpha%20connection%20third%20score%20moment%20regularity%20counterexample); HTTP 406. | [Same query](https://epubs.siam.org/action/doSearch?AllField=statistical%20alpha%20connection%20third%20score%20moment%20regularity%20counterexample); HTTP 403. |

An additional arXiv query, `Amari-Chentsov tensor alpha-connection regular
statistical model score`, returned 0 results. The arXiv search syntax treats
unquoted terms conjunctively, so these zero-result pages are not evidence of
absence.

### Supplementary local-reference route

The local reference catalog was checked first with
`uv run python tools/reference_lookup.py "Fisher information alpha connection
cubic score tensor"` and
`uv run python tools/reference_lookup.py "Methods of Information Geometry"`;
both returned no matches because the catalog currently has no local reference
records.

The relevant cited local source is Amari and Nagaoka, *Methods of Information
Geometry* (2000), cited in the References section of `tem.md` and
`ancillary_holonomy_paper_revised_md.md`. The exact-title/author query
[`"Methods of Information Geometry" Amari Nagaoka`](https://arxiv.org/search/?searchtype=all&abstracts=show&order=-announced_date_first&query=%22Methods+of+Information+Geometry%22+Amari+Nagaoka)
was submitted to arXiv (0 results), [SpringerLink](https://link.springer.com/search?query=%22Methods%20of%20Information%20Geometry%22%20Amari%20Nagaoka)
(HTTP 406), and [SIAM](https://epubs.siam.org/action/doSearch?AllField=%22Methods%20of%20Information%20Geometry%22%20Amari%20Nagaoka)
(HTTP 403). The supplementary arXiv query
[`information geometry alpha connections Amari Chentsov Fisher metric`](https://arxiv.org/search/?searchtype=all&abstracts=show&order=-announced_date_first&query=information+geometry+alpha+connections+Amari+Chentsov+Fisher+metric)
returned 0 results. The publisher's [AMS/Oxford book page](https://bookstore.ams.org/mmono-191/)
was inspected for bibliographic identity and its description of Fisher
metrics and alpha connections; it does not state the precise score-moment
assumptions used here.

The arXiv record for Nielsen, “An elementary introduction to information
geometry” (arXiv:1808.08271), was inspected as a broad secondary lead. The
HTML source page exposed section 3.7 on dually flat manifolds, but it was not
used as verification of the exact FM-31 claim or its regularity hypotheses.
No backward/forward citation closure was completed because the relevant
provider results were unavailable or returned no exact candidate result.

## Best next discriminating step

The remaining theoretical question is to identify weaker-than-smooth
regularity thresholds, if any, under which the desired alpha-connections
remain meaningful in an appropriate low-regularity category. For the usual
smooth statistical-manifold convention, the sufficient formulation above and
the two counterexamples isolate the issue: smooth moment fields work, while
pointwise finite moments—even with a continuous Fisher metric—do not ensure
continuity of the cubic field.

### Continuation record

Date: 2026-10-04 12:14:25 (OS local time)

This continuation strengthened the prior counterexample with an explicit
bump function and a second scaling (`q_n=w_n^3`) that leaves the Fisher metric
continuous while keeping the cubic score field discontinuous. The derivation
is analytic; no floating-point or external computation was used.

## Continuation: low-regularity connection and sharp obstruction

Date: 2026-10-04 12:33:37 (OS local time)

### A low-regularity definition that is available

Let the parameter domain be a smooth manifold. In a smooth coordinate chart,
assume that the Fisher matrix `g` is `C^1` and positive definite and that the
score cubic `T` is continuous. Then the Levi-Civita coefficients

`Gamma^(0)_{ij}^k =
 (1/2) g^(kℓ)(partial_i g_(jℓ) + partial_j g_(iℓ) - partial_ℓ g_(ij))`

are continuous. Raising an index of `T` with `g` also gives a continuous
tensor `T^sharp`. Therefore

`Gamma^(alpha) = Gamma^(0) - (alpha/2)*T^sharp`

has continuous coefficients and obeys the affine-connection coordinate
transformation law. It defines a continuous-coefficient connection: for
`C^1` vector fields its covariant derivative is continuous and obeys the
connection linearity and Leibniz rules. Since `T^sharp` is symmetric in its
two vector-field inputs, this connection is torsion-free. Moreover, for `C^1`
vector fields `X,Y,Z`, metric compatibility of `Gamma^(0)` and cancellation
of the opposite cubic terms give

`X[g(Y,Z)] = g(nabla^(alpha)_X Y,Z)
           + g(Y,nabla^(-alpha)_X Z)`.

Thus a continuous dualistic alpha-connection package is available without
requiring smooth `g` or `T`. Along `C^1` paths its parallel-transport
equation is a linear ODE with continuous coefficients, so parallel transport
is well-defined. This is a low-regularity extension of the connection
construction, not a claim that the manifold is smooth in the usual
information-geometric sense.

More generally, for an integer `r >= 0`, `g` of class `C^(r+1)` and `T` of
class `C^r` give alpha-connection coefficients of class `C^r`. For `r >= 1`
the classical curvature tensor is defined with `C^(r-1)` coefficients. For
`r=0`, the coefficients are continuous but not necessarily differentiable;
the curvature is defined below as a coordinate-invariant distribution, not a
classical pointwise tensor. These are sufficient regularity levels, not a
claim of a globally minimal function-space scale.

### A model with constant Fisher metric but discontinuous cubic

The previous continuous-metric example did not isolate the cubic regularity
from differentiability of the metric. The following variant keeps the Fisher
metric exactly constant and still has a discontinuous score cubic.

Use the countable sample space `(k,y)` and the disjoint bump functions from
the previous example, with parameter `theta` in a sufficiently small open
interval `(-epsilon,epsilon)` about zero. First define the bump family and
`R` on `(-1,1)`; `R` is bounded there, and set

`w_n=2^(-n)/4`, `q_n=w_n^3`, `q_0=1-sum_(n>=1)q_n=447/448`,
`phi(u)=exp(-1/(1-u^2))` for `|u|<1` and zero otherwise,
`u_0=1/2`,
`b_n(theta)=phi((theta-2^(-n))/w_n)/2` for `n>=1`.

Let

`R(theta) = sum_(n>=1) q_n*b'_n(theta)^2/(1-b_n(theta)^2)`.

At most one term is nonzero at each parameter. The `n`th term is
`(w_n/4)*phi'(u)^2/(1-phi(u)^2/4)`, so `R` is bounded and continuous,
including at zero where it vanishes. Set `G=1+sup_(theta in (-1,1)) R(theta)`. Define

`b_0(theta) = sin(integral_0^theta sqrt((G-R(t))/q_0) dt)`.

Choose `epsilon > 0` small enough that the integral has absolute value less
than `pi/4` throughout `(-epsilon,epsilon)`. Then `b_0` is `C^1`,
`|b_0|<1`, and

`b'_0(theta)^2/(1-b_0(theta)^2) = (G-R(theta))/q_0`.

For outcomes `(k,y)`, define the probabilities exactly as before:

`p_theta(k,y) = q_k*(1+y*b_k(theta))/2`.

They are positive, sum to one, share counting measure as a dominating
measure, and are pointwise `C^1` in the parameter. At each parameter only
the baseline pair and at most one bump pair contribute nonzero scores, so
all finite score moments exist pointwise. The Fisher information is

`g(theta) = q_0*b'_0(theta)^2/(1-b_0(theta)^2) + R(theta) = G`,

a positive constant. Hence its Levi-Civita connection vanishes in this
coordinate.

The third score moment is the sum over active pairs of
`-2*q_k*b_k*b'_k^3/(1-b_k^2)^2`. The baseline contribution is continuous
because `b_0` and `b'_0` are continuous, and it is zero at `theta=0`.
At `theta_n=2^(-n)+w_n*u_0`, the `n`th bump contribution equals

`-phi(u_0)*phi'(u_0)^3 /
 (8*(1-phi(u_0)^2/4)^2)`,

a fixed nonzero constant independent of `n`. Since `theta_n -> 0`, the
total cubic score is discontinuous at zero. For any nonzero `alpha`, the
coefficient `Gamma^(alpha) = -alpha*T/(2G)` is consequently discontinuous.

The family is not finite-dimensional exponential: for infinitely many bump
indices whose supports lie in the parameter interval, the log probability
ratios `log(p_theta(n,+1)/p_theta(n,-1))=2*artanh(b_n(theta))` are nonzero
and have pairwise disjoint supports. They are linearly independent as
functions of `theta`, whereas all log probability ratios in a finite
dimensional exponential family lie in one fixed finite-dimensional span.

This proves a sharper necessity statement for continuous-coefficient
alpha-connections in this class: even a constant positive Fisher metric and
pointwise finite score moments do not suffice; for `alpha != 0`, continuity
of the cubic contribution is needed unless some additional structure
supplies continuity by another route. For `alpha=0`, only the Levi-Civita
part remains, so the metric's `C^1` regularity is the relevant condition.

### Distributional curvature for a continuous-coefficient connection

In a smooth local frame, write the continuous connection one-form as
`A = sum_i A_i dx^i`, with continuous matrix-valued coefficient functions.
Define

`F = dA + A wedge A`

in the sense of distributions: the entries of `dA` are distributional
derivatives of continuous functions, while `A wedge A` is continuous. If a
smooth change of frame is given by a matrix `S`, then
`A' = S^(-1) A S + S^(-1) dS`. Distributional differentiation obeys the
product rule with smooth functions, so direct expansion gives
`F' = S^(-1) F S` as distributions. Under a smooth coordinate change,
`F` also transforms as a 2-form. Thus this curvature is a well-defined
distribution-valued endomorphism-valued 2-form, even though it need not have
pointwise values.

For continuous `alpha`-connection coefficients, this construction applies
to each alpha. Along `C^1` loops the continuous connection still defines
parallel transport and hence holonomy operators. No claim is made here that
the distributional curvature determines those holonomies through a
classical Ambrose-Singer theorem, or that it yields a pointwise curvature
criterion for ancillary behavior. Establishing a useful curvature-holonomy
theorem at this regularity remains open.

### Provider search record for this continuation

Search date: 2026-10-04. Queries targeted low-regularity statistical
connections, regularity of Christoffel symbols, and weak curvature. Search
pages were requested directly; result coverage was not global.

| Query family | arXiv | SpringerLink | SIAM |
|---|---|---|---|
| Exact: `low regularity statistical manifold continuous connection Fisher metric` | [Search page](https://arxiv.org/search/?searchtype=all&abstracts=show&order=-announced_date_first&query=low+regularity+statistical+manifold+continuous+connection+Fisher+metric) inspected; 0 results reported. | [Query](https://link.springer.com/search?query=low%20regularity%20statistical%20manifold%20continuous%20connection%20Fisher%20metric); HTTP 406, no results inspectable. | [Query](https://epubs.siam.org/action/doSearch?AllField=low%20regularity%20statistical%20manifold%20continuous%20connection%20Fisher%20metric); HTTP 403, no results inspectable. |
| Neighboring: `C1 Riemannian metric continuous Christoffel symbols connection` | [Search page](https://arxiv.org/search/?searchtype=all&abstracts=show&order=-announced_date_first&query=C1+Riemannian+metric+continuous+Christoffel+symbols+connection) inspected; 0 results reported. | [Query](https://link.springer.com/search?query=C1%20Riemannian%20metric%20continuous%20Christoffel%20symbols%20connection); HTTP 406, no results inspectable. | [Query](https://epubs.siam.org/action/doSearch?AllField=C1%20Riemannian%20metric%20continuous%20Christoffel%20symbols%20connection); HTTP 403, no results inspectable. |
| Weak-curvature boundary: `weak curvature low regularity Riemannian metric distributional` | [Search page](https://arxiv.org/search/?searchtype=all&abstracts=show&order=-announced_date_first&query=weak+curvature+low+regularity+Riemannian+metric+distributional) inspected; 0 results reported. | [Query](https://link.springer.com/search?query=weak%20curvature%20low%20regularity%20Riemannian%20metric%20distributional); HTTP 406, no results inspectable. | [Query](https://epubs.siam.org/action/doSearch?AllField=weak%20curvature%20low%20regularity%20Riemannian%20metric%20distributional); HTTP 403, no results inspectable. |

The local catalog query `uv run python tools/reference_lookup.py "low
regularity continuous affine connection Fisher metric cubic tensor"` returned
no matches. These searches do not close the literature review; in particular,
no source was identified that settles the weak-curvature or minimal
function-space question.

### Current status and next step

- Evidence status: the low-regularity sufficiency statement and the
  constant-metric counterexample are `proved/agent`, not owner-checked.
- The distinction between a continuous-coefficient connection and the usual
  smooth statistical-manifold connection is explicit.
- Still open at this checkpoint: clarify curvature-holonomy implications
  outside the flat simply connected case, and determine whether statistical
  duality curvature identities remain useful at this regularity.
- No canonical ledger or manuscript was modified; the work remains a
  scratch-level continuation.

## Continuation: flat curvature does not determine holonomy

Date: 2026-10-04 12:38:32 (OS local time)

### An explicit dualistic-geometry example on the circle

Let the parameter manifold be the circle `S^1=R/(2*pi*Z)`, with its global
closed one-form `dtheta`. Equip it with the metric

`g = dtheta tensor dtheta`

and symmetric cubic tensor

`T = c*dtheta tensor dtheta tensor dtheta`,

where `c` is a nonzero real constant. These are globally well-defined smooth
tensors: under changing a lifted angular coordinate by `2*pi`, `dtheta` is
unchanged. The Levi-Civita connection has zero coefficient in every local
angular coordinate. With the thread's convention,

`Gamma^(alpha) = Gamma^(0) - alpha*T^sharp/2`,

the local connection coefficient is the constant
`Gamma^theta_(theta theta) = -alpha*c/2`. Its curvature is zero because a
one-dimensional manifold has no nonzero 2-forms.

Nevertheless, parallel transport of a tangent vector `v` along the once
positively oriented circle solves

`dv/dtheta - (alpha*c/2)*v = 0`,

so after one circuit,

`v(2*pi) = exp(pi*alpha*c)*v(0)`.

For `alpha*c != 0` this holonomy is nontrivial even though the curvature
vanishes identically. This is an explicit smooth dualistic statistical
structure `(g,T)`; it is not claimed here to have been realized as the
Fisher metric and score cubic of a particular probability family.

The example establishes that curvature alone cannot determine holonomy on a
non-simply-connected parameter space: global topology and the connection's
periods matter, even before low regularity is considered. It also rules out
any proposed statement “zero distributional curvature implies trivial
holonomy” without a simple-connectivity or global-trivialization hypothesis.
It does not decide holonomy from nonzero distributional curvature; that
broader question remains separate from the flat simply-connected theorem
proved below.

### Query-driven literature update

On 2026-10-04 the following searches were sent directly to the three required
providers. They were focused discovery queries, not full-coverage searches.

| Query family | arXiv | SpringerLink | SIAM |
|---|---|---|---|
| `continuous flat connection distributional curvature holonomy` | Search returned a 2025 graphene/disclination result mentioning curvature and holonomy; its abstract concerns a physical model, not a low-regularity flat-connection theorem, so it was not used as evidence. | HTTP 406; result page unavailable. | HTTP 403; result page unavailable. |
| `low regularity flat connection parallel transport holonomy` | Search page inspected; 0 results reported. | HTTP 406; result page unavailable. | HTTP 403; result page unavailable. |
| `distributional curvature connection holonomy counterexample` | Search page inspected; 0 results reported. | HTTP 406; result page unavailable. | HTTP 403; result page unavailable. |

The prior independent search pass on low-regularity curvature (immediately
above) and the existing local-reference lookup found no directly applicable
source. SpringerLink/SIAM access failures persist. Therefore the literature
review is still `incomplete`, and no novelty or literature-proved claim is
made.

### Remaining precise question

On a simply connected smooth domain, let `A` be a continuous matrix-valued
connection one-form and define `F=dA+A wedge A` distributionally. Does
`F=0` imply that every loop's parallel transport is the identity (equivalently
that `A` is locally, and on the domain globally, gauge-equivalent to zero by
a suitably regular gauge)? The circle example shows simple connectivity
cannot be omitted. This question is addressed by the theorem and referee
assessment below; it is not a remaining open question in this record.

### Theorem: distributionally flat continuous connections on a simply
connected domain

Let `Omega` be a simply connected open subset of `R^d`, and let
`A=sum_i A_i dx^i` be a continuous matrix-valued one-form, defining a
connection on the trivial rank-`m` bundle. Define its curvature
distribution by

`F_ij = partial_i A_j - partial_j A_i + [A_i,A_j]`.

If `F_ij=0` as a distribution for all `i,j`, then parallel transport around
every piecewise `C^1` loop in `Omega` is the identity. Equivalently, there is
a global `C^1` frame in which `A=0`.

#### Proof

Fix a piecewise smooth null-homotopy `H:[0,1]^2 -> Omega` of a piecewise
`C^1` loop, with the basepoint fixed. Its image is compact. After choosing a
neighborhood of this compact image still contained in `Omega`, mollify the
matrix coefficients of `A` there to obtain smooth one-forms `A_epsilon`.
Continuity gives uniform convergence `A_epsilon -> A` on the homotopy image.
Distributional flatness says

`partial_i A_j - partial_j A_i = -[A_i,A_j]`.

Convolving this identity and adding the quadratic term for `A_epsilon`
shows

`(F_epsilon)_ij
 = [ (A_i)_epsilon, (A_j)_epsilon ]
   - ([A_i,A_j])_epsilon`.

The commutator is a continuous bilinear function of its entries. Uniform
convergence of the mollifications on compact sets therefore implies
`sup_H |F_epsilon| -> 0`.

For a smooth connection, variation of parallel transport along a smooth
homotopy gives the endpoint variation as the integral of the curvature
`F_epsilon(∂_s H, ∂_t H)`, conjugated by the parallel transports along
subpaths. The homotopy has finite area and the coefficients `A_epsilon`
remain uniformly bounded on its compact image; the subpath transports and
their inverses are uniformly bounded by the linear ODE estimate. Hence the
difference between the holonomies of the two boundary loops is bounded by
a constant (depending on this fixed homotopy and a uniform coefficient
bound) times `sup_H |F_epsilon|`. One boundary is constant, with identity
holonomy, so the loop holonomy for `A_epsilon` tends to the identity.

Finally, solutions of the parallel-transport linear ODE depend continuously
on the coefficient matrix in the uniform norm along a fixed piecewise `C^1`
loop. Since `A_epsilon -> A` uniformly there, its holonomy converges to the
holonomy of `A`. That holonomy must therefore be the identity.

For any two paths with the same endpoints, their concatenation is a loop;
the identity-loop result makes endpoint transport path-independent. Fixing
a basis at one point and transporting it to every other point gives a global
parallel frame. Locally, extending a path by a short coordinate segment and
using continuity of `A` shows this frame is `C^1` and solves
`partial_i P = -A_i P`. In that frame the connection form vanishes. This
proves the theorem.

No simple-connectivity assumption can be dropped: the preceding circle
example is flat with nontrivial holonomy. More generally, on a connected
domain, a flat continuous connection has holonomy depending only on the
homotopy class of a loop, giving a representation of the fundamental group
into `GL(m)`; the proof above gives triviality precisely when all loops are
null-homotopic.

This theorem is an agent proof, not owner-checked, and concerns a connection
on a trivial bundle over a Euclidean domain. Its conclusion concerns
holonomy/gauge triviality, not whether the distributional curvature is a
classical tensor or whether any statistical ancillary exists.

### Focused literature search for the theorem

Search date: 2026-10-04. The three provider queries were:

| Provider | Query | Outcome |
|---|---|---|
| arXiv | [`distributionally flat continuous connection simply connected gauge trivial`](https://arxiv.org/search/?searchtype=all&abstracts=show&order=-announced_date_first&query=distributionally+flat+continuous+connection+simply+connected+gauge+trivial) | Search page inspected; 0 results reported. |
| arXiv | [`weak flat connection continuous coefficients trivial holonomy`](https://arxiv.org/search/?searchtype=all&abstracts=show&order=-announced_date_first&query=weak+flat+connection+continuous+coefficients+trivial+holonomy) | Search page inspected; 0 results reported. |
| arXiv | [`distributional zero curvature parallel transport simply connected`](https://arxiv.org/search/?searchtype=all&abstracts=show&order=-announced_date_first&query=distributional+zero+curvature+parallel+transport+simply+connected) | Search page inspected; 0 results reported. |
| SpringerLink | [`distributionally flat continuous connection simply connected gauge trivial`](https://link.springer.com/search?query=distributionally%20flat%20continuous%20connection%20simply%20connected%20gauge%20trivial) and [`weak flat connection continuous coefficients trivial holonomy`](https://link.springer.com/search?query=weak%20flat%20connection%20continuous%20coefficients%20trivial%20holonomy), submitted separately. | Both returned HTTP 406; no results inspectable. |
| SIAM | [`distributionally flat continuous connection simply connected gauge trivial`](https://epubs.siam.org/action/doSearch?AllField=distributionally%20flat%20continuous%20connection%20simply%20connected%20gauge%20trivial) and [`weak flat connection continuous coefficients trivial holonomy`](https://epubs.siam.org/action/doSearch?AllField=weak%20flat%20connection%20continuous%20coefficients%20trivial%20holonomy), submitted separately. | Both returned HTTP 403; no results inspectable. |

The pages inspected and provider limitations are recorded immediately above
as query records; the searches are not a comprehensive survey and do not
establish novelty. No matching primary source was verified, so the proof
status remains `proved/agent` and the literature status remains `incomplete`.

### Updated status

- Resolved: distributionally flat continuous matrix connections on simply
  connected Euclidean domains have trivial holonomy and admit a global
  parallel frame.
- Resolved: without simple connectivity, even a smooth dualistic statistical
  structure can have zero curvature and nontrivial holonomy.
- Superseded by later sections: realization of the circle `(g,T)` example by
  a concrete statistical model, and existence of a nontrivial exact
  ancillary in that model.
- Still open and separate: extension to nontrivial bundles and
  weaker-than-continuous coefficients.
- No canonical ledger or manuscript was modified.

## Continuation: realize nontrivial alpha-holonomy by a statistical model

Date: 2026-10-04 14:35:56 (OS local time)

### Question and scope

The preceding circle construction specified a metric and cubic tensor
abstractly. This check asks whether a smooth, identifiable probability model
on a circular parameter space can have constant positive Fisher information,
constant nonzero score cubic, and consequently nontrivial alpha-holonomy.
No ancillary claim or ambient immersion is in scope.

### Model

Let both sample space and parameter space be the circle
`S^1=R/(2*pi*Z)`. Use normalized arc measure `dx/(2*pi)` as a fixed
dominating probability measure and define

`h(u)=cos(u)+sin(2u)`,
`p_theta(x)=1+epsilon*h(x-theta)`,
`epsilon=1/1000`.

Here `p_theta` is the density with respect to `dx/(2*pi)`. Since
`|h|<=2`, `p_theta>=1-2*epsilon=0.998>0`; and the integral of `h` over a
period is zero, so every `p_theta` is normalized. This gives a smooth,
strictly positive, common-support dominated family. It is identifiable:
the first Fourier harmonic of `p_theta` has phase `theta`, so equality of
two densities forces their parameters to agree modulo `2*pi`.

Write `u=x-theta`. Its score is

`s_theta(x) = partial_theta log p_theta(x)
            = -epsilon*h'(u)/(1+epsilon*h(u))`.

It is bounded uniformly in `x` and `theta`, so every finite score moment
exists. Translation invariance of the integral gives parameter-independent
Fisher information and cubic score:

`g = epsilon^2/(2*pi) * integral_0^(2*pi)
     h'(u)^2/(1+epsilon*h(u)) du`,

`T = -epsilon^3/(2*pi) * integral_0^(2*pi)
     h'(u)^3/(1+epsilon*h(u))^2 du`.

The first quantity is strictly positive because `h'` is not identically
zero and the denominator is positive.

### Exact sign check that `T` is nonzero

For `h'=-sin(u)+2*cos(2u)`, direct trigonometric integration gives

`integral_0^(2*pi) h'(u)^3 du = -3*pi`.

Set `r=2*epsilon=1/500`. For `|y|<=r`,

`|(1+y)^(-2)-1| <= B := (2*r+r^2)/(1-r)^2`.

Also `|h'|<=3`, so

`| integral h'^3/(1+epsilon*h)^2 - integral h'^3 |
 <= 54*pi*B`.

For `r=1/500`, `54*B < 1.5 < 3`. Therefore the perturbed integral remains
strictly negative, and the displayed formula implies `T>0`. This is an exact
analytic bound; it does not rely on floating-point quadrature.

An optional check of the leading scale is
`g/epsilon^2 -> 5/2` and `T/epsilon^3 -> 3/2` as `epsilon -> 0`.
The exact bound above fixes a concrete nonzero epsilon for the actual model.

### Non-exponentiality

This model is also not a finite-dimensional exponential family. Put
`q(u)=log(1+epsilon*h(u))`. If `q` were a trigonometric polynomial, its
complexification would be a Laurent polynomial `Q(z)` and
`exp(Q(z))` would equal the nonconstant Laurent polynomial obtained by
complexifying `1+epsilon*h`. The exponential of a nonconstant Laurent
polynomial has an essential singularity at zero or infinity and cannot be a
Laurent polynomial. Hence `q` has infinitely many nonzero Fourier modes.
The translates `q(x-theta)` therefore have infinite-dimensional linear
span (their nonzero Fourier modes acquire the distinct characters
`exp(-i*n*theta)`). In a finite-dimensional exponential family, all
log-density differences lie in the finite-dimensional span of its
sufficient statistics. This contradiction proves the family is
non-exponential in the finite-dimensional sufficient-statistic sense.

### Alpha connection and holonomy

The parameter is a circle and `g` is a positive constant, so its
Levi-Civita coefficient is zero in every lifted angular coordinate. The
thread's convention yields

`Gamma^(alpha)^theta_(theta theta) = -alpha*T/(2*g)`.

Parallel transport of a tangent vector component `v` around the positive
generator, from angle zero to `2*pi`, solves

`dv/dtheta + Gamma^(alpha)^theta_(theta theta)*v = 0`.

Its holonomy is multiplication by

`H_alpha = exp(pi*alpha*T/g)`.

Since `T>0` and `g>0`, `H_alpha != 1` for every real `alpha != 0`. Thus the
abstract smooth dualistic circle example is realized by a concrete smooth,
identifiable, non-exponential statistical model. Curvature is zero by
one-dimensionality, while alpha-holonomy is nontrivial. The result is
statistical-model geometry only; it does not imply or obstruct an exact
ancillary.

### Literature searches

The local catalog was queried first on 2026-10-04 with
`uv run python tools/reference_lookup.py "statistical circle location model
Fisher cubic score holonomy"`; it returned no matches.

Independent question-driven and candidate-specific searches were submitted
directly to arXiv, SpringerLink, and SIAM on 2026-10-04. The three query
families were:

1. Exact model geometry: `circular location family Fisher information third
   score moment asymmetric density`.
2. Nearby terminology: `Fisher Rao geometry circle location family Amari
   Chentsov tensor`, and `periodic statistical model nonzero third score
   moment Fisher metric`.
3. Obstruction/contrast: `location model skewed density third score moment
   zero curvature holonomy`.

The arXiv pages for all submitted queries reported zero results. SpringerLink
returned HTTP 406 and SIAM returned HTTP 403 for each query, so those provider
results could not be inspected. These finite query outcomes are not evidence
of absence, and no novelty claim is made. No relevant primary source was
verified; literature status remains `incomplete`.

### Status and remaining scope

- Statistical realization: `proved/agent` analytically for the explicit
  model above; exact positivity and nonzero cubic are bounded without
  numerical approximation.
- Literature status: `incomplete`.
- Resolved: nontrivial alpha-holonomy with zero curvature occurs in an
  identifiable, smooth, non-exponential statistical model on `S^1`.
- This result supersedes the earlier “Still open” item above concerning
  realization of the circle `(g,T)` structure by a probability model.
- Superseded below: whether this model has an exact ancillary related to the
  holonomy; the following continuation constructs one and distinguishes
  coexistence from an implication or equivalence.
- No canonical ledger or manuscript was modified.

## Continuation: exact ancillary in the circular statistical model

Date: 2026-10-04 14:43:41 (OS local time)

### Exact ancillary construction

For the model above, let

`A(X) = 3X mod 2*pi`,

viewed as a point of the circle. This is a parameter-free, nonconstant
statistic. For `a` on the circle its three inverse images are
`x_j=(a+2*pi*j)/3`, `j=0,1,2`, with equal Jacobian. Relative to normalized
arc measure, its pushforward density is

`f_(A|theta)(a) = (1/3) * sum_(j=0)^2 p_theta(x_j)`

`= 1 + (epsilon/3) * sum_(j=0)^2
        [cos(x_j-theta) + sin(2*(x_j-theta))]`

`= 1`.

The last equality follows because the three cosine phases are spaced by
`2*pi/3`, and the three sine phases of twice the angle are also spaced by
`2*pi/3`; each three-term sum is zero. Therefore `A(X)` is exactly uniform
on the circle for every value of `theta`. It is an exact ancillary in the
usual sense: its statistic does not involve the unknown parameter and its
sampling distribution is parameter-independent.

### Why this ancillary is not the full translation invariant

The location group acts transitively on the sample circle, so a statistic
whose value is invariant under every translation must be constant. `A` is
not such an invariant:

`A(X+delta) = A(X) + 3*delta mod 2*pi`.

It is equivariant under translations, while its law remains uniform and
therefore unchanged. Its ancillarity comes from aliasing: the density has
Fourier modes only at frequencies 1 and 2, and the three-to-one map removes
those modes. It is not the maximal invariant of the full location group.

More generally, for any measurable statistic `S(X)` with values in a
standard Borel space, exact ancillarity in this model is equivalent to the
following Fourier condition: for every measurable output set `B`, the
indicator `1_{S(x) in B}` has zero Fourier coefficients at frequencies
`+1,-1,+2,-2`. Indeed,

`P_theta(S in B) = integral 1_{S(x) in B} p_theta(x) dm(x)`

is constant in `theta` exactly when the sinusoidal terms of frequencies 1
and 2 in this integral vanish. Thus this model admits many possible
ancillary sigma-fields; the criterion is a characterization, not a claim
that `sigma(A)` contains all ancillaries.

### The ancillary is not sufficient

Conditional on `A=a`, the original sample lies at one of the three points
`x_j=(a+2*pi*j)/3`. Its conditional probabilities are

`P_theta(X=x_j | A=a)
   = [1 + epsilon*h(x_j-theta)]/3`.

The denominator is 3 because the three values of `h` sum to zero. These
conditional probabilities depend on `theta`; for example, the `j=0`
probability contains a nonconstant translate of `h`. Hence the conditional
law of the data given `A` is parameter-dependent and `A` is not sufficient.
The ancillary retains no marginal information about `theta`, while the
conditional three-branch experiment still carries parameter information.

### Relation to alpha-holonomy

The same probability model has `g>0`, `T>0`, and, for every
`alpha != 0`, nontrivial holonomy

`H_alpha = exp(pi*alpha*T/g) != 1`.

Consequently this single identifiable non-exponential model has both:

1. a nonconstant exact ancillary `A(X)=3X mod 2*pi`; and
2. nontrivial alpha-holonomy on the parameter circle.

This proves compatibility, not a causal or equivalence relation. The
ancillary is produced by the frequency support of the sampling density;
the holonomy is produced by the score cubic relative to Fisher information
and the topology of the parameter circle. In particular, vary epsilon over
a sufficiently small positive interval. The same statistic `A` remains
exactly uniform for every such epsilon, whereas

`g_epsilon/epsilon^2 -> 5/2`,
`T_epsilon/epsilon^3 -> 3/2`,
`T_epsilon/g_epsilon ~ (3/5)*epsilon`

as `epsilon -> 0`. Thus its ancillary law remains fixed while the
alpha-holonomy varies and tends to the identity. The ancillary distribution
alone cannot determine the holonomy. No implication from nontrivial
holonomy to absence of an exact ancillary is possible in general, since
this model supplies a counterexample to that implication.

This does not rule out a relationship under extra restrictions, such as
requiring the ancillary to be invariant under a specified group action or
requiring it to arise from a particular structural decomposition. Those
would be different, explicitly constrained questions.

### Literature search record

The local catalog was queried before external discovery with
`uv run python tools/reference_lookup.py "exact ancillary circular location
family Fourier invariant statistic"`; it returned no matches.

Independent question-driven search families sent directly on 2026-10-04:

| Family | arXiv result | SpringerLink | SIAM |
|---|---|---|---|
| Exact: `exact ancillary circular location family Fourier statistic` | Search page inspected; 0 results reported. | HTTP 406; unavailable. | HTTP 403; unavailable. |
| Group terminology: `group action maximal invariant ancillary statistic location family` | Search page inspected; 0 results reported. | HTTP 406; unavailable. | HTTP 403; unavailable. |
| Fourier/obstruction: `ancillary statistic Fourier coefficients translation invariant distribution counterexample` | Search page inspected; 0 results reported. | HTTP 406; unavailable. | HTTP 403; unavailable. |

Supplementary local-reference route: `tem.md`, References, cites Fraser and
Reid (1995), “Ancillaries and third order significance,” and Fraser and Reid
(2001), “Ancillary information for statistical inference.” The exact 1995
title/author query was also sent to arXiv (0 results), SpringerLink (HTTP
406), and SIAM (HTTP 403). The 2026-09-30 generation-level supplementary
search record in the [candidate batch manifest](../20260930-231402/batch-manifest.md)
also records the title/author search for the 2001 Fraser–Reid source at all
three providers, with arXiv reporting 0 results and SpringerLink/SIAM
unavailable. No exact result from either source was inspected as evidence
for this Fourier ancillary calculation, and no citation-closure pass was
completed.

The provider searches are incomplete and do not establish novelty. The
calculation above is an explicit derivation for this model, not a
literature-priority claim.

### Updated status

- Evidence status: existence and exact distribution of `A` are
  `proved/agent`; its insufficiency and coexistence with nontrivial
  alpha-holonomy are `proved/agent`.
- The previous open question about whether this model has a nontrivial exact
  ancillary is resolved affirmatively.
- Still open: characterize maximal ancillary sigma-fields for this model;
  determine whether any ancillary criterion with additional group or
  structural restrictions relates to alpha-holonomy; and complete the
  literature review when provider access permits.
- No canonical ledger or manuscript was modified.

## Referee check: simply connected distributionally flat connection

Date: 2026-10-04 14:49:54 (OS local time)

### Referee verdict

The theorem proved above is correct under its stated hypotheses:
`Omega` is an open simply connected subset of Euclidean space, the bundle is
trivial, and the connection coefficients are continuous. The mollification
argument is a valid way to reduce distributional flatness to the classical
smooth homotopy formula. The original proof is mathematically sound in
outline, but it omits several technical bridges that should be stated for a
referee:

1. A piecewise `C^1` loop has a null-homotopy that can be chosen piecewise
   smooth relative to its boundary and basepoint. This is the relative smooth
   approximation theorem for maps into the open manifold `Omega`; corners
   may be handled by a finite triangulation.
2. Mollification is local. If `K` is the compact image of that homotopy,
   choose an open neighborhood of `K` whose closure is contained in
   `Omega`, and convolve the coordinate coefficient functions only there.
   Distributional flatness holds on this neighborhood.
3. The homotopy-variation estimate should be displayed, rather than just
   asserted, to make clear that small curvature controls the difference of
   boundary holonomies.
4. Path independence yields the global frame; its `C^1` regularity follows
   from the local parallel-transport ODE and continuity of `A`, not merely
   from the pointwise definition by path transport.

These are proof-completion requirements, not a counterexample or a change
to the theorem.

### Tightened local argument

Use the parallel-transport convention `U'=-A_i(gamma)*gamma'^i*U`, so the
curvature matrix is

`F_ij = partial_i A_j - partial_j A_i + [A_i,A_j]`.

Let `H:[0,1]^2 -> Omega` be a piecewise smooth based null-homotopy of a
piecewise `C^1` loop. Write `K=H([0,1]^2)`. Since `K` is compact and
contained in the open set `Omega`, it has a relatively compact open
neighborhood `V` in `Omega`. For sufficiently small `delta`, mollify each
coefficient on `V` to get `A_delta`; uniform continuity gives
`A_delta -> A` uniformly on `K`.

On a slightly smaller neighborhood of `K`, the distribution identity
`dA=-A wedge A` holds. Therefore

`F_delta = dA_delta + A_delta wedge A_delta
         = A_delta wedge A_delta - (A wedge A)_delta`.

The bilinear product is continuous and mollification converges uniformly on
compact sets, so `||F_delta||_(C^0(K)) -> 0`. The coefficients `A_delta`
are uniformly bounded on `K`.

For each smooth `A_delta`, pull the connection back along `H` and vary its
parallel transport across the homotopy. The standard variation-of-constants
formula expresses the difference of the boundary holonomies as an integral
of conjugates of
`F_delta(dH(partial_s),dH(partial_t))`. If `M` bounds `|A_delta|` and the
lengths of the paths in the chosen finite piecewise-smooth homotopy are
bounded by `L`, the ODE estimate bounds each transport and inverse by
`exp(M L)`. Consequently, for a constant `C_H` independent of small
`delta`,

`||Hol_delta(boundary_1)-Hol_delta(boundary_0)||
   <= C_H * ||F_delta||_(C^0(K))`.

One boundary is the constant loop, whose holonomy is the identity; hence
the other boundary holonomy for `A_delta` converges to the identity.
On the fixed original loop, the coefficient matrices in the transport ODE
converge uniformly. Continuous dependence of linear ODE solutions on
coefficients implies that the holonomies converge to the holonomy for `A`.
Thus the latter is exactly the identity.

Every loop is null-homotopic, so every loop has identity holonomy. Transport
between two endpoints is therefore independent of the chosen path. Transport
a fixed basis from a basepoint to each point to define a global frame `P`.
In a small coordinate ball, path independence and the transport ODE imply
`partial_i P=-A_i P`. The right side is continuous; hence `P` is `C^1`,
invertible, and its frame change makes the connection form zero. This also
shows the result is about a continuous-coefficient connection; it does not
assert classical differentiability of curvature.

### Scope distinctions

- For a smooth connection, “curvature zero implies local parallel frames”
  is the standard local flat-connection theorem. Global triviality on a
  connected base is controlled by the holonomy representation of its
  fundamental group; simple connectivity forces this representation to be
  trivial.
- The theorem here uses the same conclusion but weakens coefficient
  regularity to continuity and curvature to the distributional equation.
  The mollification proof is the specific bridge supplied in this record.
- This is a connection-theoretic result. It does not prove an information
  geometric curvature identity, an exact ancillary theorem, or a relationship
  between ancillary statistics and normal-bundle holonomy.

### Literature positioning and search limits

The local reference catalog was queried first:
`uv run python tools/reference_lookup.py "flat connection trivial holonomy
simply connected parallel frame"` returned no matches.

The 2026-10-04 question-driven searches at the required providers were:

| Family | arXiv | SpringerLink | SIAM |
|---|---|---|---|
| Exact classical statement: `flat connection simply connected trivial holonomy parallel frame` | Search page inspected; 0 results reported. | HTTP 406; inaccessible. | HTTP 403; inaccessible. |
| Low-regularity variant: `distributional flatness continuous connection gauge trivialization` | Search page inspected; 0 results reported. | HTTP 406; inaccessible. | HTTP 403; inaccessible. |
| Monodromy/obstruction: `flat connection holonomy fundamental group representation simply connected counterexample` | Search page inspected; 0 results reported. | HTTP 406; inaccessible. | HTTP 403; inaccessible. |
| Local systems terminology: `flat connections representations of the fundamental group monodromy local systems` | Search returned a result by Silke Lekaus, *Unipotent flat bundles and Higgs bundles over compact Kaehler manifolds* (arXiv:math/0304137). Its abstract discusses monodromy representations and local systems, but not the continuous-coefficient distributional theorem here; it is contextual, not proof evidence. | HTTP 406; inaccessible. | HTTP 403; inaccessible. |

Crossref metadata identifies Auslander and Markus, “Holonomy of Flat
Affinely Connected Manifolds,” *Annals of Mathematics* 62 (1955), DOI
[10.2307/2007104](https://doi.org/10.2307/2007104). This is a relevant
historical source for the global holonomy side of flat affine geometry.
Crossref verifies bibliographic identity only; the JSTOR full record was
not inspectable here, so this source is not cited as verification of the
specific simply-connected theorem or its low-regularity extension. The exact
title/author query was additionally submitted to arXiv (0 results),
SpringerLink (HTTP 406), and SIAM (HTTP 403); the JSTOR page was not fully
inspectable.

Accordingly, the literature classification is `incomplete`. The defensible
position is: the smooth conclusion belongs to standard flat-connection and
monodromy theory; this record supplies an elementary mollification argument
for continuous coefficients and distributional flatness. No priority or
novelty claim is made for that extension.

### Corrected record status

- Mathematical status: `proved/agent`, with the technical steps above made
  explicit; not `proved/literature` and not owner-checked.
- Literature status: `incomplete`.
- The former “Remaining precise question” is resolved in the theorem above;
  the open questions are the separate weaker-than-continuous and
  nontrivial-bundle extensions, and statistical/ancillary interpretations.
- No canonical ledger or manuscript was modified.

## Dual curvature identity with continuous connection coefficients

Date: 2026-10-04
Agent: Copilot

### Statement and conventions

Let a smooth coordinate chart carry a positive-definite metric matrix
`G ∈ C¹` and two connection matrices `A_i, A_i* ∈ C⁰`, with the convention
`∇_i v = ∂_i v + A_i v`. Assume the weak duality equation

`∂_i G = A_iᵀ G + G A_i*`

holds (both sides here are continuous). Define their curvatures as
distributions by

`F_ij = ∂_i A_j − ∂_j A_i + [A_i,A_j]`,

and the same formula for `F*_ij`. The bracket terms are continuous; only the
derivative terms are distributional.

Then the dual curvature identity is meaningful and holds as a distribution:

`F_ijᵀ G + G F*_ij = 0`.

This is the weak counterpart of
`g(R(X,Y)Z,W) + g(Z,R*(X,Y)W) = 0`; it does not assert that either curvature
has pointwise values. In this formula, multiplication of the curvature
distribution by `G` is not being taken as an unrestricted product of arbitrary
distributions. Each derivative-of-continuous-coefficient term is multiplied
using the canonical extension
`⟨G ∂_k A, φ⟩ = −∫ A ∂_k(Gᵀ φ)` componentwise, for smooth compactly
supported test matrices `φ`. This is well-defined because `G` is `C¹` and
`A` is continuous. The continuous commutator terms use ordinary multiplication.

### Proof

Apply the two covariant derivatives induced by `A` and `A*` to the
metric-compatibility equation. Equivalently, regard
`D_i H = ∂_i H − A_iᵀH − H A_i*` as the induced connection on bilinear forms.
The hypothesis is `D_iG=0`. The commutator, expanded distributionally, is

`(D_iD_j − D_jD_i)G = −F_ijᵀG − G F*_ij`.

Mixed distributional derivatives of `G` commute. The remaining products in
this expansion are defined: the derivative terms are first derivatives of
continuous matrices and are multiplied by `C¹` matrices as specified above;
all other factors are continuous. Therefore the left side vanishes and gives
the stated identity. This calculation only differentiates the `C¹` metric
once in each order and does not require a classical second derivative.

For a smooth change of frame, curvature distributions transform by the usual
conjugation law, and `G` transforms by the usual congruence law. Thus the
identity is frame-independent in the ordinary smooth tangent-bundle atlas.
This argument does not establish an invariant calculus for arbitrary
low-regularity frame changes.

### Application to the statistical `α`-pair

Take `g ∈ C¹` positive definite and a continuous symmetric cubic tensor `T`.
Let `K^k_{ij}=g^{kℓ}T_{ijℓ}`; then `K` is continuous. With the thread's
convention

`Γ^(α) = Γ^(0) − (α/2)K`,

the Levi-Civita connection `Γ^(0)` is `C⁰`, and direct substitution in the
metric-compatibility equation shows that `∇^(α)` and `∇^(−α)` are weakly dual.
Consequently, their distributional curvatures obey

`(F^(α)_ij)ᵀ G + G F^(−α)_ij = 0`.

In particular, distributional flatness of either member implies
distributional flatness of its dual. This is a useful conclusion even when
the coefficients are only continuous. It is not a pointwise curvature claim,
nor does it by itself assert pointwise sectional curvature, classical
Bianchi-derivative identities, or extra regularity of parallel transport.

### Literature search and positioning

The local reference catalog had no entry matching the earlier
`"flat connection simply connected parallel frame"` lookup; no local
Amari–Nagaoka bibliography item was available to pursue. On 2026-10-04,
question-driven searches were run independently at arXiv, SpringerLink, and
SIAM using three query families:

| Query family | arXiv | SpringerLink | SIAM |
|---|---|---|---|
| Classical dual connections / metric compatibility / curvature identity | Search page inspected; 0 results. | HTTP 406. | HTTP 403. |
| Distributional curvature / continuous coefficients / dual connections | Search page inspected; 0 results. | HTTP 406. | HTTP 403. |
| Weak regularity / statistical manifolds / curvature identity and failure conditions | Search page inspected; 0 results. | HTTP 406. | HTTP 403. |

A supplementary arXiv search for Amari–Nagaoka's *Methods of Information
Geometry* returned 0 results; SpringerLink and SIAM were unavailable as above.
The [AMS book page](https://bookstore.ams.org/mmono-191/) describes the
standard role of dual `α` and `−α` connections, but it does not establish
this low-regularity distributional extension. The arXiv article [*An
elementary introduction to information geometry* (arXiv:1808.08271)](
https://arxiv.org/abs/1808.08271) provides contextual discussion of smooth
dually flat manifolds, not this weak curvature identity. These sources are
context only, not proof evidence for the stated extension.

Accordingly, the mathematical status is `proved/agent` for the explicitly
stated chart-level identity and its `C¹`-metric/`C⁰`-connection setting; it is
not `proved/literature` or owner-checked. The literature review is
`incomplete`: SpringerLink and SIAM were inaccessible, and the arXiv queries
did not locate a directly matching low-regularity treatment. The calculation
answers the current question affirmatively in a well-defined weak sense while
separating it from classical pointwise curvature. It makes no novelty claim.
