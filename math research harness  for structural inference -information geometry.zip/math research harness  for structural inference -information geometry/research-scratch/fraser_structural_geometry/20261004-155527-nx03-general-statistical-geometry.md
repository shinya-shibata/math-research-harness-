# NX-03: general statistical-manifold geometry

Date: 2026-10-04
Agent: GitHub Copilot
Status: bounded research card; literature review incomplete

## Question and scope

Audit whether existing work resolves NX-03, then derive the general
statistical-submanifold formulas needed to extend the exponential-family
calculation. This card does not update the ledger, manuscript, or durable
claims. It does not identify normal holonomy with statistical ancillary
choices.

## Result

Existing work resolves part, but not all, of NX-03. The thread ledger already
requires an ambient model and immersion. The revised ancillary/holonomy paper
works in a full exponential-family ambient model, corrects the dual
shape-operator convention, and reports a non-symmetric-basepoint numerical
check. It does not derive its score-moment connection or submanifold formulas
for a general dominated model; its section 2 explicitly assumes an exponential
family. The 2026-10-01 discovery report therefore correctly leaves this
extension open.

Under the regularity and immersion assumptions below, the geometric extension
is conditional but precise:

1. Fisher information and score-moment alpha-connections are defined without
   an exponential-family representation.
2. For an immersed submodel, dual Gauss, Codazzi, and Ricci equations hold
   with the ambient alpha-curvature retained.
3. With the convention `Gamma^(alpha) = Gamma^(0) - alpha*T^sharp/2`, the
   normal second fundamental form and the dual shape operator are
   `h^(alpha) = h^(0) - alpha*kappa/2` and
   `g(A^(alpha)_xi X, Y) = g(xi, h^(-alpha)(X,Y))`, respectively.
4. These constructions are geometric objects of the chosen statistical
   ambient manifold and immersion. They do not by themselves encode
   ancillary statistics or prove a relation to ancillary selection.

## Definitions and assumptions

Let `p_theta` be a positive density with respect to a fixed dominating measure
on an open parameter set. Assume differentiability sufficient to define the
first and second log-density derivatives, differentiation under the integral,
finite score moments through order three, and a nonsingular Fisher matrix.
Write `ell = log p_theta`, `s_i = partial_i ell`, and
`g_ij = E[s_i s_j]`. Define the symmetric cubic score tensor
`T_ijk = E[s_i s_j s_k]`. For an immersed parameter submanifold
`f:B -> M`, use the orthogonal normal bundle determined by `g`.

The regularity assumptions must be strengthened as needed to differentiate
the connection and curvature (for example, one additional parameter
derivative with the corresponding integrability). No assertion is made at
support-changing or Fisher-singular points.

## Derivation

### Score-moment connection

With the convention above, the lower-index coefficients of the alpha
connection are

`Gamma^(alpha)_{ij,k} =
 E[(partial_i partial_j ell + (1-alpha)/2 * s_i s_j) s_k]`.

This is the general score-moment expression. In a canonical exponential
family, `E[(partial_i partial_j ell) s_k] = 0` and it reduces to
`(1-alpha) T_ijk/2`, the special formula used by the existing paper. That
reduction is not available for a general model. The alpha and minus-alpha
connections are dual with respect to `g`; neither is asserted to be flat.

Let `K = T^sharp`, meaning `g(K(X,Y),Z) = T(X,Y,Z)`. Then

`nabla^(alpha) = nabla^(0) - alpha*K/2`,

and direct expansion gives

`R^(alpha)(X,Y)Z =
 R^(0)(X,Y)Z
 - alpha/2 * ((nabla^(0)_X K)(Y,Z) - (nabla^(0)_Y K)(X,Z))
 + alpha^2/4 * (K_X K_Y - K_Y K_X)Z`.

Thus the Levi-Civita curvature and the covariant derivative of the cubic
tensor need not vanish. The special exponential-family flat identities
require separate hypotheses; they are not consequences of regularity alone.

### Immersed-submanifold equations and dual shape operators

For `X,Y` tangent to `S`, set

`h^(alpha)(X,Y) = (bar_nabla^(alpha)_X Y)^perp`,

and define the induced tangent connection by the tangential projection. The
normal connection is

`nabla_perp^(alpha)_X xi = (bar_nabla^(alpha)_X xi)^perp`.

Fix the curvature convention
`R(X,Y) = nabla_X nabla_Y - nabla_Y nabla_X - nabla_[X,Y]`.
Duality gives the shape operator paired with the opposite second fundamental
form:

`g(A^(alpha)_xi X, Y) = g(xi, h^(-alpha)(X,Y))`.

Consequently, for tangent `X,Y,Z,W` and normal `xi`, the equations are

`g(bar_R^(alpha)(X,Y)Z,W) =
 g(R_S^(alpha)(X,Y)Z,W)
 + g(h^(alpha)(X,Z), h^(-alpha)(Y,W))
 - g(h^(alpha)(Y,Z), h^(-alpha)(X,W))`,

`(bar_R^(alpha)(X,Y)Z)^perp =
 (nabla_perp^(alpha)_X h^(alpha))(Y,Z)
 - (nabla_perp^(alpha)_Y h^(alpha))(X,Z)`,

`R_perp^(alpha)(X,Y)xi =
 (bar_R^(alpha)(X,Y)xi)^perp
 + h^(alpha)(X,A^(alpha)_xi Y)
 - h^(alpha)(Y,A^(alpha)_xi X)`.

Here the covariant derivative of `h` uses the induced tangent connection in
both tangent arguments. The last equation uses `A^(alpha)`, the adjoint of
`h^(-alpha)`, not the adjoint of `h^(alpha)`. This is the convention needed
for the Ricci equation; replacing it changes the result away from
self-dual points.

The forms vary affinely with alpha. Specifically,
`kappa(X,Y) = (T^sharp(X,Y))^perp` and
`h^(alpha) = h^(0) - alpha*kappa/2`. Equivalently,
`h^(alpha) = h^(1) + (1-alpha)*kappa/2`; this latter identity is valid for
the alpha-family under this convention, but interpreting `h^(1)` as the
coordinate Hessian of an immersion requires an e-affine ambient chart.

### Exact nonzero-curvature check

For `0<u<pi/2`, `0<v<pi/4`, define a four-category model by

`p_1 = cos^2(u) cos^2(v)`,
`p_2 = cos^2(u) sin^2(v)`,
`p_3 = sin^2(u) cos^2(2v)`,
`p_4 = sin^2(u) sin^2(2v)`.

All probabilities are positive and sum to one. In square-root coordinates,
the Fisher metric is `4 * sum_i d(sqrt(p_i))^2`, hence

`ds_F^2 = 4(du^2 + A(u) dv^2)`, where `A(u)=1+3 sin^2(u)`.

For a metric `4 du^2 + 4 A(u) dv^2`, its Gaussian curvature is
`K = -A''/(8A) + (A')^2/(16A^2)`. At the interior point
`u=pi/4` this is exactly `9/100`, so the Fisher/Levi-Civita curvature is
nonzero. The model is not a full two-parameter exponential family: its
log-odds vector in R^3 would have to lie in an affine plane for such a
representation. Modulo its u-direction `(1,1,0)`, the log-odds curve has
coordinates
`x=2 log(cot(v))` and `y=2 log(cot(2v))`; its slope
`dy/dx=(cot(v)^2+1)/(cot(v)^2-1)` varies with `v`, so it is not a line.
It is, of course, contained in the saturated three-parameter categorical
exponential family; the example is a curved, non-full-exponential model,
not a claim that it lies outside every larger exponential family.

This exact example confirms nonzero ambient Fisher curvature is compatible
with a regular non-full-exponential statistical model. It does not test
nonzero normal curvature (which requires an immersion with at least
two-dimensional tangent and normal spaces).

## Evidence classification and limits

- General score-moment expression and the displayed submanifold identities:
  `proved/agent`, conditional on the stated smoothness, integrability,
  immersion, metric, duality, and curvature conventions.
- The `9/100` curvature value: exact analytic derivation for the specified
  finite categorical model only.
- General non-flatness of every non-exponential alpha-connection: not claimed.
- Relation between normal holonomy and actual exact or approximate ancillary
  choices: `open`; it requires an additional theorem connecting the
  statistical immersion to a parameter-free statistic or an explicitly
  defined local ancillary construction.
- Literature review: `incomplete`; no novelty or literature-proof claim.

## Literature record (2026-10-04)

The local catalog was queried before external discovery for “information
geometry”, “alpha-connection”, “statistical manifold”, “curvature”,
“Amari”, and “statistical submanifold”; no catalog entries were returned.
The local reference route then checked the context cited by the two relevant
files: the revised paper's sections 2 and 4–5 and bibliography (Amari and
Nagaoka, *Methods of Information Geometry*; its erratum's mention of
Marugame (2021)); and `tem.md`'s TEM/Efron references. The local Marugame
mention does not give a complete bibliographic identity and was not treated
as a verified citation.

Independent, question-driven arXiv API searches included:

- `all:"statistical submanifold" AND all:Gauss`: zero results.
- `all:"statistical manifold" AND all:submanifold`: 28 results; the first
  inspected result, Kaur and Shanker, “Submanifolds of Bochner Holomorphic
  Statistical Manifolds” (arXiv:2608.20499v1), is a specialized holomorphic
  statistical-geometry setting, not the score-moment inference question.
- `all:"Gauss equation" AND all:"statistical submanifold"`: zero results.
- `all:"statistical submanifold" AND all:"information geometry"`: two
  results. Ueno, “Doubly Totally-Umbilical Statistical Submanifolds in the
  Probability Simplex” (arXiv:2606.06395v2), discusses statistical
  submanifolds in the simplex but treats a specialized classification. It
  does not establish the present general score-moment/ancillary claim.
- `all:alpha-connection AND all:curvature AND all:non-exponential`: zero
  results. A broad Amari search produced mostly unrelated results.

Candidate/reference follow-up searches were also attempted for the general
statistical-submanifold/Gauss–Ricci claim and for the local references
Amari–Nagaoka and Marugame. SpringerLink searches returned HTTP 406, and
SIAM searches returned HTTP 403/security denial; no access controls were
bypassed. The exact Amari–Nagaoka title was bibliographically identified by
Crossref as *Methods of Information Geometry*, DOI 10.1090/mmono/191, but
this metadata is not a check of its mathematical statements. Searches at
those providers are therefore incomplete; the available arXiv results are
not an exhaustive review.

## Best next discriminating step

Choose a regular continuous two-parameter non-full-exponential ambient model
with tractable score moments, and a two-dimensional immersed submodel of
codimension at least two. Compute `R^(alpha)`, `h^(alpha)`, both dual shape
operators, and `R_perp^(alpha)` independently from their definitions at one
interior point. This would test the normal Ricci equation beyond the
exponential-family examples. Keep any resulting normal-holonomy/ancillary
comparison as a separate statistical theorem.
