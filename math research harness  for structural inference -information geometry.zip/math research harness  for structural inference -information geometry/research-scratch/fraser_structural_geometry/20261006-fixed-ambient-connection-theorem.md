# Fixed ambient + fixed connection: the correct positive theorem boundary

Date: 2026-10-06
Agent: GitHub Copilot in VS Code
Scope: define the strongest statement that remains valid once the ambient manifold, immersion, metric, and connection are fixed.
Status: `open` as a general theorem; `verified-computationally` for the explicit codimension-two model.

## The issue

The OP-3 counterexample shows that the naive implication

`F = 0  =>  R_perp = 0`

is false unless one has already chosen the ambient geometry and the normal connection. The same is true for the informal slogan

`exact ancillary => canonical normal bundle`.

The right way to proceed is therefore not to search for a universal Fraser theorem, but to isolate the conditional theorem that does hold once the ambient data are fixed.

## Definition: fixed ambient normal setup

Fix a smooth ambient statistical manifold `\tilde M` together with:

1. a smooth metric `g` and a chosen `alpha`-connection `\tilde\nabla^alpha`;
2. a smooth immersion `i : M -> \tilde M` of the base manifold `M`;
3. a metric-orthogonal normal bundle `\nu M` of fixed rank `q`;
4. the induced normal projection `\Pi^\nu : T\tilde M|_M -> \nu M`;
5. a smooth structural distribution `F = span{v_1, ..., v_r}` tangent to `M`.

Assume further that the selected normal directions (or approximate ancillary directions) form a smooth rank-`q` subbundle `A \subset \nu M`, and that the induced normal connection is

`\nabla^\perp := \Pi^\nu \circ \tilde\nabla^\alpha`.

This is the minimal fixed-ambient setup in which normal curvature and holonomy are well defined.

## Proposition: the correct local theorem under fixed ambient + fixed connection

Under the above hypotheses, on any sufficiently small contractible neighborhood `U \subset M`, the following statements are valid:

1. the normal connection 1-form `\omega^\perp` is well defined;
2. the curvature form `R^\perp` is well defined by
   `R^\perp = d\omega^\perp + \omega^\perp \wedge \omega^\perp`;
3. for a small contractible loop `\Gamma` bounding a surface `\Omega`, the path-ordered transport satisfies
   `Pexp(\oint_{\Gamma} \omega^\perp) = I + \iint_{\Omega} R^\perp + O(\mathrm{area}(\Omega)^2)`;
4. therefore local curvature controls the first nontrivial term of small-loop transport;
5. if the selected connection is such that `\omega_\tau = 0` on the relevant loop direction and the loop has zero `mu`-displacement, then the period contribution vanishes on that loop.

In other words, once the ambient and connection are fixed, the correct local statement is:

> local curvature is the infinitesimal generator of small-loop transport.

This is the precise theorem that survives the OP-3 counterexample.

## Corollary: what is not valid without these assumptions

Without fixing the ambient manifold, immersion, metric, and normal connection, the following statements are false in general:

- `F = 0 => R^\perp = 0`;
- `exact ancillary => flat normal transport`;
- `approximate ancillary => canonical normal bundle`;
- `structural integrability => nontrivial holonomy`.

The codimension-two logistic-tilt model verifies this directly: the structural distribution is involutive, but the normal curvature is still nonzero in a fixed ambient model.

## The strongest safe generalization

The strongest positive statement presently justified is the following conditional theorem:

> For a fixed ambient Fisher manifold, a fixed immersion, a fixed metric, and a fixed `alpha`-connection, the induced normal connection is well defined and local curvature controls the first nontrivial term of small-loop transport.

This statement remains true even though the explicit model also shows that:

- the same ancillary law can coexist with different ambient normal bundles;
- a zero local period is compatible with nonzero local curvature in the same coordinate neighborhood;
- full holonomy requires additional topological control beyond the local curvature calculation.

## What remains open

The remaining gap is not the local statement itself. The gap is the passage from the fixed local ambient to a global or canonical geometric theorem. To prove a global holonomy theorem, one must further specify:

1. a fixed class of admissible normal bundles;
2. a canonical gauge or projection rule;
3. topological assumptions on the loop space or the fundamental group;
4. conditions ensuring that the period integral is nonzero or vanishes exactly.

Thus the correct program is to separate:

- local curvature / small-loop transport (which is valid under fixed ambient + fixed connection);
- noncontractible period / full holonomy (which is a separate global problem);
- ancillary selection / bundle selection (which is not determined by the ancillary law alone).

## Conclusion

The best theorem boundary is therefore not a universal Fraser theorem but a conditional local theorem:

> once the ambient manifold, immersion, metric, and normal connection are fixed, local curvature determines infinitesimal normal transport, and small-loop holonomy is controlled by the curvature. Global period statements require additional topology and bundle-selection hypotheses.

This is the exact boundary requested by the OP-3 resolution.
