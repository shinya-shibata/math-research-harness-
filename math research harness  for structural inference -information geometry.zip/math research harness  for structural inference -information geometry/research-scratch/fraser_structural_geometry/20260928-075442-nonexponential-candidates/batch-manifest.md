# Hypothesis Candidate Batch

## Run

- Date: 2026-09-28 07:54:42 (OS local time; session identifier: `20260928-075442`)
- Agent/generation system: GitHub Copilot in VS Code; exact underlying model version was not exposed in this session.
- Prompt: `.github/prompts/generate-hypothesis-candidates.prompt.md` (repository version present at run time; no version tag declared).
- Structural validator: `.github/prompts/hypothesis_batch.py` with `.github/prompts/HYPOTHESIS-CANDIDATE.schema.json`.
- Output: `research-scratch/fraser_structural_geometry/20260928-075442-nonexponential-candidates/`.

## Research Question

What bounded, testable extensions of the revised ancillary/holonomy and TEM arguments could connect the general non-exponential structural model, especially Fraser's `X = theta(beta) * U`, to score transport, exact ancillarity, information geometry, and local higher-order inference?

This is a candidate-generation batch, not a theorem audit. The source manuscripts' assertions are treated as prompts and not as verified mathematical evidence.

## Seeds

- S1: `ancillary_holonomy_paper_revised_md.md`, section 1, Fraser structural equation and the manuscript's general-model future-work section in section 7.
- S2: `threads/fraser_structural_geometry/notes/2026-09-27-103815-fraser-consistency-audit.md`, claim inventory B-C and the conditional pushforward score derivation.
- S3: the same audit note, claim inventory E-G and the distinction among exact ancillaries, structural contours, and normal curvature.
- S4: `ancillary_holonomy_paper_revised_md.md`, sections 2-5 and 7, alpha connections, ambient geometry, and normal curvature.
- S5: `tem.md`, sections 3-4 and conclusion, local TEM/r-star construction and listed non-exponential/directional extensions.

## Scope, Exclusions, and Generation Matrix

Requested: 50 candidates in one batch. Produced: 50 candidates. The finite matrix is five seeds crossed with ten transformation families, one candidate for each cell. Each family block cycles through S1-S5 in order.

| Transformation family | Seed allocation | Candidate IDs | Count |
|---|---|---:|---:|
| `assumption_weakening` | S1-S5 | NX01-NX05 | 5 |
| `assumption_strengthening` | S1-S5 | NX06-NX10 | 5 |
| `converse` | S1-S5 | NX11-NX15 | 5 |
| `equivalent_characterization` | S1-S5 | NX16-NX20 | 5 |
| `special_case` | S1-S5 | NX21-NX25 | 5 |
| `boundary_or_limit` | S1-S5 | NX26-NX30 | 5 |
| `dimension_or_class_change` | S1-S5 | NX31-NX35 | 5 |
| `symmetry_or_invariant` | S1-S5 | NX36-NX40 | 5 |
| `new_construction` | S1-S5 | NX41-NX45 | 5 |
| `counterexample_or_obstruction` | S1-S5 | NX46-NX50 | 5 |

Each record includes definitions/assumptions, predicted consequences, a scoped first test with a failure condition, obstacles, and `work_status: generated`, `evidence_status: null`.

Explicit exclusions: no manuscript or canonical ledger edits; no literature/catalog search; no proof, computation, counterexample search, novelty assessment, or promotion to durable claims. This follows the generation-only prompt and the user's explicit instruction not to edit the papers.

## Screening and Duplicate Review

- Produced: 50; malformed/incomplete records excluded: 0.
- Exact duplicate records: 0 identified by the structural validator's statement-plus-definitions key.
- Possible thematic overlaps, retained separately and not asserted equivalent:
  - NX01/NX46: non-invertible or multi-branch structural maps.
  - NX04/NX09/NX19/NX44: non-exponential score geometry and alpha-connection extension.
  - NX08/NX13/NX18/NX23/NX38/NX43: exact ancillarity and invariant-statistic constructions.
  - NX15/NX20/NX25/NX30/NX45/NX50: local TEM/r-star construction, validity conditions, and boundary failure.
  - NX24/NX33/NX48/NX49: relation and non-equivalence between normal geometry and ancillary structure.

These are review clusters, not duplicate eliminations. Candidates remain `generated`; no candidate was marked selected or rejected.

## Review Recommendations

A diverse first review could begin with:

- NX02 for weak transport and boundary flux.
- NX11 for the converse structural-representation question.
- NX18 for the clean distributional definition of exact ancillarity.
- NX26 for the critical-Jacobian boundary regime.
- NX31 for latent dimensions and fiber integration.
- NX36 for equivariance as a model-class organizing principle.
- NX42 for a conditional-score construction with multiple latent branches.
- NX48 for the unresolved coexistence of exact ancillarity and nonzero normal curvature.
- NX50 for the gap between a structural direction and third-order r-star validity.

These are suggestions only and do not change candidate work status.

## Validation and Remaining Ambiguity

The required command was run after `uv` was located on the user installation:

```text
uv run python .github/prompts/hypothesis_batch.py research-scratch/fraser_structural_geometry/20260928-075442-nonexponential-candidates
```

Initial validation confirmed 50 parsed and schema-valid records, 5 per each of 10 transformation families, but reported the manifest missing. The manifest was then created; a final validation is recorded after that repair. Structural validation checks record shape and workspace-relative file references only; it does not validate mathematical truth, novelty, or correctness.

The output is intentionally a broad hypothesis set. Unresolved choices include the precise structural operation `*`, allowed regularity and support conditions, which ambient statistical manifold is intended, the definition and order of the TEM/r-star approximation, and when a structural residual or direction is an actual ancillary. No external or mathematical validation was performed.
