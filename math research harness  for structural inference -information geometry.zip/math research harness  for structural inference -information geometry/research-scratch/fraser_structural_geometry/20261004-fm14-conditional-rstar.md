# FM-14: Conditional Inference and r* Under Two Structural Maps

- Date: 2026-10-04 (JST)
- Agent: GitHub Copilot
- Scope: Compare exact conditioning and the local scalar TEM r* construction for the two structural maps in `20261004-fm14-structural-representations.md`, conditioning on the explicit exact ancillary `Y`.
- Evidence status: `proved/agent` for equality of the conditional experiment and the corresponding symbolic r* inputs under this fixed ancillary; no numerical coverage study was performed.
- Related records:
  - `research-scratch/fraser_structural_geometry/20261004-fm14-structural-representations.md`
  - `tem.md`, Section 4.1, for the local scalar convention `q = [phi(hat beta)-phi(beta)] sqrt(j(hat beta))/phi'(hat beta)` and `r* = r + r^(-1) log(q/r)`.

## Exact conditional experiment

The common joint density is

`p_beta(X,Y) = [(1 + epsilon cos(X-a beta))/(2 pi)] [(1 + delta cos(Y))/(2 pi)]`.

Thus `Y` is an exact ancillary and is independent of `X` for every beta. Conditioning on `Y=y` leaves

`f_beta(x | y) = (1 + epsilon cos(x-a beta))/(2 pi)`,

which is also the marginal density of `X`. Its conditional log likelihood, up to a beta-independent constant, is

`ell_c(beta;x) = log(1 + epsilon cos(x-a beta))`.

It is exactly the same under `F^1` and `F^2`; the joint `Y` factor cancels under conditioning. Consequently every exact conditional likelihood ratio, conditional confidence set, and conditional tail probability based on `(X | Y=y)` is identical under the two representations.

## Valid sample-space direction and scalar r*

Work in a local parameter/data chart with an interior MLE and choose the orientation `a>0`; the interval and observed point are restricted so `z = x-a beta` is in a local neighborhood of zero and there is no circular wrap. Then `hat beta=x/a` and `z=a(hat beta-beta)`.

At fixed ancillary value `Y=y`, the conditional sample space is the one-dimensional level set `Y=y`. The tangent direction obtained from either representation after restricting to this level set is

`V_c = (a,0)`.

For `F^1`, this is its full parameter velocity. For `F^2`, the full velocity is `(a, c/q(x-a beta,y))`, but its second component is normal to the fixed-`Y` conditional sample space and must not be used as a conditional sufficient direction. Projection to the tangent of `Y=y` again gives `(a,0)`.

Using the scalar convention stated in `tem.md`, the conditional sample-space canonical coordinate is

`phi(beta) = V_c dot grad_(x,y) ell_c = -a epsilon sin(z)/(1+epsilon cos(z))`.

At the MLE,

`phi(hat beta)=0`,
`phi'(hat beta)=a^2 epsilon/(1+epsilon)`,
`j(hat beta)=a^2 epsilon/(1+epsilon)`,

where `j` is the observed conditional information. Therefore

`q(beta) = sqrt(epsilon(1+epsilon)) sin(z)/(1+epsilon cos(z))`

for `a>0` in this local chart. The signed likelihood root is

`r(beta) = sign(hat beta-beta) sqrt(2 log((1+epsilon)/(1+epsilon cos(z))))`.

Hence, where the local scalar formula is defined and `q/r>0`,

`r*(beta) = r(beta) + (1/r(beta)) log(q(beta)/r(beta))`.

Every input in these expressions is identical under the two structural representations once conditioning on the same exact ancillary and using its tangent sample space. Thus this valid conditional `r*` approximation does not change between `F^1` and `F^2`. At `beta=hat beta`, use the continuous limiting value `r*=0`.

The formula is local: it does not address other circular branches, boundary MLEs, or global parameter identifiability. It is an approximation to the conditional distribution, not the exact conditional distribution itself. No Monte Carlo accuracy or coverage assessment is claimed here.

## Why a naive full-velocity substitution is invalid

If one differentiates the *joint* log density in the full `F^2` direction without first conditioning, the resulting quantity includes

`(c/q(x-a beta,y)) partial_y log[(1+delta cos(y))/(2 pi)]`
`= - c delta sin(y) / (q(x-a beta,y)(1+delta cos(y)))`.

This term is absent under `F^1` and generally nonzero. Its appearance reflects motion across the ancillary levels, not information in the conditional experiment. It cannot be inserted into the conditional `phi` or used to define a valid ancillary-based `r*`. A representation-dependent number produced that way would be a result of an invalid direction choice, not evidence that legitimate conditional inference changes.

## Conclusion and limits

For this concrete model and the fixed, valid exact ancillary `Y`, exact conditional inference is representation-invariant. The scalar conditional TEM `r*` is also invariant because its conditional likelihood, observed information, and tangent sufficient direction coincide. The second structural map's entire velocity field is not itself a valid conditional direction, since its vertical component moves the ancillary.

This does not prove invariance across all possible ancillary choices in arbitrary models, nor does it settle whether a separately justified higher-order procedure using a different valid approximate ancillary could differ. The construction has no nuisance parameter; extensions to nuisance-parameter problems require their own verified `r*` formula and ancillary choice.
