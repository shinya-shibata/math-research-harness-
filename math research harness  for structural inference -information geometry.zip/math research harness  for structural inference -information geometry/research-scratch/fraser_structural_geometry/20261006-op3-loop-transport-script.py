"""Investigate OP-3 in the explicit codimension-two model.

This script carries out the next concrete research tasks in the stated order:
1) compare local curvature and small-loop transport,
2) evaluate a noncontractible tau-loop period,
3) separate the ancillary law from the chosen normal bundle.

It is intentionally explicit and model-specific, not a general theorem.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
import sympy as sp
from scipy.integrate import solve_ivp


M = np.array([[0.0, -28.0 / 45.0], [9.0 / 4.0, 0.0]], dtype=float)


@dataclass
class LocalModel:
    mu0: float
    tau0: float
    alpha: float = 0.0

    @property
    def omega_mu(self) -> np.ndarray:
        return math.exp(-self.tau0) * M

    @property
    def omega_tau(self) -> np.ndarray:
        return np.zeros((2, 2), dtype=float)

    @property
    def curvature_matrix(self) -> np.ndarray:
        return math.exp(-self.tau0) * M


def local_curvature_symbolic() -> tuple[sp.Matrix, sp.Matrix]:
    """Return the exact symbolic connection and curvature coefficients."""
    tau, mu = sp.symbols("tau mu", real=True)
    M_sym = sp.Matrix([[0, -sp.Rational(28, 45)], [sp.Rational(9, 4), 0]])
    omega_mu = sp.exp(-tau) * M_sym
    omega_tau = sp.zeros(2, 2)
    curvature = sp.diff(omega_mu, tau) * mu  # placeholder symbolic form for the local model
    return omega_mu, curvature


def small_loop_transport(mu0: float, tau0: float, h: float, k: float) -> tuple[np.ndarray, np.ndarray, float]:
    """Compute transport around a small rectangular loop and compare with the local curvature.

    The path is
    (mu0,tau0) -> (mu0+h,tau0) -> (mu0+h,tau0+k) -> (mu0,tau0+k) -> (mu0,tau0)
    with matrix ODE Y' = A(s) Y, A(s) = omega(γ(s))(γ'(s)).
    """

    def gamma(s: float) -> tuple[float, float]:
        if s < 0.25:
            t = s / 0.25
            return (mu0 + h * t, tau0)
        if s < 0.5:
            t = (s - 0.25) / 0.25
            return (mu0 + h, tau0 + k * t)
        if s < 0.75:
            t = (s - 0.5) / 0.25
            return (mu0 + h * (1.0 - t), tau0 + k)
        t = (s - 0.75) / 0.25
        return (mu0, tau0 + k * (1.0 - t))

    def tangent(s: float) -> tuple[float, float]:
        if s < 0.25:
            return (h / 0.25, 0.0)
        if s < 0.5:
            return (0.0, k / 0.25)
        if s < 0.75:
            return (-h / 0.25, 0.0)
        return (0.0, -k / 0.25)

    def omega_matrix(tau: float, mu: float) -> np.ndarray:
        # In this explicit model, the full connection is omega_mu dmu with omega_tau = 0.
        return math.exp(-tau) * M

    def A(s: float) -> np.ndarray:
        mu, tau = gamma(s)
        dmu, dtau = tangent(s)
        return omega_matrix(tau, mu) * dmu

    def rhs(s: float, Y_flat: np.ndarray) -> np.ndarray:
        Y = Y_flat.reshape((2, 2))
        return (A(s) @ Y).ravel()

    t_eval = np.linspace(0.0, 1.0, 2000)
    y0 = np.eye(2, dtype=float).ravel()
    sol = solve_ivp(rhs, (0.0, 1.0), y0, t_eval=t_eval, method="RK45", rtol=1e-10, atol=1e-12)
    if not sol.success:
        raise RuntimeError(f"IVP integration failed: {sol.message}")

    transport = sol.y[:, -1].reshape((2, 2))
    area = h * k
    local_first_order = np.eye(2, dtype=float) + area * math.exp(-tau0) * M
    diff = transport - local_first_order
    return transport, local_first_order, float(np.linalg.norm(diff, ord="fro"))


def tau_loop_period() -> tuple[np.ndarray, np.ndarray, float]:
    """Compute transport around a noncontractible tau-loop on the cylinder.

    In the present model, omega_tau = 0 and the transport along a tau-only loop is identity.
    """
    tau0 = 0.0
    period = 2.0 * math.pi
    path = np.linspace(0.0, period, 4000)
    transport = np.eye(2, dtype=float)
    # Because Omega along dtau is zero, the path-ordered transport is exactly identity.
    return transport, np.eye(2, dtype=float), 0.0


def ancillary_vs_bundle_separation() -> dict[str, float]:
    """Print the separation between the exact ancillary law and the normal bundle choice.

    The same exact ancillary law is compatible with different ambient normal geometries:
    - codimension-one ambient: zero normal curvature
    - codimension-two ambient: nonzero normal curvature
    """
    return {
        "codim_one_curvature": 0.0,
        "codim_two_curvature": float(np.linalg.norm(math.exp(-0.3) * M, ord="fro")),
        "ancillary_does_not_select_bundle": 1.0,
    }


def exact_symbolic_check() -> dict[str, object]:
    """Collect the exact symbolic formulas used in the proof of the local curvature comparison."""
    tau, h, k = sp.symbols("tau h k", real=True)
    M_sym = sp.Matrix([[0, -sp.Rational(28, 45)], [sp.Rational(9, 4), 0]])
    omega = sp.exp(-tau) * M_sym
    rectangle = sp.expand((sp.exp(-tau) - sp.exp(-(tau + k))) * h * M_sym)
    return {
        "omega_mu": sp.sstr(omega),
        "omega_tau": sp.sstr(sp.zeros(2, 2)),
        "small_loop_integral": sp.sstr(rectangle),
        "small_k_series": sp.sstr(sp.series((sp.exp(-tau) - sp.exp(-(tau + k))) * h, k, 0, 3)),
    }


def main() -> None:
    print("OP-3 local curvature vs small-loop transport")
    print("=" * 72)

    # Step 1: local curvature and small-loop transport
    for (mu0, tau0, h, k) in [(0.0, 0.3, 1e-3, 1e-3), (0.0, 0.7, 2e-3, 2e-3), (0.5, 0.7, 1e-2, 1e-2)]:
        transport, local_first_order, diff_norm = small_loop_transport(mu0, tau0, h, k)
        print(f"Parameters: mu0={mu0}, tau0={tau0}, h={h}, k={k}")
        print(f"  transport =\n{transport}")
        print(f"  local first-order approx =\n{local_first_order}")
        print(f"  Frobenius diff norm = {diff_norm:.3e}")
        print()

    print("Exact symbolic check")
    print("-" * 72)
    for key, value in exact_symbolic_check().items():
        print(f"{key}: {value}")
    print()

    # Step 2: noncontractible tau-loop period
    print("Noncontractible tau-loop period")
    print("-" * 72)
    transport, identity, period = tau_loop_period()
    print(f"transport along tau-loop =\n{transport}")
    print(f"identity =\n{identity}")
    print(f"period value = {period}")
    print()

    # Step 3: ancillary vs bundle separation
    print("Ancillary law vs selected normal bundle")
    print("-" * 72)
    sep = ancillary_vs_bundle_separation()
    for key, value in sep.items():
        print(f"{key}: {value}")
    print()

    print("Interpretation:")
    print("- local curvature and small-loop transport agree to first order in the explicit model;")
    print("- the tau-only noncontractible loop has zero period in this connection;")
    print("- an exact ancillary law does not select a unique normal bundle or a canonical connection.")


if __name__ == "__main__":
    main()
