"""Exact rectangular-loop transport for the explicit OP-3 model.

This script derives the exact matrix product for the rectangular loop in the
codimension-two model and compares it to the local curvature approximation.
"""

from __future__ import annotations

import math

import numpy as np
import sympy as sp
from scipy.linalg import expm


M = np.array([[0.0, -28.0 / 45.0], [9.0 / 4.0, 0.0]], dtype=float)


def exact_loop_transport(mu0: float, tau0: float, h: float, k: float) -> tuple[np.ndarray, np.ndarray, float]:
    """Compute the exact rectangular-loop transport using the fact that only the horizontal edges contribute.

    The connection is omega = exp(-tau) M dmu, so along the vertical edges dmu = 0 and omega=0.
    Hence the path-ordered transport is
        exp(-h exp(-(tau0+k)) M) * exp(h exp(-tau0) M)
    = exp(h (exp(-tau0) - exp(-(tau0+k))) M).
    """
    coeff = h * (math.exp(-tau0) - math.exp(-(tau0 + k)))
    exact = expm(coeff * M)
    approx = np.eye(2, dtype=float) + coeff * M
    diff = exact - approx
    return exact, approx, float(np.linalg.norm(diff, ord="fro"))


def symbolic_summary() -> dict[str, str]:
    tau0, h, k = sp.symbols("tau0 h k", real=True)
    coeff = h * (sp.exp(-tau0) - sp.exp(-(tau0 + k)))
    M_sym = sp.Matrix([[0, -sp.Rational(28, 45)], [sp.Rational(9, 4), 0]])
    exact = sp.expand(coeff * M_sym)
    series = sp.series(coeff, k, 0, 3)
    return {
        "coeff": str(coeff),
        "exact_transport_coefficient": str(exact),
        "small_k_series": str(series),
        "curvature_term": str(sp.exp(-tau0) * h * k * M_sym),
    }


def main() -> None:
    print("OP-3 exact rectangular-loop transport")
    print("=" * 80)
    for params in [(0.0, 0.3, 1e-3, 1e-3), (0.0, 0.7, 2e-3, 2e-3), (0.5, 0.7, 1e-2, 1e-2)]:
        mu0, tau0, h, k = params
        exact, approx, diff = exact_loop_transport(mu0, tau0, h, k)
        print(f"params: mu0={mu0}, tau0={tau0}, h={h}, k={k}")
        print(f"exact transport =\n{exact}")
        print(f"first-order approx =\n{approx}")
        print(f"Frobenius diff = {diff:.3e}")
        print()

    print("symbolic summary")
    print("-" * 80)
    for key, value in symbolic_summary().items():
        print(f"{key}: {value}")
    print()
    print("Interpretation:")
    print("- Along the rectangular loop, only the horizontal edges contribute because omega_tau = 0.")
    print("- The exact transport equals exp(h*(exp(-tau0)-exp(-(tau0+k))) M), which expands to I + h*k*exp(-tau0) M + O(h*k*(h+k)).")
    print("- Therefore the small-loop transport matches the local curvature term exactly to first order in the explicit model.")


if __name__ == "__main__":
    main()
