# OP-1: local curvature, global holonomy, and the selected score bundle

Date: 2026-10-06 22:46:35 +09:00
Agent: GitHub Copilot in VS Code
Scope: bounded investigation of OP-1 in `threads/fraser_structural_geometry/LEDGER.md`, following the five owner-specified steps.
Status: `proved/agent` for the conditional connection statements and the exact zero-period result under the stated reflection/global-rank hypotheses; the general approximate-ancillary theorem remains `open`; literature review `incomplete`.

## Scope and seed

The target is OP-1, “Local curvature versus global holonomy for the selected
score bundle,” in
[`research-scratch/fraser_structural_geometry/20261004-174134-open-problems.md`](./20261004-174134-open-problems.md).
This is one conditional theorem audit, not a new thread, campaign, ledger
update, or manuscript revision. The independent search pass was completed
before using the local bibliography. The candidate theorem below is deliberately
conditional on fixed ambient data and a smooth, constant-rank selected bundle.

### Candidate card

- `candidate_id`: `OP1-C1`
- `seed_refs`: thread OP-1 in the cited open-problems note; current thread
  ledger opportunity “local curvature versus global holonomy.”
- `transformation`: strengthen the ambient/connection and rank hypotheses;
  separate local contractible-loop transport from the `pi_1` contribution.
- `statement_draft`: for any smooth finite-rank score bundle selected by the
  stated approximate-ancillary projection, once its ambient, metric,
  connection, and projection are fixed, curvature determines the leading
  small-contractible-loop transport term; noncontractible transport is the
  path-ordered connection transport and reduces to a `pi_1` representation
  only in the flat case.
- `motivation`: prevent local curvature, global period, and ancillary
  selection from being conflated.
- `predictions`: changing a feature span or ambient extension may change the
  selected bundle or its holonomy while leaving the base model unchanged.
- `first_test`: test for a base reflection reversing the circle orientation
  while preserving the selected score feature and normal frame.
- `known_obstacles`: the original implementation left the statistic outside
  the local tube unspecified; this continuation gives a global measurable
  reflection-equivariant completion. Publisher literature coverage remains
  incomplete.
- `work_status`: `screened` as a conditional theorem candidate.
- `evidence_status`: `proved/agent` for the conditional transport statements
  and the symmetric-model zero-period result below; the general
  approximate-ancillary implication remains `open`.

## Step 1 — fixed ambient and connection

Let `B` be a smooth parameter manifold and let
`i : B -> M_tilde` be an immersion into a fixed regular statistical ambient
manifold with Fisher metric `g` and a specified smooth `alpha`-connection
`nabla^(alpha)`. Use the project convention
`Gamma^(alpha) = Gamma^(0) - alpha*T^sharp/2`.
Fix the metric-orthogonal normal projection along `i(B)`.

To specify which part of the normal score space is selected, let `P_theta` be
a regular dominated model on `B`, with score `s_a = partial_a log p_theta` and
nonsingular Fisher matrix `I_ab = E_theta[s_a*s_b]`. Let `A_n` be a fixed
statistic whose distribution may depend on `theta` (so it is only
approximately ancillary), and choose a finite family of bounded,
parameter-free functions `phi_j(A_n)`. Put

`u_j = phi_j(A_n) - E_theta[phi_j(A_n)]`,
`c_j^a = I^(ab) E_theta[s_b*u_j]`,
`nu_j = u_j - c_j^a*s_a`.

Then `E_theta[s_a*nu_j] = 0`. The residual Gram matrix is

`G_perp,ij(theta) = E_theta[nu_i*nu_j]`
`                  = E_theta[u_i*u_j] - E_theta[u_i*s_a] I^(ab) E_theta[s_b*u_j]`.

Assume the relevant residual rank is constant on the neighborhood under
study, the residual fields and moments are smooth, and the Fisher block of the
full model is nonsingular. These hypotheses make their span a smooth
finite-rank subbundle `E` of the Fisher normal space. A local statistical
ambient realizing the selection is the exponential tilt

`p_(theta,eta) = p_theta * exp(eta^j*phi_j(A_n) - psi(theta,eta))`,
`psi(theta,eta) = log E_theta[exp(eta^j*phi_j(A_n))]`.

At `eta=0`, the added coordinate scores are `u_j`; their Fisher-orthogonal
projections are exactly `nu_j`. Boundedness gives a finite normalizer near
`eta=0`; constant positive rank supplies local regularity. This constructs one
ambient extension and one score sector. It does not show that the original
Fraser model chose this extension.

For the fixed `E`, define its induced connection by

`D_X^(alpha) nu = Pi_E(nabla_X^(alpha) nu)`,

where `Pi_E` is the chosen projection onto `E`. In a local frame, write its
matrix-valued one-form as `A`; its curvature is

`F_E = dA + A wedge A`.

This is the local theorem's complete geometric input. A structural
distribution or an ancillary law alone does not provide `M_tilde`, `i`, `g`,
`alpha`, `E`, or `D^(alpha)`.

## Step 2 — contractible loops

Fix parallel transport by the convention
`dU/dt + A(gamma_dot) U = 0`, so
`Hol(gamma) = Pexp(-integral_gamma A)`.
For a positively oriented coordinate rectangle based at `p`, with sides
`epsilon X` and `epsilon Y`, smoothness gives

`Hol(gamma_epsilon) = Id - epsilon^2*F_E,p(X,Y) + O(epsilon^3)`.

The sign follows from the chosen transport convention and orientation. The
leading term follows by expanding the four edge transports and retaining their
first commutator/derivative term. Equivalently, curvature is the infinitesimal
generator of small-loop transport. For a scalar line bundle the commutator
vanishes, but the same order estimate applies.

For a finite contractible loop, the exact statement is the path-ordered
transport `Pexp(-integral_gamma A)`. In a nonabelian bundle it is not generally
`Id - integral_Omega F` for an arbitrary spanning surface: curvature has to be
transported to a common fiber and surface ordering matters. Curvature at one
point, or a single surface integral without these qualifications, does not
classify an individual loop. This local expansion also has remainder
`O(epsilon^3)` for a fixed-shape loop, not a general `O(area^2)` remainder;
with both side lengths of order `epsilon`, `area^2` is order `epsilon^4` and
is too strong without extra cancellation or regularity structure.

## Step 3 — noncontractible loops and periods

For any based loop, contractible or not, the fixed-connection holonomy is
defined by the same path-ordered ODE. In a globally trivialized rank-one
bundle, with scalar connection form `omega`, this reduces to

`Hol(gamma) = exp(-integral_gamma omega)`.

Thus on the selected `S^1 x R` model at fixed `lambda=lambda_0`, the relevant
period is

`P(lambda_0) = integral_0^(2*pi) omega_theta(theta,lambda_0) dtheta`,
`Hol(generator) = exp(-P(lambda_0))`.

This is the precise period to derive or certify for the OP-1 model. The
existing shifted-label, `alpha=1`, `n=400` calculation reports nonzero local
curvature estimates near `2.64107e-5` at `(theta,lambda)=(pi/4,0.7)`, and
8- and 16-point global-loop holonomies numerically indistinguishable from one
(`0.99999999999960` and `1.00000000000022`). It uses quadrature and
finite-difference connection coefficients, without tail or interval-error
certification. Those numbers alone do not establish `P(lambda_0)=0` exactly.
However, the model has a reflection symmetry that gives an exact zero-period
result under the global regularity conditions below. See the numerical scope in
[`research-scratch/fraser_structural_geometry/20261004-162349-conditional-ancillary-score.md`](./20261004-162349-conditional-ancillary-score.md).

### Exact period cancellation for the OP-1 reflection-symmetric model

Consider the OP-1 cylinder model with
`gamma(theta)=(cos(theta),2 sin(theta))`, independent
`Ybar_3 ~ N(lambda,1/n)`, and the shifted label using
`q(a,Ybar_3)=sin(a)*tanh(Ybar_3)`. Assume its tube statistic is defined
globally up to a probability-zero cut locus in a way that respects Euclidean
reflection, and use the bounded selected feature
`h=tanh(sqrt(n)*B_n^q)`.

Let `S=diag(-1,1)` act on the first two sample coordinates, and let
`f(theta,lambda)=(pi-theta,lambda)` on the cylinder (angles are modulo
`2*pi`). The identities

`gamma(pi-a)=S*gamma(a)`,
`N(pi-a)=S*N(a)`,
`speed(pi-a)=speed(a)`,
`kappa(pi-a)=kappa(a)`,
`q(pi-a,Ybar_3)=q(a,Ybar_3)`

show that the sample-space reflection sends the tube point at `(a,u,Ybar_3)`
to the tube point at `(pi-a,u,Ybar_3)`, preserving the signed normal
coordinate and the selected feature. The Gaussian base family is carried to
itself with parameter changed from `theta` to `pi-theta`; the `lambda` score
and selected feature are preserved, while the coordinate `theta` score
changes sign. Consequently the transformation is an isometry of the Fisher
score geometry and preserves its cubic tensor. It therefore preserves the
induced `alpha`-connection and the Fisher-orthogonal residual line.

The residual line has a global frame wherever the residual variance is
positive: take its residual score with coefficient `+1` on the selected
feature and divide by its positive Fisher norm. That variance is strictly
positive at every base point if the feature is bounded and nonconstant under
the full-support Gaussian law. Otherwise the feature would equal a constant
plus a linear combination of the two base scores almost surely; those scores
are nonzero linear functions of the full-support Gaussian observation and
cannot combine to a bounded nonconstant function. Expectations of the bounded
feature and its score products are smooth in `(theta,lambda)` by dominated
differentiation of the Gaussian density. Thus the selected rank-one bundle and
unit frame are global under the stated tube-statistic assumption.

In this frame the reflection acts without a sign change on the normal section.
Naturality of the projected connection gives `f^*omega=omega`; since
`df(partial_theta)=-partial_theta`, its coefficient satisfies

`omega_theta(pi-theta,lambda) = -omega_theta(theta,lambda)`.

Pairing points under `f` in the full circle integral now yields

`P(lambda)=integral_0^(2*pi) omega_theta(theta,lambda)dtheta = 0`,
`Hol(generator)=exp(-P(lambda))=1`.

This exact cancellation does not imply zero local curvature: a nonzero
curvature two-form may have a globally cancelling circle period. It also does
not follow from approximate ancillarity alone; the reflection-equivariant
statistic, full-rank selected line, and induced connection are essential
hypotheses. The next section gives an explicit global completion, including
its cut-locus convention, so the reflection hypothesis is realized for the
specified statistic rather than left as an implicit assumption.

As a symmetry sanity check, the existing quadrature routine was imported with
`ANGLE_COUNT=64`, `NORMAL_COUNT=40`, and `GAUSSIAN_COUNT=20`, and evaluated at
five angles together with their reflected angles. The sums
`omega_theta(theta)+omega_theta(pi-theta)` ranged in absolute value from
`1.3e-13` to `8.2e-13`. Periodic trapezoid sums with 4, 8, and 16 points
were respectively `-3.22e-13`, `-1.24e-12`, and `-6.00e-13`. These are
floating-point implementation checks only; exact cancellation is from the
reflection argument, not from the quadrature values.

If `D^(alpha)` is flat, holonomy is invariant under based homotopy and defines
a representation of `pi_1(B)`; on a simply connected base it is trivial. If
curvature is nonzero, loop transport is not determined by the homotopy class
alone, and the line integral is not a topological period invariant. For a
nontrivial line bundle, chart transition maps must also be included; the
displayed scalar integral presumes a global frame along the circle.

There is a separate issue in the earlier OP-3 transport note:
`omega_mu = exp(-tau)*M`, `omega_tau = 0` does not descend under
`tau ~ tau+2*pi`, because its coefficient is not periodic. A path changing
`tau` by `2*pi` is not a closed loop on the original `R` parameter space, and
the stated form is not a connection on that quotient cylinder. Its identity
transport calculation is valid along a tau-only path in a chosen chart, but
does not establish a noncontractible cylinder period. See
[`research-scratch/fraser_structural_geometry/20261006-op3-transport-propositions.md`](./20261006-op3-transport-propositions.md).

## Step 4 — ancillary selection versus bundle dependence

The residual construction above separates three choices:

1. **Statistic/label:** `A_n` is parameter-free as a map on the sample space,
   but its distribution can vary with `theta`. Its conditional score
   `E_theta[s | A_n]` need not vanish.
2. **Selected score sector:** the chosen feature span
   `span{phi_j(A_n)}` determines the residual bundle after Fisher projection.
   Changing the ancillary label, feature family, or truncation can change this
   bundle. An invertible change of basis within the same feature span changes
   only its frame.
3. **Ambient transport:** the exponential tilt, Fisher metric, immersion,
   normal projection, and `alpha` determine the connection on that bundle.
   A different ambient extension or `alpha` can change curvature and
   holonomy while preserving the same base model and ancillary statistic.

Indeed,
`E_theta[s_a*u_j] = partial_a E_theta[phi_j(A_n)]`.
The projection removes this distributional response's tangent component; it
does not select a unique connection. Only after specifying the full set of
data and a projection rule is curvature or holonomy defined. The
exact-ancillary case is a useful boundary: its full `L^2_0` ancillary score
sector is Fisher-orthogonal to the tangent scores, but a finite subspace and
ambient extension remain choices. For approximate ancillaries, even the
orthogonality requires the projection above.

## Step 5 — theorem boundary

**Conditional theorem.** Suppose a regular dominated statistical model,
fixed ambient metric and `alpha`-connection, immersion, and normal projection
are specified on a connected base `B`. Suppose a parameter-free approximate
ancillary and bounded feature family induce a smooth residual score bundle
`E` of constant finite rank, with positive-definite residual Fisher Gram
matrix, and the projected connection `D^(alpha)` is smooth. Then:

1. `D^(alpha)` and `F_E` are well-defined;
2. `F_E` gives the order-`epsilon^2` term of parallel transport around small
   contractible loops, with the sign and remainder specified above;
3. full holonomy around a noncontractible loop is the path-ordered transport
   of this fixed connection, and in a global rank-one frame is the exponential
   of its connection integral;
4. only in the flat case does this global transport descend to a
   `pi_1(B)`-representation, with trivial representation on a simply connected
   base;
5. if the full statistical model, selected feature, and residual unit frame
   are equivariant under a base reflection reversing the loop orientation,
   then the corresponding scalar connection coefficient is odd under that
   reflection and the loop period vanishes exactly.

The first two conclusions follow directly from the smooth projected
connection and the local parallel-transport expansion. The global statements
follow from the transport ODE and flat path-independence. The theorem is
conditional on the selected bundle and connection; it does not claim that
approximate ancillarity canonically selects either one.

**Decision:** the noncontractible period for the reflection-equivariant
OP-1 rank-one model is exactly zero, provided the stated global tube
definition holds. This upgrades the previous numerical near-identity
observation to an analytic model-specific result. Retain the general OP-1
claim as open: the result does not identify a canonical bundle for arbitrary
approximate ancillaries and does not extend to nonsymmetric score selections.

**Next discriminating step:** investigate whether the local nonzero curvature
for this explicitly completed model can be certified analytically or with
rigorous error bounds. A nonsymmetric label would require a separate
full-circle period analysis.

## Literature record

Search date: 2026-10-06. All searches were public-site requests; no access
controls were bypassed.

### Independent question-driven pass (before using local bibliography)

Research question: under what fixed geometric and regularity data does
curvature control contractible normal-bundle holonomy, how does `pi_1` enter
global holonomy, and can an approximate ancillary select the relevant score
bundle?

- **arXiv API**, each query inspected as returned (one page, zero results):
  - `all:"ancillary" AND all:"normal connection"` — 0.
  - `all:"statistical manifold" AND holonomy AND curvature` — 0.
  - `all:"global holonomy" AND all:"normal bundle"` — 0.
- **SpringerLink**, three distinct query families were attempted:
  - `ancillary normal connection statistical manifold`
  - `statistical manifold holonomy curvature alpha connection`
  - `flat connection nontrivial holonomy fundamental group normal bundle`
  Each search endpoint returned HTTP 406; result pages and full texts were
  unavailable.
- **SIAM Journals**, three distinct query families were attempted:
  - `ancillary normal connection statistical manifold`
  - `statistical manifold holonomy curvature alpha connection`
  - `flat connection nontrivial holonomy fundamental group`
  Each search endpoint returned HTTP 403; result pages and full texts were
  unavailable.

### Supplementary local-reference route

The local catalog was checked first using `uv run python
tools/reference_lookup.py` for “normal connection holonomy,” keyword
“ancillary,” and Fraser/Ambrose/Singer author fragments; these searches
returned no matches. The supplementary local seed was `tem.md`, introduction,
§4.1, and references: Fraser, Fraser & Staicu, “Second order ancillary: A
differential view from continuity” (2010), arXiv:1011.5779v1,
DOI `10.3150/10-BEJ248`. The arXiv title query returned one result. Its
abstract and §1 were inspected at
<https://arxiv.org/abs/1011.5779> and
<https://ar5iv.labs.arxiv.org/html/1011.5779>. The source describes
parameter-free ancillary distributions and second-order ancillary contours
from quantile continuity; it notes the vector-parameter Frobenius
compatibility issue. It does not identify those contours with a statistical
normal connection or establish a holonomy theorem.

Exact-title searches for that local seed were also attempted at SpringerLink
(HTTP 406) and SIAM (HTTP 403). An arXiv search for `Ambrose-Singer` and
holonomy returned 14 records on one page; the relevant search lead
“Structure groups and holonomy in infinite dimensions” (Magnot,
arXiv:math/0212160v1) was inspected at its discussion in §4. It treats
holonomy/curvature theorems in a different, infinite-dimensional setting and
is not used to certify the present finite-dimensional result.

### Candidate-specific pass

After formulating the conditional theorem, candidate-specific searches were
attempted:

- **arXiv API**, one page per query; all returned 0:
  - `all:"normal holonomy" AND all:"approximate ancillary"`
  - `all:"score bundle" AND holonomy AND curvature`
  - `ancillary AND all:"global holonomy" AND periods`
- **SpringerLink**:
  - `approximate ancillary score bundle holonomy curvature`
  - `normal connection curvature small loop parallel transport`
  - `noncontractible loop flat connection period holonomy`
  All returned HTTP 406.
- **SIAM Journals**:
  - `approximate ancillary score bundle holonomy curvature`
  - `normal connection curvature small loop parallel transport`
  - `noncontractible loop flat connection period holonomy`
  All returned HTTP 403.

The candidate's literature review is therefore `incomplete`. The zero-result
arXiv searches and the unavailable publisher searches do not establish
novelty or corpus-wide absence. No candidate-specific claim is classified
`proved/literature`.

## Evidence classification and disposition

- Fixed-bundle local definitions and small-loop expansion:
  `proved/agent`, under the explicitly stated smoothness and rank hypotheses.
- Flat connection, simply connected trivial holonomy, and rank-one period
  formula: `proved/agent` for the fixed connection and specified
  trivialization.
- Approximate-ancillary-to-canonical-bundle or global-holonomy implication:
  `open` in general. For the OP-1 symmetric model, the period is established
  conditionally by the next item.
- OP-1 circle period: `proved/agent` exactly under the full-circle,
  reflection-equivariance, and global positive-rank assumptions above.
  The numerical check is `verified-computationally` only at the reduced
  quadrature and angle samples reported in the continuation record.
- Literature: `incomplete`; no novelty claim.

No ledger, canonical note, or manuscript was changed.

## Continuation: explicit global tube statistic and cut-locus rule

Date: 2026-10-07 07:49:42 +09:00
Agent: GitHub Copilot in VS Code
Status: `proved/agent` for measurability, almost-sure uniqueness, and
reflection equivariance of the global completion below.

The previous period proof assumed a global reflection-equivariant tube
statistic. Here is one explicit completion. Write the sufficient observation
as `(y,z) in R^2 x R`, let
`Gamma = {gamma(phi) : phi in S^1}` with
`gamma(phi)=(cos(phi),2 sin(phi))`, and let `Pi(y)` be the set of nearest
points on the compact ellipse. On the set where `Pi(y)` is a singleton, write
its unique point as `gamma(phi(y))`. Let `d(y)=dist(y,Gamma)`, and define the
signed distance `a(y)` to be positive inside the ellipse, negative outside,
and zero on its boundary. With the inward unit normal `N(phi)`, one has
`y=gamma(phi(y))+a(y)N(phi(y))`.

Use the geometric curvature
`kappa(phi)=2/(sin(phi)^2+4 cos(phi)^2)^(3/2)` and set, off the cut locus,

`B_n^q(y,z) = a(y) + kappa(phi(y))/(2n)`
`             + n^(-3/2)*sin(phi(y))*tanh(z)`.

Set `B_n^q(y,z)=0` on the cut locus. The selected feature is
`h_n(y,z)=tanh(sqrt(n)*B_n^q(y,z))`. This agrees with the earlier local
tube formula wherever the nearest-point coordinate is unique; it replaces
the previously unspecified outside-tube extension for this explicit global
model. The use of an all-plane nearest-point statistic is a choice of
completion, not a claim that all extensions define the same finite-n
statistic.

### The cut locus is measurable and null

Let `C={y: Pi(y) has at least two points}`. For each positive integer `m`,
let `C_m` be the set of `y` for which there exist `p,q in Gamma` with
`|p-q| >= 1/m` and
`|y-p|=|y-q|=d(y)`. Compactness of `Gamma` and continuity of distance show
that each `C_m` is closed: for a convergent sequence in `C_m`, take
convergent subsequences of the two witnessing nearest points. Every pair of
distinct nearest points is separated by at least `1/m` for some `m`, hence
`C=union_m C_m` is Borel.

For `y` off `Gamma`, if it has two distinct nearest points, the distance
function `d` is not differentiable at `y`. Indeed, its one-sided directional
derivative in direction `v` is the minimum over nearest points `p` of
`< (y-p)/d(y), v >`; two distinct nearest points give distinct unit vectors,
so these directional derivatives cannot be a single linear functional for
all `v`. Since `d` is Lipschitz, Rademacher's theorem implies that its
nondifferentiability set has two-dimensional Lebesgue measure zero.
Consequently `C` is null (the ellipse itself is also null). The Gaussian
law of `Ybar` is absolutely continuous, so `P_(theta,lambda)(Ybar in C)=0`
for every parameter value.

On the unique-projection set the nearest-point map is continuous: any
convergent sequence of observations has nearest points whose subsequential
limits minimize distance at the limiting observation, and uniqueness forces
all such limits to coincide. Together with the Borel cut set this makes
`phi(y)` and `B_n^q` measurable. Assigning the fixed value zero on `C`
therefore defines a measurable statistic on all of sample space. It does
not change any of its expectations or Fisher moments relative to any other
completion on `C`.

### Reflection equivariance on all sample space

Let `S=diag(-1,1)` and `f(phi)=pi-phi` on `S^1`. Then
`gamma(f(phi))=S gamma(phi)`,
`N(f(phi))=S N(phi)`,
`kappa(f(phi))=kappa(phi)`, and
`sin(f(phi))=sin(phi)`. Since `S` is an isometry preserving the ellipse and
its interior, `Pi(Sy)=S Pi(y)` as sets and `d(Sy)=d(y)`. The cut locus is
therefore invariant under `S`; on its complement the unique footpoint
transforms by `phi(Sy)=f(phi(y))`, and the signed distance is unchanged.
Thus

`B_n^q(Sy,z)=B_n^q(y,z)` and `h_n(Sy,z)=h_n(y,z)`

off the cut locus. On the cut locus the equality holds because both values
were assigned zero. Hence reflection equivariance is pointwise on the full
sample space, not merely almost surely.

Under `(theta,lambda) -> (pi-theta,lambda)`, the Gaussian experiment is
carried to itself by `(y,z) -> (Sy,z)`. The feature `h_n` is invariant.
The exponential-tilt ambient generated by `h_n` is consequently equivariant
as well. Its Fisher metric and cubic tensor, and hence every fixed
`alpha`-connection under the project convention, are preserved. The
Fisher-residual score has a global coefficient-one frame, and its variance
is strictly positive: if its residual variance vanished, the bounded
nonconstant feature would equal a constant plus a linear combination of
the two unbounded Gaussian base scores almost surely, which full support
rules out. Nonconstancy follows already by varying `z` in an open tube
where `sin(phi) != 0`. The positive residual norm makes the normalized
frame global and reflection-preserving. Therefore the earlier oddness
identity for `omega_theta` and exact zero-period conclusion apply to this
explicit global completion.

The pointwise feature `h_n` is bounded. Its expectations and score moments
are smooth in `(theta,lambda)` by dominated differentiation of the Gaussian
density on compact parameter neighborhoods; the residual variance remains
positive everywhere by the argument above. Thus the selected line bundle
and its projected `alpha`-connection are globally regular on `S^1 x R`.
This removes the cut-locus and constant-rank qualifications for this
particular completed model. It does not remove the symmetry requirement or
make the selected bundle canonical for other approximate ancillaries.

**Conclusion:** the model-specific OP-1 period is exactly zero for the
explicit global statistic just defined, for every `lambda`, every positive
integer `n`, and every fixed real `alpha` for which the same score-moment
connection is used. The general approximate-ancillary/global-holonomy
question remains `open`.

## Continuation: local curvature refinement and sample-size scaling

Date: 2026-10-07 08:02:43 +09:00
Agent: GitHub Copilot in VS Code
Status: `verified-computationally` for the numerical settings and finite
parameter values below; the exact nonzero-curvature claim remains `open`.

### Question

Does the shifted-label model's numerically reported local curvature persist
under quadrature/finite-difference refinement, and what sample-size order is
suggested by this model? This checks local nonflatness, not the already proved
reflection cancellation of the full-circle period.

### Method and exact scope

Ran the project computation preflight from the workspace root:

`uv run python tools/computation_preflight.py`

It passed with Python 3.14.6, SymPy 1.14.0, NumPy 2.5.3, and SciPy 1.18.1.
The calculation used double-precision NumPy/SciPy, the existing
`curvature_holonomy_2d_base.py` implementation, `alpha=1`,
`(theta,lambda)=(pi/4,0.7)`, and centered differences in the existing
curvature routine. The curvature step `h` also sets the internal connection
derivative step to `h/4`.

First, for `n=400`, refined quadrature grids
`(angle, normal, Gaussian)=(64,40,20),(96,48,24),(128,64,32)` and used
`h=0.04,0.02,0.01`. Results:

| Grid | Label | h=0.04 | h=0.02 | h=0.01 |
|---|---|---:|---:|---:|
| (64,40,20) | baseline | `3.51e-32` | `4.07e-33` | `-1.14e-31` |
| (64,40,20) | shifted | `2.64107005e-5` | `2.64097454e-5` | `2.64094948e-5` |
| (96,48,24) | baseline | `6.93e-33` | `-9.90e-33` | `3.11e-32` |
| (96,48,24) | shifted | `2.64116357e-5` | `2.64106576e-5` | `2.64104220e-5` |
| (128,64,32) | baseline | `1.50e-32` | `-1.87e-32` | `1.52e-31` |
| (128,64,32) | shifted | `2.64117034e-5` | `2.64107015e-5` | `2.64105794e-5` |

Second, fixed the quadrature grid at `(96,48,24)`, used `h=0.02`, and
varied `n`:

| n | Baseline curvature | Shifted curvature | `n^(3/2)` × shifted curvature |
|---:|---:|---:|---:|
| 400 | `-9.90e-33` | `2.64106576e-5` | `0.21128526` |
| 800 | `1.70e-31` | `9.33802250e-6` | `0.21129533` |
| 1600 | `9.51e-32` | `3.30153715e-6` | `0.21129838` |
| 3200 | `8.92e-32` | `1.16727385e-6` | `0.21129914` |

The quadrature study used the existing script's local tangent window
`[-8,8]`, scaled normal window `[-8,8]`, and Gauss-Hermite integration for
the independent Gaussian coordinate. The outputs are deterministic for the
listed floating-point inputs. No interval arithmetic, certified tail bound,
or rigorous bound on finite-difference truncation was used. The full-plane
statistic is defined globally, but the numerical integral is the existing
local-window approximation; these data are not a rigorous enclosure of its
exact Fisher moments.

### Interpretation

At the tested point the shifted-label curvature remains positive over all
three resolutions and the three finite-difference steps; the baseline result
is at floating-point cancellation scale. The rescaled values strongly suggest
an `n^(-3/2)` leading order, with coefficient near `0.21130` at this point.
This matches the explicit `n^(-3/2)` label displacement as a plausible
mechanism, but the finite sequence does not prove an asymptotic expansion or
its coefficient. In particular:

- the exact reflection argument proves zero period for the symmetric
  full-circle model, independently of these numerical values;
- nonzero curvature here is supported numerically but is not yet
  `proved/agent`;
- near-zero baseline curvature and apparent sample-size scaling are
  computational observations only;
- general approximate-ancillary curvature/holonomy remains `open`.

### Reproduction recipe

The exact reproducible command from the workspace root is

`uv run python .research-scratch/fraser_structural_geometry/20261007-op1-curvature-refinement.py`

The driver imports
`.research-scratch/fraser_structural_geometry/20261004-approx-ancillary/curvature_holonomy_2d_base.py`,
sets the grid and sample-size values listed above, and evaluates
`curvature(THETA0,LAMBDA0,label,1.0,h)` with cache clears between runs. All
numerical geometry/moment evaluation remains in the existing NumPy/SciPy
model implementation. The driver was rerun successfully after being saved.

**Best next test:** derive the leading `n^(-3/2)` curvature coefficient
analytically from the local tube/Laplace expansion, or construct rigorous
quadrature and derivative enclosures at one fixed `n` to certify the sign.
