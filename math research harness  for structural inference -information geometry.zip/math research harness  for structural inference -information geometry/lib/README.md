# Reusable research code

Place maintained reusable code here, organized according to the selected
language or mathematical system. Give it stable interfaces and tests.

Do not copy one-off experiment logic into this layer. Promote it deliberately
when it becomes reusable, then make experiments call the maintained version.
