"""Validate local reference records and deterministically regenerate catalogs."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from reference_common import CatalogError, catalog_json, catalog_markdown, collect_records


WORKSPACE_ROOT = Path(__file__).resolve().parents[1]


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=WORKSPACE_ROOT,
                        help="workspace root (defaults to the repository root)")
    parser.add_argument("--item", action="append", default=[], metavar="PATH",
                        help="also report validation of this workspace-relative item record")
    parser.add_argument("--check", action="store_true",
                        help="validate records and fail if generated catalogs are missing or stale")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    root = args.root.resolve()
    references = root / "references"
    if not args.check:
        for directory in (references / "items", references / "external", references / "derived" / "text"):
            directory.mkdir(parents=True, exist_ok=True)

    try:
        records = collect_records(root)
        known_paths = {record["record_path"] for record in records}
        for requested in args.item:
            normalized = Path(requested).as_posix().removeprefix("./")
            if normalized not in known_paths:
                raise CatalogError(f"--item is not a valid discovered record: {requested}")

        outputs = {
            references / "CATALOG.json": catalog_json(records),
            references / "CATALOG.md": catalog_markdown(records),
        }
        stale = [path for path, content in outputs.items()
                 if not path.is_file() or path.read_text(encoding="utf-8") != content]
        if args.check:
            if stale:
                names = ", ".join(path.relative_to(root).as_posix() for path in stale)
                print(f"Catalogs are stale or missing: {names}", file=sys.stderr)
                return 1
            print(f"Validated {len(records)} reference record(s); catalogs are current.")
            return 0

        for path, content in outputs.items():
            path.write_text(content, encoding="utf-8", newline="\n")
        print(f"Validated {len(records)} reference record(s); regenerated CATALOG.json and CATALOG.md.")
        return 0
    except (CatalogError, OSError) as error:
        print(error, file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())