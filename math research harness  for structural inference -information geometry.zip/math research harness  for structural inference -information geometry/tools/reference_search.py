"""Build native-site literature search URLs for the required publishers."""

from __future__ import annotations

import argparse
import json
import sys
import webbrowser
from dataclasses import dataclass
from urllib.parse import urlencode


@dataclass(frozen=True)
class SearchProvider:
    key: str
    name: str
    endpoint: str
    query_parameter: str
    fixed_parameters: tuple[tuple[str, str], ...] = ()


PROVIDERS = (
    SearchProvider("arxiv", "arXiv", "https://arxiv.org/search/", "query",
                   (("searchtype", "all"), ("abstracts", "show"),
                    ("order", "-announced_date_first"))),
    SearchProvider("springer", "SpringerLink", "https://link.springer.com/search", "query"),
    SearchProvider("siam", "SIAM", "https://epubs.siam.org/action/doSearch", "AllField"),
)
PROVIDER_BY_KEY = {provider.key: provider for provider in PROVIDERS}


def build_search_targets(queries: list[str], provider_keys: list[str] | None = None) -> list[dict[str, str]]:
    cleaned_queries = [query.strip() for query in queries]
    if not cleaned_queries or any(not query for query in cleaned_queries):
        raise ValueError("at least one non-empty query is required")

    selected_keys = provider_keys or [provider.key for provider in PROVIDERS]
    unknown = sorted(set(selected_keys) - PROVIDER_BY_KEY.keys())
    if unknown:
        raise ValueError(f"unknown provider(s): {', '.join(unknown)}")

    targets = []
    for provider_key in selected_keys:
        provider = PROVIDER_BY_KEY[provider_key]
        for query in cleaned_queries:
            parameters = dict(provider.fixed_parameters)
            parameters[provider.query_parameter] = query
            targets.append({
                "provider": provider.key,
                "provider_name": provider.name,
                "query": query,
                "url": f"{provider.endpoint}?{urlencode(parameters)}",
            })
    return targets


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--query", action="append", required=True,
                        help="search phrase; repeat for multiple independent queries")
    parser.add_argument("--provider", action="append", choices=tuple(PROVIDER_BY_KEY),
                        help="provider key; repeat to limit searches (default: all three)")
    parser.add_argument("--open", action="store_true",
                        help="open each native search page in the default browser")
    parser.add_argument("--json", action="store_true", help="emit machine-readable JSON")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        targets = build_search_targets(args.query, args.provider)
    except ValueError as error:
        print(error, file=sys.stderr)
        return 2

    if args.open:
        for target in targets:
            target["opened"] = str(bool(webbrowser.open_new_tab(target["url"]))).lower()

    if args.json:
        print(json.dumps(targets, ensure_ascii=False, indent=2))
    else:
        for target in targets:
            state = f" [opened={target['opened']}]" if args.open else ""
            print(f"{target['provider_name']} | {target['query']}{state}\n  {target['url']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())