"""Shared schema, path-safety, and normalization helpers for reference tools."""

from __future__ import annotations

import json
import re
import unicodedata
from pathlib import Path, PurePosixPath
from typing import Any


SCHEMA_VERSION = 1
ASSET_ROLES = {"original", "pdf", "source", "tex", "text", "metadata"}
DASHES = "\u2010\u2011\u2012\u2013\u2014\u2212\ufe58\ufe63\uff0d"


class CatalogError(ValueError):
    """Invalid source metadata, catalog data, or workspace path."""


def normalize(value: str) -> str:
    decomposed = unicodedata.normalize("NFKD", value).casefold()
    without_marks = "".join(char for char in decomposed
                            if not unicodedata.combining(char))
    dashed = without_marks.translate(str.maketrans({char: "-" for char in DASHES}))
    dashed = re.sub(r"-{2,}", "-", dashed)
    return re.sub(r"\s+", " ", dashed).strip()


def read_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise CatalogError(f"{path}: cannot read valid UTF-8 JSON: {error}") from error


def safe_reference_path(root: Path, raw_path: str, *, must_exist: bool = True) -> Path:
    if not isinstance(raw_path, str) or not raw_path or "\\" in raw_path:
        raise CatalogError(f"invalid workspace-relative path: {raw_path!r}")
    relative = PurePosixPath(raw_path)
    if relative.is_absolute() or ".." in relative.parts or "." in relative.parts:
        raise CatalogError(f"path must be relative and cannot traverse: {raw_path!r}")
    if not relative.parts or relative.parts[0] != "references":
        raise CatalogError(f"asset path must be under references/: {raw_path!r}")

    root_resolved = root.resolve()
    result = root_resolved.joinpath(*relative.parts).resolve()
    try:
        result.relative_to(root_resolved)
    except ValueError as error:
        raise CatalogError(f"path escapes workspace: {raw_path!r}") from error
    if must_exist and not result.is_file():
        raise CatalogError(f"asset does not exist or is not a file: {raw_path}")
    return result


def _require_string(value: Any, field: str, source: Path, *, nonempty: bool = True) -> str:
    if not isinstance(value, str) or (nonempty and not value.strip()):
        raise CatalogError(f"{source}: {field} must be a non-empty string")
    return value


def validate_record(record: Any, source: Path, root: Path, expected_kind: str) -> dict[str, Any]:
    if not isinstance(record, dict):
        raise CatalogError(f"{source}: record must be a JSON object")
    if record.get("schema_version") != SCHEMA_VERSION:
        raise CatalogError(f"{source}: schema_version must be {SCHEMA_VERSION}")

    slug = _require_string(record.get("slug"), "slug", source)
    if not re.fullmatch(r"[a-z0-9][a-z0-9._-]*", slug):
        raise CatalogError(f"{source}: slug must use lowercase letters, digits, '.', '_' or '-'")
    if record.get("kind") != expected_kind:
        raise CatalogError(f"{source}: kind must be {expected_kind!r}")

    source_resolved = source.resolve()
    if expected_kind == "local":
        expected_parent = (root / "references" / "items").resolve()
        if not source_resolved.is_relative_to(expected_parent):
            raise CatalogError(f"{source}: local item records must be under references/items/")
        if source.parent.name != slug or source.name != "item.json":
            raise CatalogError(f"{source}: expected .../{slug}/item.json")
    else:
        expected_parent = (root / "references" / "external").resolve()
        if source_resolved.parent != expected_parent or source.name != f"{slug}.json":
            raise CatalogError(f"{source}: external record must be references/external/{slug}.json")

    identity = record.get("bibliographic_identity")
    if not isinstance(identity, dict):
        raise CatalogError(f"{source}: bibliographic_identity must be an object")
    _require_string(identity.get("title"), "bibliographic_identity.title", source)
    authors = identity.get("authors")
    if not isinstance(authors, list) or not authors:
        raise CatalogError(f"{source}: bibliographic_identity.authors must be a non-empty list")
    for index, author in enumerate(authors):
        _require_string(author, f"bibliographic_identity.authors[{index}]", source)

    year = identity.get("year")
    if year is not None and (type(year) is not int or not 1 <= year <= 9999):
        raise CatalogError(f"{source}: bibliographic_identity.year must be a year or null")
    identifiers = identity.get("identifiers")
    if not isinstance(identifiers, dict):
        raise CatalogError(f"{source}: bibliographic_identity.identifiers must be an object")
    for key, value in identifiers.items():
        if not isinstance(key, str) or (value is not None and not isinstance(value, str)):
            raise CatalogError(f"{source}: identifiers must map strings to strings or null")
    keywords = identity.get("keywords")
    if not isinstance(keywords, list):
        raise CatalogError(f"{source}: bibliographic_identity.keywords must be a list")
    for index, keyword in enumerate(keywords):
        _require_string(keyword, f"bibliographic_identity.keywords[{index}]", source)
    abstract = identity.get("abstract")
    if abstract is not None and not isinstance(abstract, str):
        raise CatalogError(f"{source}: bibliographic_identity.abstract must be a string or null")

    provenance = record.get("provenance")
    if not isinstance(provenance, dict):
        raise CatalogError(f"{source}: provenance must be an object")
    _require_string(provenance.get("recorded_from"), "provenance.recorded_from", source)

    assets = record.get("assets")
    if not isinstance(assets, list) or not assets:
        raise CatalogError(f"{source}: assets must be a non-empty list")
    for index, asset in enumerate(assets):
        field = f"assets[{index}]"
        if not isinstance(asset, dict):
            raise CatalogError(f"{source}: {field} must be an object")
        asset_path = _require_string(asset.get("path"), f"{field}.path", source)
        role = _require_string(asset.get("role"), f"{field}.role", source)
        if role not in ASSET_ROLES:
            raise CatalogError(f"{source}: {field}.role must be one of {sorted(ASSET_ROLES)}")
        resolved_asset = safe_reference_path(root, asset_path)
        asset_parts = PurePosixPath(asset_path).parts
        if expected_kind == "local" and asset_parts[:2] not in {
            ("references", "items"), ("references", "derived")
        }:
            raise CatalogError(f"{source}: local assets must be under references/items/ or references/derived/")
        if expected_kind == "external" and not PurePosixPath(asset_path).parts[:2] == ("references", "derived"):
            raise CatalogError(f"{source}: external records may only list local derivatives under references/derived/")
        asset_source = asset.get("source")
        if role in {"tex", "text"}:
            _require_string(asset_source, f"{field}.source", source)
        elif asset_source is not None and not isinstance(asset_source, str):
            raise CatalogError(f"{source}: {field}.source must be a string or null")
        if isinstance(asset_source, str) and asset_source.startswith("references/"):
            safe_reference_path(root, asset_source)
        if expected_kind == "external" and not resolved_asset.is_relative_to(
            (root / "references" / "derived").resolve()
        ):
            raise CatalogError(f"{source}: external derivatives must be under references/derived/")

    return record


def collect_records(root: Path) -> list[dict[str, Any]]:
    references = root / "references"
    records: list[dict[str, Any]] = []
    for kind, paths in (
        ("local", sorted((references / "items").glob("**/item.json"))),
        ("external", sorted((references / "external").glob("*.json"))),
    ):
        for path in paths:
            record = validate_record(read_json(path), path, root, kind)
            catalog_record = dict(record)
            catalog_record["record_path"] = path.resolve().relative_to(root.resolve()).as_posix()
            records.append(catalog_record)

    records.sort(key=lambda record: (
        normalize(record["bibliographic_identity"]["authors"][0]),
        normalize(record["bibliographic_identity"]["title"]),
        record["bibliographic_identity"]["year"] or 0,
        record["record_path"],
    ))
    seen: dict[tuple[str, str], str] = {}
    for record in records:
        identity = record["bibliographic_identity"]
        for key in ("arxiv", "doi"):
            value = identity["identifiers"].get(key)
            if not value:
                continue
            normalized = normalize_identifier(key, value)
            identity_key = (key, normalized)
            if identity_key in seen:
                raise CatalogError(
                    f"duplicate {key} identifier {value!r} in {seen[identity_key]} and {record['record_path']}"
                )
            seen[identity_key] = record["record_path"]
    return records


def normalize_identifier(kind: str, value: str) -> str:
    normalized = normalize(value)
    if kind == "doi":
        normalized = re.sub(r"^(https?://(dx\.)?doi\.org/|doi:\s*)", "", normalized)
    elif kind == "arxiv":
        normalized = re.sub(r"^(https?://arxiv\.org/(abs|pdf)/|arxiv:\s*)", "", normalized)
        normalized = normalized.removesuffix(".pdf")
    return normalized


def load_catalog(root: Path) -> list[dict[str, Any]]:
    path = root / "references" / "CATALOG.json"
    catalog = read_json(path)
    if not isinstance(catalog, dict) or catalog.get("schema_version") != SCHEMA_VERSION:
        raise CatalogError(f"{path}: invalid catalog schema; run tools/reference_metadata.py")
    records = catalog.get("records")
    if not isinstance(records, list) or any(not isinstance(item, dict) for item in records):
        raise CatalogError(f"{path}: records must be a list of objects")
    return records


def catalog_json(records: list[dict[str, Any]]) -> str:
    return json.dumps(
        {"schema_version": SCHEMA_VERSION, "records": records},
        ensure_ascii=False,
        indent=2,
        sort_keys=True,
    ) + "\n"


def markdown_escape(value: str) -> str:
    return value.replace("\\", "\\\\").replace("|", "\\|").replace("\n", " ")


def catalog_markdown(records: list[dict[str, Any]]) -> str:
    lines = [
        "# Local Reference Catalog",
        "",
        "Generated by `tools/reference_metadata.py`; do not edit by hand.",
        "",
    ]
    if not records:
        lines.extend(["No local reference records yet.", ""])
        return "\n".join(lines)

    for record in records:
        identity = record["bibliographic_identity"]
        authors = identity["authors"]
        author_label = authors[0] if len(authors) == 1 else f"{authors[0]} et al."
        year_label = str(identity["year"]) if identity["year"] is not None else "n.d."
        lines.append(f"## {markdown_escape(author_label)} ({year_label}) - {markdown_escape(identity['title'])}")
        lines.append("")
        lines.append(f"- Kind: `{record['kind']}`")
        lines.append(f"- Authors: {markdown_escape('; '.join(authors))}")
        identifiers = [f"{key}: {value}" for key, value in sorted(identity["identifiers"].items()) if value]
        if identifiers:
            lines.append(f"- Identifiers: {markdown_escape('; '.join(identifiers))}")
        if identity["keywords"]:
            lines.append(f"- Keywords: {markdown_escape('; '.join(identity['keywords']))}")
        if identity["abstract"]:
            lines.append(f"- Abstract: {markdown_escape(identity['abstract'])}")
        lines.append(f"- Record: `{record['record_path']}`")
        for asset in record["assets"]:
            source = f" (source: {asset['source']})" if asset.get("source") else ""
            lines.append(f"- {asset['role']}: `{asset['path']}`{source}")
        lines.append("")
    return "\n".join(lines)