"""Search the offline reference catalog and its explicitly listed TeX/text assets."""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any

from reference_common import CatalogError, load_catalog, normalize, normalize_identifier, safe_reference_path


WORKSPACE_ROOT = Path(__file__).resolve().parents[1]


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("query", nargs="*", help="free-text terms; all terms must match")
    parser.add_argument("--root", type=Path, default=WORKSPACE_ROOT,
                        help="workspace root (defaults to the repository root)")
    parser.add_argument("--author", help="author name or fragment")
    parser.add_argument("--title", help="title fragment")
    parser.add_argument("--year", help="year or inclusive range, for example 1920-1930")
    parser.add_argument("--keyword", help="keyword fragment")
    parser.add_argument("--id", dest="identifier", action="append", default=[],
                        help="arXiv id, DOI, or URL; may be repeated")
    parser.add_argument("--kind", choices=("local", "external"),
                        help="restrict to local items or external sources with local derivatives")
    parser.add_argument("--grep", metavar="TEXT",
                        help="case/accent/dash-insensitive literal search in listed TeX/text files only")
    parser.add_argument("--json", action="store_true", help="emit machine-readable JSON")
    parser.add_argument("-v", "--verbose", action="store_true", help="include abstracts and asset paths")
    return parser


def parse_year_filter(value: str | None) -> tuple[int, int] | None:
    if value is None:
        return None
    match = re.fullmatch(r"(\d{1,4})(?:-(\d{1,4}))?", value)
    if not match:
        raise CatalogError("--year expects YYYY or YYYY-YYYY")
    start = int(match.group(1))
    end = int(match.group(2) or start)
    if start > end:
        raise CatalogError("--year range must be ascending")
    return start, end


def record_text(record: dict[str, Any]) -> str:
    identity = record["bibliographic_identity"]
    identifier_text = " ".join(str(value) for value in identity["identifiers"].values() if value)
    return " ".join([
        identity["title"],
        " ".join(identity["authors"]),
        str(identity["year"] or ""),
        " ".join(identity["keywords"]),
        identity["abstract"] or "",
        identifier_text,
    ])


def matches_record(record: dict[str, Any], args: argparse.Namespace,
                   year_filter: tuple[int, int] | None) -> bool:
    identity = record["bibliographic_identity"]
    if args.kind and record["kind"] != args.kind:
        return False
    if args.author and normalize(args.author) not in normalize(" ".join(identity["authors"])):
        return False
    if args.title and normalize(args.title) not in normalize(identity["title"]):
        return False
    if args.keyword and normalize(args.keyword) not in normalize(" ".join(identity["keywords"])):
        return False
    if year_filter:
        year = identity["year"]
        if year is None or not year_filter[0] <= year <= year_filter[1]:
            return False
    if args.identifier:
        values = identity["identifiers"]
        normalized_values = {
            normalize_identifier(key, str(value))
            for key, value in values.items() if value
        }
        if not all(any(normalize_identifier(key, query) in value
                       for key in ("arxiv", "doi") for value in normalized_values)
                   for query in args.identifier):
            return False
    query_terms = [normalize(term) for term in args.query if normalize(term)]
    searchable = normalize(record_text(record))
    return all(term in searchable for term in query_terms)


def find_text_matches(root: Path, records: list[dict[str, Any]], pattern: str) -> list[dict[str, Any]]:
    normalized_pattern = normalize(pattern)
    if not normalized_pattern:
        raise CatalogError("--grep pattern must contain searchable characters")
    results = []
    for record in records:
        for asset in record["assets"]:
            if asset.get("role") not in {"tex", "text"}:
                continue
            path = safe_reference_path(root, asset.get("path"))
            relative_path = path.relative_to(root.resolve()).as_posix()
            try:
                lines = path.read_text(encoding="utf-8").splitlines()
            except (OSError, UnicodeError) as error:
                raise CatalogError(f"{relative_path}: cannot search UTF-8 text: {error}") from error
            for line_number, line in enumerate(lines, start=1):
                if normalized_pattern in normalize(line):
                    results.append({
                        "record_path": record["record_path"],
                        "title": record["bibliographic_identity"]["title"],
                        "path": relative_path,
                        "line": line_number,
                        "text": line.strip(),
                    })
    return results


def plain_record(record: dict[str, Any], verbose: bool) -> str:
    identity = record["bibliographic_identity"]
    authors = identity["authors"]
    author_label = authors[0] if len(authors) == 1 else f"{authors[0]} et al."
    year = str(identity["year"]) if identity["year"] is not None else "n.d."
    line = f"{author_label} ({year}) - {identity['title']} [{record['kind']}]"
    identifiers = [f"{key}: {value}" for key, value in sorted(identity["identifiers"].items()) if value]
    if identifiers:
        line += "\n  " + "; ".join(identifiers)
    if verbose:
        line += f"\n  Record: {record['record_path']}"
        if identity["abstract"]:
            line += f"\n  Abstract: {identity['abstract']}"
        for asset in record["assets"]:
            line += f"\n  {asset['role']}: {asset['path']}"
            if asset.get("source"):
                line += f" (source: {asset['source']})"
    return line


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    root = args.root.resolve()
    try:
        year_filter = parse_year_filter(args.year)
        records = load_catalog(root)
        selected = [record for record in records if matches_record(record, args, year_filter)]
        if args.grep is not None:
            results = find_text_matches(root, selected, args.grep)
            if args.json:
                print(json.dumps(results, ensure_ascii=False, indent=2))
            elif results:
                for result in results:
                    print(f"{result['title']} - {result['path']}:{result['line']}: {result['text']}")
            else:
                print("No matches.")
            return 0

        if args.json:
            print(json.dumps(selected, ensure_ascii=False, indent=2))
        elif selected:
            print("\n".join(plain_record(record, args.verbose) for record in selected))
        else:
            print("No matches.")
        return 0
    except (CatalogError, OSError) as error:
        print(error, file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())