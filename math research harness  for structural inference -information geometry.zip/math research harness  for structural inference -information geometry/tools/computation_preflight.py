"""Check that the configured symbolic and numerical backends are usable."""

from __future__ import annotations

import platform
import sys


def main() -> int:
    try:
        import numpy as np
        import scipy
        import sympy as sp
        from scipy.integrate import quad
    except ImportError as error:
        print(f"FAIL backend import: {error}", file=sys.stderr)
        return 1

    print(f"Python {platform.python_version()}")
    print(f"SymPy {sp.__version__}")
    print(f"NumPy {np.__version__}")
    print(f"SciPy {scipy.__version__}")

    symbol = sp.symbols("symbol")
    if sp.diff(symbol**3, symbol) != 3 * symbol**2:
        print("FAIL SymPy exact differentiation", file=sys.stderr)
        return 1
    print("PASS SymPy exact differentiation")

    matrix = np.array([[3.0, 1.0], [1.0, 2.0]])
    solution = np.linalg.solve(matrix, np.array([9.0, 8.0]))
    if not np.allclose(solution, [2.0, 3.0]):
        print("FAIL NumPy linear solve", file=sys.stderr)
        return 1
    print("PASS NumPy linear solve")

    integral, estimated_error = quad(lambda value: value**2, 0.0, 1.0)
    if abs(integral - 1.0 / 3.0) > max(1e-12, 10.0 * estimated_error):
        print("FAIL SciPy adaptive quadrature", file=sys.stderr)
        return 1
    print("PASS SciPy adaptive quadrature")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())