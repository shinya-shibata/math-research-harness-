# Math Research Harness の使い方

この harness は、AI agent と研究を進めながら、問いの範囲、根拠、計算条件、未解決点を後から確認できる形で残すための workspace です。通常はチャットで研究協力者に話すように依頼してください。モード名を指定したり、毎回テンプレートを埋めたり、台帳や Git を自分で管理したりする必要はありません。
agent は `AGENTS.md` を作業契約として読み、数学的な依頼では `STEERING.md` と対象 thread の `LEDGER.md` から始めます。必要な note や文献だけを追加で読みます。会話で許可された範囲が作業の境界です。

## 1. 最初の準備

workspace の Python 依存関係を用意し、数理計算バックエンドとテストを確認します。repository root で実行します。

```powershell
uv sync
uv run python tools/computation_preflight.py
uv run python -m unittest discover -s tests
uv run python -m unittest discover -s .github/prompts -p 'test_hypothesis_batch.py'
このプロジェクトでは SymPy を記号計算、NumPy を配列・線形代数、SciPy を数値積分などに使います。VS Code では workspace の `.venv` を Python interpreter に選びます。preflight は基本演算が動くことを確認するもので、研究結果の数学的正しさを証明するものではありません。

通常の作業依頼の前にコマンドを毎回実行する必要はありません。環境を新しくしたとき、依存を変更したとき、または計算が import error で止まったときに実行します。
## 2. 研究を始める依頼の書き方

依頼は自然文で構いません。よい依頼には、対象 thread、知りたい問い、調べる深さ、除外事項、望む成果物が含まれます。

```text
fraser_structural_geometry の現状を台帳から要約し、未解決項目を優先度ではなく種類別に整理してください。まだ計算や台帳更新はしないでください。
具体的な作業に進むときは、対象を狭めます。

```text
「構造の可積分性と非零法束曲率が両立する例」の問いについて、必要な定義と仮定を整理し、候補を考える前に必須の外部文献調査を行ってください。候補ごとに指定された全9探索先で先行研究と反例を調べ、検索範囲を記録してください。論文編集はしないでください。
依頼で範囲が不明なら、agent は仮定を明示するか確認を求めます。広い依頼を受けても、無断で新しい thread、研究プログラム、全解決キャンペーンを開始してはいけません。

## 3. 作業の深さを指定する

- **限定タスク**: 指定した成果物、説明、実装、確認だけを行う。例:「この計算式の添字と符号規約を確認してください」
- **方向づけた調査**: 一つの問いを掘り下げ、結果、具体的な障害、有望な別経路、または見込みが薄くなった理由を返す。例:「この仮定を外した場合の反例を探してください」
- **完全解決キャンペーン**: 特定の定理・予想を対象範囲全体で解決する作業。開始前に対象と完了条件を合意します。有限例や部分計算だけで完了とはしません。
- **理論開発プログラム**: 定められた領域で継続的な自律研究を行う許可です。独立したプログラムや新しい durable thread は、明示的な承認なしに作りません。
迷ったときは「まず bounded task で診断だけ」「この問いを directed investigation として調べて」のように会話で伝えれば十分です。

## 4. 仮説候補を大量生成する

VS Code Chat で `/generate-hypothesis-candidates` を選び、thread、種となる台帳項目、候補数、変形パターン、除外条件を入力します。たとえば:

```text
/generate-hypothesis-candidates thread=fraser_structural_geometry seeds="構造の可積分性と法束曲率の両立" count=30 transformations="new_construction,counterexample_or_obstruction,special_case" exclusions="論文編集はしない"
入力が空欄なら prompt の既定値が使われます。thread が曖昧なら agent に確認させてください。候補生成は最大50件を一バッチとし、必要な場合は複数回に分けます。まず研究課題から独立に9つの必須探索先で広域検索し、その後、関連するローカル文書の参考文献（`tem.md` を含む）も補助的な探索元として使います。各候補についても同じ全探索先を再検索し、どのローカル文献から検索語を得たか記録します。ローカル参考文献だけに依存してはいけません。検索できない探索先がある場合は完了扱いにせず、候補生成前なら停止、候補別検索後なら `incomplete` として未完了範囲を報告します。検索で一致が見つからないことは新規性の証明ではありません。

候補ファイルと manifest は次の同じ session directory に保存します。

```text
research-scratch/<thread>/<session>/
  candidates.jsonl
  batch-manifest.md
```

`candidates.jsonl` は1行1候補です。`work_status` は生成・選別の作業状態、`evidence_status` は数学的証拠の状態です。新規生成候補は `work_status: generated`、`evidence_status: null` から始まります。生成バッチは Git 管理外の scratch であり、ledger や論文を自動更新しません。

バッチを検査するには、保存先を指定して実行します。

```powershell
uv run python .github/prompts/hypothesis_batch.py research-scratch/fraser_structural_geometry/20260927-first-batch
```

機械可読な報告が必要なときは `--json` を追加します。

```powershell
uv run python .github/prompts/hypothesis_batch.py research-scratch/fraser_structural_geometry/20260927-first-batch --json
```

この validator は JSON Schema、必須9探索先の候補ごとの検索記録、ID 重複、参照ファイルの有無と workspace 内のパス、完全一致候補、変形別件数を検査します。検索が実際に十分だったか、候補の意味的同値性・数学的正しさ・新規性は判定しません。完全重複も削除せず警告します。

## 5. 候補を詳査する

候補一覧から ID を指定して次の作業を依頼します。

```text
candidate-004 と candidate-011 を比較してください。仮定の差、予測、最初の反証テストを整理し、どちらを詳査する価値があるか理由つきで提案してください。候補状態や台帳はまだ変更しないでください。
```

検討対象を選んだ後、`.github/prompts/HYPOTHESIS-CARD.md` を使って正確な主張、定義、仮定、予測、証明義務、反証テスト、文献・計算の根拠を整理できます。必要に応じ、次のように検証範囲も明示して依頼します。

```text
candidate-004 を詳査してください。まず failure_condition を満たす最小例を記号計算で探し、その検査範囲と前提を報告してください。一般証明として扱わず、ledger と論文は編集しないでください。
```

候補と矛盾する事実が見つかっても、すぐ消すのではなく、反例なのか、規約・仮定の違いなのかを確認します。有限範囲で反例が見つからないことは一般的な成立証明ではありません。

## 6. 文献を調べる

仮説・新理論の生成では、まず研究課題からarXiv、SpringerLink、SIAMを独立検索し、用語と既知結果を押さえます。その後、関連ローカル文献を補助検索し、調査結果を整理してからLLMで候補を広げます。LLMの記憶から出た文献名や主張は検索手掛かりであり、証拠として扱いません。生成した各候補は3サイトで個別に照合します。ローカル検索の例:

```powershell
uv run python tools/reference_lookup.py Fraser ancillary
uv run python tools/reference_lookup.py --author Fraser --year 1990-2026
uv run python tools/reference_lookup.py --grep "normal connection"
```

カタログは「手元にある資料」の索引で、主張を検証済みという印ではありません。`proved/literature` とするには、資料の版を特定し、主張・仮定・範囲・規約を一致させ、確認可能な locator を残します。検索で一致が見つからないことは新規性の証明ではありません。

依頼例:

```text
この候補の exact claim を既存文献と照合してください。最初にローカルカタログを検索し、関連する一次資料、版、定理の仮定と locator を報告してください。新規性は断定しないでください。
```

文献の原本は変更しません。PDF・DjVu の抽出や OCR が本当に必要な場合は、repository の準備・抽出手順を使い、既存の derived text を先に確認します。

## 7. 計算・数値検証を行う

最初は `.research-scratch/<thread>/<session>/` に短い disposable probe を置きます。探索コードと数学的エンジンの責任を分け、計算前に対象・規約・精度・有限範囲を決めます。

結果が後の研究判断に使われる段階になったら、少なくとも次を残します。

- 正確な問いと計算範囲、定義、規約
- 実行したコマンド、プログラム、backend とバージョン
- 算術領域・精度・seed などの再現条件
- 出力または certificate と、それを確認する verifier
- 何が支持・反証され、何が未解決のままか

雛形は `templates/COMPUTATION-SUMMARY.md` です。`data/<thread>/` の機械可読出力はローカル専用で Git に追加せず、追跡対象の `results/<thread>/` 側に再生成方法・範囲・出力場所を記録します。探索候補の一例や Monte Carlo は、その設定内の結果であって一般証明ではありません。

## 8. 作業結果を記録する

- 途中の考察・使い捨てコード: `.research-scratch/<thread>/<session>/`
- 仮説候補 batch: `research-scratch/<thread>/<session>/`
- 一度限りで再実行可能な実験プログラム: `experiments/<thread>/`
- 繰り返し使う保守対象コード: `lib/`。安定した interface とテストを付ける
- coherent な証明、反例、計算、重要訂正、永続的障害: `threads/<thread>/notes/`
- 現在の結果と未解決事項: `threads/<thread>/LEDGER.md`

note を作るだけで LEDGER が自動更新されるとは限りません。canonical state を更新する必要がある成果では、note と影響を受ける ledger を同じ checkpoint で一緒に整えます。既存 claim の文言や status は、実際に確立した証拠に合わせます。

## 9. 証拠状態を読む

- `proved/owner-checked`: owner がその正確な証明を確認した
- `proved/literature`: 前提・範囲・規約まで照合した文献証明
- `proved/agent`: agent の証明。owner の確認前
- `verified-computationally`: 記載した有限または数値的範囲で検証
- `unverified`: 継承・報告されたが証明済み根拠をまだ確認できない主張。新規予想のラベルには使わない
- `open`: 明確な形にされた未解決問題または候補
- `refuted`: 指定範囲の主張が反例などで否定された
- `disputed`: 前提・規約・論証などに争点がある
- `parked`: 所有者の判断や外部依存で停止中

「計算した」「有望」「進展した」と「証明した」「owner が確認した」は別です。

## 10. Owner の判断を agent に伝える

- **“Go for it.”**: 直前に提案された攻撃を開始する
- **“Pivot.” /「別方向へ切り替えて」**: 失敗の証拠を保持したうえで、仕組みの異なる方針を検討する
- **“Record this as progress.” /「進捗として記録して」**: 重要度を認める。正しさや証明状態を自動で昇格させる指示ではない
- **“I checked this proof.” /「この証明を確認しました」**: 対象の正確な証明を指定して、`proved/owner-checked` にできるか確認する
- **“Put this in the paper.” /「これを論文に入れて」**: 論文編集を明示的に許可する。通常の記録・報告だけでは論文を編集しない

持続的な campaign、新しい理論開発プログラム、新規の durable thread も明示的な承認が必要です。所有者だけが長期方針・優先度・park/resume と owner-checked を決めます。

## 11. ハーネス改善を調査する

他の AI agent harness と比較し、この harness への改善案を作る調査はオーナーが明示的に依頼した場合だけ実行します。VS Code Chat で `/review-agent-harness` を選ぶか、同等の明示依頼をしてください。通常の会話で harness に触れただけでは起動しません。

```text
/review-agent-harness scope="数学研究用harness全体" focus="権限管理、コンテキスト、文献調査、検証、安全性" exclusions="実装・既存指示の変更はしない"
```

調査は [`AIエージェントのハーネス調査サイト一覧.md`](../AIエージェントのハーネス調査サイト一覧.md) を候補発見に使い、公式文書・実装・一次研究や独立評価で重要な主張を確認します。[`AI Agent Harness Research.md`](../AI%20Agent%20Harness%20Research.md) は未検証の二次資料として扱い、根拠そのものとはみなしません。外部検索が使えない場合はその事実を報告し、完了した比較のように装いません。

結果は `harness-improvement-proposals/YYYY-MM-DD-<slug>.md` に別ファイルとして保存します。提案書は助言であり、`AGENTS.md`、コード、テスト、台帳、論文を自動変更しません。提案の実装・採用には、別途オーナーの明示指示が必要です。

## 12. ハーネス研究メモの鮮度を確認する

`AI Agent Harness Research.md` は時期の異なる製品・ベンチマーク主張を含む二次資料です。主張ごとの確認状態は `harness-improvement-proposals/research-evidence-register.json` に記録します。初期レジストリは部分インベントリなので、未登録の本文主張が残っている間はメモ全体の鮮度確認を完了扱いにできません。

期限または特定主張の確認は、オーナーが明示的に依頼します。

```text
/review-agent-harness mode=freshness claim_ids="HR-004,HR-008" focus="出典の新版、ベンチマーク条件、主張の差分"
```

`mode=freshness` は出典を再確認して日付付き差分レポートを作るだけです。レビュー間隔は再確認の優先度であり、期限切れだけで主張が誤りになるわけではありません。新しい版・評価条件・矛盾の発見は、間隔に関係なく再確認のきっかけです。外部検索が使えない場合やインベントリが不完全な場合は、その範囲をレポートに残します。元メモとレジストリはこの段階では変更しません。

差分を確認し、適用を決めた場合だけ、別の明示指示でレポートと claim ID を指定します。

```text
/review-agent-harness mode=apply report="harness-improvement-proposals/YYYY-MM-DD-harness-freshness.md" claim_ids="HR-004,HR-008"
```

適用時は指定された主張だけを更新し、旧状態・新版・根拠をレジストリの `change_history` に追記します。`blocked` レポートや指定されていない変更は適用しません。自動巡回・自動書き換えは行いません。

## そのまま使える依頼例

```text
catch up: この thread の LEDGER と必要な note を読み、現状、確かなこと、open なことを分けて説明してください。
```

```text
調査してください: claim の正確な仮定を明示し、最小の反例テストを行ってください。数値結果は検査範囲内の証拠としてだけ報告してください。
```

```text
文献確認だけしてください: ローカルカタログから始め、一次資料と exact locator を示してください。台帳や論文は編集しないでください。
```

```text
この結果を note と ledger に記録してください。証拠状態は今回実際に確認できた強さを超えないようにしてください。
```

```text
この内容を論文に入れてください。主張と対応する根拠を明示し、現在の paper workflow に従ってください。
```
# Working with the research harness

Talk to the agent as you would to a research collaborator. You do not need to
name a mode, fill in a template, manage notes, edit ledgers, or make commits.
The agent infers scope from ordinary language and handles repository mechanics.

## Adapting the template

The included contract, sample thread, workflow documents, and environment notes
are starting points. Describe how you prefer to work, discuss changes with the
agent, or simply work normally and correct mismatches as they appear. The agent
can revise the repository to fit your terminology, policies, tools, execution
environment, and working habits. You do not need to translate those preferences
into configuration files yourself.

## Common interactions

> Catch up on the sample inquiry and tell me what you want to do.

The agent reads the relevant canonical state, proposes a substantive direction,
and waits before beginning a sustained attack.

> That seems worthwhile. Go for it.

The agent begins the proposed investigation and persists beyond the first
superficial failure.

> This route is too narrow. Discuss a pivot.

The agent preserves any durable result, identifies what failed, and proposes a
materially different mechanism.

> Record this as progress.

The agent treats the package as owner-significant and updates canonical state
when appropriate. This does not mean the owner checked its correctness.

> I checked this proof.

The exact checked claim may become `proved/owner-checked`. General praise does
not carry that meaning.

> Put this in the paper.

The agent may edit and compile the live paper. Recording progress, preparing a
research note, or writing a standalone report does not independently authorize
paper editing. Once authorized, the agent works to the portable exposition standard carried
by the paper-writing skill (see [`SKILLS.md`](SKILLS.md)), together with this
repository's conventions in [`PAPER-WRITING.md`](PAPER-WRITING.md) and any
style memo in the paper's thread.

## What the records mean

- The project foundations file is an optional shared reference for conventions
  and scope or transport guards that recur across substantively different
  threads. The relevant ledger, rather than that file, is the normal
  mathematical entry point.
- Scratch holds disposable reasoning and probes.
- A note preserves one coherent durable package.
- A ledger describes the present research picture in one sitting.
- A claim catalog stores only the strongest current non-subsumed reusable
  statements and their provenance; notes and Git preserve superseded history.
- Active state organizes interacting live routes without becoming evidence.
- Git preserves the evolution between coherent checkpoints.

Correctness and significance remain separate. The owner controls durable
direction and owner-checking; the agent keeps factual state current at the
evidence level actually established.

## Four scopes of work

- A bounded task produces a requested artifact or service without creating a
  broader agenda.
- A directed investigation seriously explores one question or mechanism and
  returns with a result, precise obstruction, useful pivot, or honest
  diminishing-return judgment.
- A full-resolution campaign targets one exact theorem or conjecture. It begins
  after approval of a short target-and-scope contract. Narrow cases and bounded
  computations are progress, not completion.
- A theory-development program grants standing autonomy in an approved
  mathematical territory. It may generate useful definitions, theorems,
  conjectures, examples, and focused subcampaigns.

See [`RESEARCH-MODES.md`](RESEARCH-MODES.md) for the authority boundaries.

## Literature

Source discovery is normally part of an authorized research task. The agent
checks the local catalog first, searches suitable public sources, controls the
version used, and distinguishes finding a related statement from verifying the
exact claim needed.

A claim becomes `proved/literature` only after its statement, assumptions,
scope, and conventions match an identified source. Local possession of a source
does not imply that you knew or endorsed it. See
[`LITERATURE.md`](LITERATURE.md) for the complete workflow.

## Computation and collaboration

When computation becomes durable, the agent records its exact scope, command,
versions, conventions, machine-readable output, and human-readable
interpretation. Machine-readable output under `data/` stays on local disk and
is never committed, so the tracked summary in `results/` carries the manifest
needed to regenerate and interpret it. See
[`COMPUTATIONS.md`](COMPUTATIONS.md).

A lead agent may optionally delegate independent tasks to internal subagents and
remains responsible for auditing and synthesis. The `briefings/` interface
supports collaborators without repository access. Neither mechanism enlarges
the research scope you authorized. See
[`COLLABORATION.md`](COLLABORATION.md).
