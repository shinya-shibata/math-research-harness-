# Thread: <name>

Status: active | dormant | parked | closed
Active mode: bounded task | directed investigation | full-resolution campaign | theory-development program | none
Last updated: <OS-derived timestamp> by <agent>
Claim catalog: inline | CLAIMS.md
Active state: none | ACTIVE.md

## Owner direction

Current durable targets, priorities, exclusions, and park/resume decisions.

## Conventions

Only conventions needed to interpret current state.

## Current theory map

Established boundary, organizing mechanism, and central obstruction.

## Durable claims

An inline table or a short pointer to `CLAIMS.md`.

## Current opportunities

Open directions with present leverage. This is not a task queue.

## Corrections and durable obstructions

Optional. Keep only material whose omission would misrepresent current state or
invite substantial repeated error.
