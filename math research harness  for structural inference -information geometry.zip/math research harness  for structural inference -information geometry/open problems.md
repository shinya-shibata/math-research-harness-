# FM-14: 未解決問題

対象候補: `research-scratch/fraser_structural_geometry/20260930-231402/` の FM-14  
基礎記録: `research-scratch/fraser_structural_geometry/20261004-2133-fm14-audit.md`

## 現在確認できていること

滑らかな正の密度族 `p_beta` と速度場 `v_a` が

`partial_a p_beta + div(p_beta v_a) = 0`

を満たすなら、`div(p_beta w_a) = 0` を満たす場 `w_a` を `v_a` に加えても、誘導されるスコア表示は変わらない。平坦な二次元トーラスでは、任意の滑らかな正の周期密度 `p(x,y)` に対し

`w(x,y) = (0, cos(x) / p(x,y))`

が非零の滑らかな例となる。この条件付きのスコア輸送の自由度は確認済みだが、exact ancillary の存在・一意性や Fraser/TEM の一般的結論は確立していない。

## 未解決問題

1. **大域的輸送の非一意性 — 存在例は確認済み**  
   平坦な二次元トーラス上で、同一の滑らかな正の非一様密度族を共通の初期分布から運ぶ、相異なる二つの滑らかな大域流を構成した。各速度場はそれぞれ一意な完備流を持つが、速度場を変えると周辺密度族を保ったまま流れが変わる。証明と具体式は `research-scratch/fraser_structural_geometry/20261004-fm14-global-flows.md` を参照。一般の領域・境界条件・正則性での分類や、境界フラックスの扱いは未解決。

2. **許容ゲージ場の分類**  
   `div(p_beta w_a) = 0` の解全体を、領域・境界条件・位相に応じてどう記述できるか。トーラス上の例は非零解の存在を示すだけであり、大域的周期や境界を横切るフラックスの分類は未解決である。

3. **exact ancillary との関係 — reduced conditional procedure の選択依存性を確認**  
   スコア輸送の非一意性そのものから exact ancillary の存在・一意性は導けない。滑らかな logistic location 標本で、差 `D` とその粗視化 `1{D>0}` はともに exact ancillary である。選んだ統計量を `T=(X1+X2)/2` に固定して各 ancillary で異なる条件付き実験へ縮約すると、`T` の条件付き分布と局所スカラー `r*` 展開が異なる。独立 nuisance を加えてもこの差は残る。詳細は `research-scratch/fraser_structural_geometry/20261004-fm14-ancillary-nuisance.md`。ただし全データを保持する場合、exact ancillary で条件付けても likelihood はパラメータ非依存の正規化因子を除き変わらない。この結果は全データ尤度の変化ではなく、条件付け sigma-field と reduced conditional calibration の選択依存性である。一般の同値条件は未解決。

4. **Fraser/TEM 構造モデルでの具体的帰結 — 固定 ancillary での比較を完了**  
   一つのトーラス上の滑らかな密度族に対し、共通の固定誤差分布から全く同じ標本分布を誘導する2つの滑らかな structural map を構成した。一方の構造曲線は exact ancillary `Y` の等位線に沿うが、他方には非定数の滑らかな共通不変量がない。詳細は `research-scratch/fraser_structural_geometry/20261004-fm14-structural-representations.md` を参照。

   固定 ancillary と同じ条件付き実験を保つ限り、二つの構造表現で exact conditional likelihood は同一であり、正しく同じ条件付き標本空間上に計算した局所スカラー `r*` も一致する。`F_beta^(2)` の全速度をそのまま使うのは不適切。詳細は `research-scratch/fraser_structural_geometry/20261004-fm14-conditional-rstar.md`。

   一方、異なる ancillary を用いて異なる縮約条件付き実験を作ると、nuisance parameter `eta` を独立に持つ積モデルでも interest parameter の条件付き `r*` が変わりうる。全データ likelihood が ancillary 条件付けだけで変わるとは主張しない。詳細は `research-scratch/fraser_structural_geometry/20261004-fm14-ancillary-nuisance.md`。nuisance は直交・独立な積成分のみであり、結合 nuisance の一般的な nuisance 調整付き `r*` と、固定条件付き実験に対する構造表現変更の不変性は未解決。法束幾何との関係も別途定義・導出が必要。

5. **文献確認の完了**  
   arXiv では関連用語の検索結果を確認したが、一次資料を使った網羅的な比較・引用追跡は未完了。SpringerLink は HTTP 406、SIAM は HTTP 403 で検索できなかった。両サイトの検索が可能になった時点で候補固有の検索と関連文献の確認を再開する。現時点で新規性は主張しない。

## 次の識別的な一手

次の識別的な一手は、パラメータ間で結合した nuisance を含むモデルを選び、同一の固定 ancillary・同一条件付き実験において2つの構造表現から得る全 nuisance-adjusted `r*` 項を比較すること。別 ancillary 選択に関しては、条件付き実験が同値となる十分条件を調べる。数値的近似精度、一般定理、境界付き領域・非コンパクト空間のフラックス条件は未確立。

## 証拠状態

- 条件付きスコア輸送恒等式とトーラス上の明示例: `proved/agent`
- トーラス上の異なる大域輸送流の存在: `proved/agent`
- 同じモデルを誘導する異なる構造写像と構造曲線の非同値例: `proved/agent`
- 固定 exact ancillary `Y` での条件付き尤度と局所スカラー `r*` の表現不変性: `proved/agent`
- ancillary の粗視化に伴う reduced conditional distribution と局所 scalar `r*` の変化、および独立 nuisance 拡張: `proved/agent`
- 独立 nuisance を持つ積モデルで上記 ancillary-choice 差が残ること: `proved/agent`
- 一般領域での分類、ancillary との橋渡し、Fraser/TEM への含意: `open`
- 結合 nuisance での一般 nuisance-adjusted `r*` 表現不変性、条件付き実験の同値条件、近似精度の数値検証: `open`
- 文献レビュー: `incomplete`
