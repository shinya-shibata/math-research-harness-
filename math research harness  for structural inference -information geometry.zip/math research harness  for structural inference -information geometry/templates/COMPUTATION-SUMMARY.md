# Computation: <descriptive name>

Date: <OS-derived timestamp>
Agent: <agent>
Status: exploratory | verified-computationally

## Question and scope

State exactly what was computed and the finite boundary of the result.

## Conventions and encoding

Define the mathematical objects, input format, handedness, indexing, and any
normalization needed to interpret the output.

## Implementation

- Program or configuration:
- Backend and version:
- Relevant dependency versions:
- Exact command from repository root:
- Seed or nondeterminism information:

## Output

- Machine-readable artifact:
- Certificate or verifier:
- Expected hash when useful, or decisive invariants:

## Result

Summarize what was verified, refuted, or left unresolved. Do not extrapolate
beyond the recorded scope.

## Canonical implications

Include only when the computation changes durable claims or the present theory
map.
