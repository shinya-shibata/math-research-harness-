Date: <OS-derived local timestamp>
Agent: <agent>
Type: literature search

# Literature search record: <research question or search pass>

## Search purpose

- Research question or exact claim:
- Search pass: question-driven / local-reference follow-up / candidate-specific
- Search source:
- Search date and time, including timezone:
- Exact query:
- Query fields:
- Filters and sort order:
- Search URL:

## Result coverage

- Displayed result count:
- Page size:
- Pages exposed:
- Pages inspected:
- Results inspected:
- Coverage status: results visible / partially inspected / all displayed results inspected / inaccessible
- Access or interface notes:

"All displayed results inspected" describes only the result set returned by
this query. It does not imply that the publisher corpus or scholarly literature
is exhausted. Opening a URL alone is not an inspected result.

## Results

| # | Title | Authors | Year | Journal/book | DOI or stable URL | Triage / next action |
|---|---|---|---:|---|---|---|
| 1 | | | | | | |

## Limits and next step

- What was not inspected or verified:
- Query refinement or follow-up:
- Related source-check records: