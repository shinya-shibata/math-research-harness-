Date: <OS-derived ISO timestamp>
Agent: <agent>
Type: literature

# Source check: <claim or source>

## Research claim to be supported

State the exact claim, assumptions, conventions, and required scope before
summarizing the source.

## Bibliographic identity

- Authors:
- Title:
- Publication or repository:
- Year:
- Exact version:
- Persistent identifier:

## Checkable locator

Prefer a stable TeX line range when available. Otherwise cite a theorem,
proposition, section, or page already present in a reusable derivative, or a
stable local text location. Do not inspect a PDF solely to add rendered
numbering.

## Match audit

- Exact statement:
- Assumptions:
- Conventions:
- Scope:
- Required dependencies:
- Visual verification needed or performed:

## Verdict

Choose and justify one: exact match; narrower result; related only; conflicting;
or unresolved.

## Canonical implications

Include only when this check changes a claim status, current theory map, durable
obstruction, or current opportunity.
