# Active state: <thread>

Mode: full-resolution campaign | theory-development program
Target: <exact current target>
Last updated: <OS-derived timestamp> by <agent>

## Current research position

State the exact live boundary without reproducing the ledger.

## Route registry

| Route | Present leverage | Exact obstruction | Status | Evidence |
|---|---|---|---|---|

## Active discriminators

Record concrete tests or lemmas that would distinguish the live possibilities.

## Route-specific cautions

Include only cautions relevant to this run.
