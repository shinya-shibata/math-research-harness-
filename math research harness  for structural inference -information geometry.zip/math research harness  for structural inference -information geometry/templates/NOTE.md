Date: <OS-derived ISO timestamp>
Agent: <agent>
Type: proof | literature | refutation | computation | correction | theory | handoff

# <Coherent package title>

## Scope

Exact question, conventions, and limits of this package.

## Result

State what was proved, computed, refuted, corrected, or left open.

## Evidence

Give the argument, certificate, reproducible command, or precise obstruction.

## Canonical implications

Include this section only when canonical state should change. State the change;
do not turn it into an owner bookkeeping request.
