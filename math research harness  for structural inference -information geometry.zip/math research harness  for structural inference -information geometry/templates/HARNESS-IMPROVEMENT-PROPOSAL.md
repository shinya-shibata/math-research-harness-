# Agent Harness Improvement Review: <scope>

- Review date: <OS-derived date>
- Authorization: Explicit owner request
- Status: `proposal; not adopted` | `blocked`
- Scope:
- Exclusions:
- Report slug:

## Summary

State the principal verified findings, proposed changes, and material blockers. Do not present proposals as owner decisions.

## Current Harness Baseline

Describe only behavior verified in the current workspace. Cite workspace-relative paths and distinguish implementation from documented intent.

| Dimension | Current behavior | Evidence path(s) | Limitation or uncertainty |
|---|---|---|---|
| Owner authority and scope | | | |
| Context and state | | | |
| Tools, execution, and recovery | | | |
| Validation and feedback | | | |
| Evidence and provenance | | | |
| Security and isolation | | | |
| Reproducibility and cost | | | |

## Method and Coverage

- Research question and search terms:
- Date range and retrieval date:
- Harness/site-list entries inspected, with status (`inspected`, `inaccessible`, `stale`, or `not relevant`):
- Inclusion and exclusion criteria:
- Comparison constraints and benchmark comparability:

## Source and Evidence Register

| Source | URL | Type | Version/date | Claim checked | Evidence status and locator | Limitations |
|---|---|---|---|---|---|---|

Use source types such as first-party documentation, source implementation, primary research, independent benchmark, curated directory, or vendor/author commentary. Label unverified claims explicitly.

## Comparative Findings

| Dimension | External practice and source | Current-harness counterpart | Transferability | Caveat or counterevidence |
|---|---|---|---|---|

## Improvement Proposals

### H-01: <short title>

- Current-harness observation:
- External evidence:
- Proposed change:
- Why it transfers to this harness:
- Expected benefit:
- Costs, risks, and what not to copy:
- Reversible trial:
- Acceptance criteria and verification:
- Owner decision: `pending`

<!-- Duplicate the H-01 section for each proposal. -->

## Rejected or Deferred Ideas

Record attractive ideas not recommended, with reasons such as weak evidence, poor domain fit, high complexity, or unsafe authority expansion.

## Gaps and Blockers

- Inaccessible or stale sources:
- Claims not independently verified:
- Missing benchmark conditions:
- Questions requiring owner direction:

## Decision Boundary

This document is advisory. No proposed change has been implemented or adopted. Implementation requires a separate explicit owner instruction.