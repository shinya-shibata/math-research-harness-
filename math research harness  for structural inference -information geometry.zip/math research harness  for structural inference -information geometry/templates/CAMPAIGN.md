# Campaign: <short name>

Status: proposed | approved | resolved | handed off

## Exact target

State the target and conventions without prescribing a proof route.

## Scope and exclusions

State permitted territory, owner exclusions, and resource limits.

## Resolution standard

State what counts as proof or certified refutation.

## Return conditions

State which owner dependencies or genuine obstructions require a handoff.
