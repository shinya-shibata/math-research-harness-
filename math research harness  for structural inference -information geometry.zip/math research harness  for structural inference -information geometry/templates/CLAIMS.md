# Durable claims: <thread>

<!--
This file is a compact present-facing prerequisite catalog. Keep only the
strongest current non-subsumed reusable claims. Each entry contains only its
current identifier/title, status, exact statement, evidence links, and
dependencies. Identifiers are catalog coordinates rather than archival keys
and are renumbered after curation; notes and Git preserve superseded history.
Make the assertion unambiguous, but put every proof sketch, computation detail,
census, witness, verification narrative, and route history in the linked note
or result.
-->

### 1. <Short title>

Status: <evidence status>

Statement: <Exact assertion, including only the assumptions, conventions, and
scope needed to identify it unambiguously.>

Evidence:

- `<note filename>`

Dependencies: none | `<thread>:<claim-id>`
