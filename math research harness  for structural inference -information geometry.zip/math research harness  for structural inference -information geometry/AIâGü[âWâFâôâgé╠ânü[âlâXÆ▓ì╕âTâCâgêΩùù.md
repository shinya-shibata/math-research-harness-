# **AIエージェントのハーネス調査サイト一覧**

[https://gemini.google.com/app/eace381665608ad6](https://gemini.google.com/app/eace381665608ad6)

*User prompt: 最新の優れたAI agentのharness を全て調べることができるサイトを教えて*

Response: 最新のAI Agent Harness（ハーネス：エージェントの実行ループ、コンテキスト管理、ツール連携、実行環境の枠組み）を網羅的に調べたり、比較・追跡したりできる主要なサイトやリポジトリを紹介します。

### **1\. 総合ディレクトリ・データベースサイト**

> * **SkillsLLM \- Best of Agent Harnesses**  
  * **概要:** 100以上のAI Agent Harnessをスコア化・ランキング形式で一覧化しているキュレーションサイト。週単位で更新されており、オープンソースの主要ハーネスやMCP（Model Context Protocol）対応ツールが網羅されています。  
  * **特徴:** カテゴリ別・プログラミング言語別（TypeScript, Python, Rust等）に整理されており、JSONやllms.txt形式でのエクスポートにも対応。  
> * **Daily.dev \- The Agentic AI Hub (Agent Harnesses & Frameworks)**  
  * **概要:** 「実行型ハーネス（Harnesses you drive）」と「構築用フレームワーク（Build frameworks）」に分類して解説・比較しているポータルサイト。  
  * **特徴:** Claude Code, OpenCode, Goose, OpenHands などの主要ハーネスの用途別比較（GUI, CLI, クロスプラットフォーム対応など）を一覧で確認できます。

### **2\. ベンチマーク・性能・コスト比較サイト**

> * **Composio \- Best AI Agent Harnesses Benchmark**  
  * **概要:** 主要なハーネス（Claude Code, OpenCode, Kimi Code, Hermes Agent, Oh My Pi, Grok Build など）に対し、同一のタスク・ツールセット・採点基準を与えて実行精度やコスト、処理速度を測定したベンチマークレポートサイト。  
  * **特徴:** タスク成功率（Pass rate）、タスクあたりの平均コスト（Cost per success）、ツール呼び出し回数（Tool calls）など、実運用における定量データがまとめられています。  
> * **Winder.AI \- Comparison of AI Agent Harnesses**  
  * **概要:** 各種ハーネスのアーキテクチャ、ライセンス、強み・弱み、オープンウェイトモデルへの対応状況などを技術者視点で掘り下げて比較している分析サイト。

### **3\. オープンソース（GitHub）キュレーションリポジトリ**

> * **GitHub \- Picrew/awesome-agent-harness**  
  * **概要:** AI Agent Harnessの設計アーキテクチャ、オーケストレーションツール、CLIコントロールプレーン、マルチエージェント基盤のリソースを集約したAwesomeリスト。  
  * **特徴:** LangGraph, CrewAI, AutoGen などのオーケストレーションフレームワークから、DeerFlow, Claude Code Router, Ruflo などの最新ハーネスプロジェクトまで幅広くリンクされています。

### **💡 調査時のポイント**

ハーネスを調査する際は、用途に応じて以下の**2つのカテゴリ**を分けるのがスムーズです。

> 1. **実行環境・CLIハーネス（Ready-to-use Harnesses）**  
   * モデルに対して直接指示を出し、ツール呼び出しやファイル操作、サンドボックス実行を管理する完成されたループ環境。  
   * *例: Claude Code, OpenCode, OpenHands, Goose, Aider*  
> 2. **構築用フレームワーク（Build Frameworks / Runtimes）**  
   * 独自のハーネスやカスタムエージェントのロジック、グラフ構造、メモリ、ツール接続をコードで組むためのライブラリ。  
   * *例: LangGraph, CrewAI, AutoGen, Pydantic AI*

**Sources**

> 1. [best-of-Agent-Harnesses \- AI Agents on GitHub \- SkillsLLM](https://skillsllm.com/skill/best-of-agent-harnesses)  
> 2. [A Comparison of AI Agent Harnesses in 2026 \- Winder.AI](https://winder.ai/ai-agent-harness-comparison/)  
> 3. [Agent Harnesses & Frameworks | The Agentic AI Hub \- Daily.dev](https://daily.dev/agentic-ai-hub/agent-harnesses-frameworks/)  
> 4. [Harness Benchmarking: The Model \+ Harness Guide (2026)](https://benchgen.com/blog/ai-agent-harness-benchmarking-guide-2026)  
> 5. [Harness Agents reference | Harness AI \- Harness Developer Hub](https://developer.harness.io/harness-ai/use-harness-ai/core-capabilities/in-your-pipelines/worker-agent/harness-agents-references)  
> 6. [8 Best AI Agent Harnesses in 2026: Performance, Cost, and Speed](https://composio.dev/content/best-ai-agent-harnesses)  
> 7. [Picrew/awesome-agent-harness \- GitHub](https://github.com/Picrew/awesome-agent-harness)

---

