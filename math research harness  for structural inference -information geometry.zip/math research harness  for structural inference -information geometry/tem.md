測地線・法座標によるTEM誤差の幾何学的解明:
バイアス公式の共変な一般化とr*統計量の数値的実証
―Fraser構造推論と情報幾何学の統合に向けて(第二部)―

研究ノート

要旨
第一部では、structural modelにおけるancillary方向選択の非一意性を、Amari–Nagaokaの情報幾何学(α-接続、Efron統計的曲率)を用いて統一的に定式化し、法束(ancillary方向の候補空間)の非平坦性(ホロノミー)として具体的に定量化した(数値例で32/45という非零値)。本稿ではその続編として、tangent exponential model(TEM)の近似誤差を測地線・正規座標を用いて幾何学的に解明する。まず対数尤度のMLE中心Taylor展開を通じ、観測情報とEfron曲率の関係(Efron–Hinkley公式)を再導出し、続いてMLEのバイアスに対するCox–Snell型公式を一般p, k次元で共変な形に再定式化する。この過程で、バイアスの主要項がEfron曲率H^{(1)}ではなく歪度テンソルTおよび誘導接続Γ^{(1)S}に支配されるという理論的知見を得て、閉じた具体例で理論値(−2/9)を数値的に厳密確認する。最後に、Fraser–Reid (1995) およびDavison–Reid (2022) の定式化に基づき、TEMの核心である符号付き尤度比修正統計量r*を、十分方向V・局所canonical parameter φ(β)を明示的に構成した上で実装し、n=4という極小標本でもカバレッジ95.05%、KLダイバージェンス0.0002という高精度を達成することを実証する。

1. 導入:第一部からの接続
第一部では、structural model S の埋め込み θ(β) に対し、Efron統計的曲率テンソル H^{(1)}(第二基本形式のe-接続版)とその一般化 H^{(α)}=H^{(1)}+(1−α)/2·κ、および法束のGauss・Codazzi・Ricci方程式を導出し、ancillary方向選択の非一意性を法束ホロノミーとして数値的に確認した(5カテゴリー多項分布モデルでの非零値32/45)。
本稿の目的は、この幾何学的道具立てを用いて、TEM近似誤差そのものの幾何学的起源を解明することである。具体的には、(i) MLE中心の正規座標でのTaylor展開の各次数がH^{(1)}, ∇^{(1)}H^{(1)}, 歪度テンソルT, 誘導接続Γ^{(1)S}のいずれに対応するかを特定し、(ii) MLEバイアスの一般共変公式を導出・検証し、(iii) 最終的にTEMの完全な形(r*統計量)を実装して、これらの理論的知見が実際の推論精度向上にどう結実するかを数値的に実証する。

2. 対数尤度の測地的Taylor展開と観測情報
構造モデル上のMLE β̂ を中心に、対数尤度の差 l(β)−l(β̂) を Δθ:=θ(β)−θ(β̂) のTaylor展開として捉える。r:=x−η(θ(β̂))(MLEでの残差)は、スコア方程式 θ_a·r=0 より厳密に法空間 N_{β̂}S に属する(r_T=0)。2次の係数を計算すると:

$$j_{ab} = g_{ab} - g(H^{(1)}_{ab}, r_N) \quad (16)$$

これはEfron (1975) / Efron–Hinkley (1978) の観測情報公式の、本研究の枠組みによる再導出である。曲がった正規分布族 N(β,β²) の具体例(β=1)でこれを検証すると、観測情報は $j_{11} = 3 - \rho\sqrt{2/3}$ ( $\rho$ :=残差の符号付き大きさ)という形で、期待情報3を中心にEfron曲率のノルム $\sqrt{2/3}$ に応じて変動することが確認された。

3. MLEバイアスの一般共変公式

3.1 Cox–Snell型公式の自己導出
スコア方程式のTaylor展開摂動法により、一般p次元パラメータβに対するMLEバイアスの標準的なテンソル公式を自己導出する:

$$b^d(\beta) = i^{da}[ i^{be}\kappa_{ab,e} + (1/2)i^{bc}\nu_{abc} ] \quad (20)$$

( $i_{ab}$ :=期待情報、 $\nu_{abc}:=E[\partial_a\partial_b\partial_c\ell]$ 、 $\kappa_{ab,e}:=E[\partial_a\partial_b\ell\cdot\partial_e\ell]$ )。これは文献既知のCox–Snell (1968) 公式と一致する。

3.2 幾何学的量への変換
構造モデルの埋め込みを用い、誘導計量の微分公式

$$\partial_c g_{ab} = \Gamma^{(1)S}_{ac,b} + \Gamma^{(1)S}_{bc,a} + T_{abc} \quad (21)$$

を直接計算により導出し、真のβで $E[r]=0$ となることを用いると:

$$\nu_{abc} = -\Gamma^{(1)S}_{ab,c} - \Gamma^{(1)S}_{ac,b} - \Gamma^{(1)S}_{bc,a} - T_{abc} \quad (22)$$

$$\kappa_{ab,e} = \Gamma^{(1)S}_{ab,e} \quad (23)$$

(23)は混合キュムラント $\kappa$ が誘導e-接続のChristoffel記号そのものに一致するという、簡潔な結果である。

3.3 主結果:トレースの相殺による劇的な簡約
(22)(23)を(20)に代入し添字の対称性を用いると、 $\Lambda_a$ 型の項が厳密に相殺し、次の閉じた式が得られる:

$$b^d(\beta) = -(1/2) i^{da} [ M_a + \tau_a ] \quad (24)$$

ここで $M_a:=i^{bc}\Gamma^{(1)S}_{bc,a}$ (誘導接続Christoffel記号のトレース)、 $\tau_a:=i^{bc}T_{abc}$ (引き戻し歪度テンソルのトレース)。 $M_a$ はパラメータ化に依存する量であり、 $\nabla^{(1)S}$ の測地的正規座標(e-affineパラメータ)を選ぶと $M_a=0$ となって:

$$b^d(\beta) = -(1/2) i^{da} i^{bc} T_{abc} \quad (25)$$

という、純粋に歪度テンソルTのみで書ける形に帰着する。重要な点は、この一次のバイアスにEfron曲率 $H^{(1)}$ が直接には現れないことである——バイアス(点推定の偏り)を支配するのは歪度Tと接続の非平坦性 $\Gamma^{(1)S}$ のみであり、 $H^{(1)}$ は観測情報の変動という異なるチャネル(式16)を通じて分散側に効く。

3.4 数値検証
曲がった正規分布族 $N(\beta,\beta^2)$ ( $\beta=1$ 、n個のi.i.d.観測)で式(24)を検証する。単一観測での基本量は $g_S(1)=3$ 、 $\Gamma^{(1)S}_{11,1}(=\text{cross})=-10$ 、 $T(e_1,e_1,e_1)$ (引き戻し歪度) $=14$ であり、これらを式(24)に代入すると:

$$n\cdot b(1) = -(1/2)(1/3)[(-10/3)+(14/3)] = -2/9 \approx -0.2222 \quad (26)$$

この理論値を、厳密な確率的表現( $X_i=\beta(1+Z_i)$ 、 $W_1:=\Sigma Z_i \sim N(0,n)$ 、 $V:=\Sigma(Z_i-\bar{Z})^2 \sim \chi^2_{n-1}$ が互いに独立)に基づく大規模モンテカルロ( $N=3\times 10^6$ )で検証した結果を表1に示す。

| n | モンテカルロ n×バイアス | 理論値 −2/9 |
|---|---|---|
| 10 | −0.2210 | −0.2222 |
| 20 | −0.2225 | −0.2222 |
| 50 | −0.2196 | −0.2222 |
| 100 | −0.2248 | −0.2222 |
| 300 | −0.2255 | −0.2222 |

表1: 式(24)–(26)による理論的バイアス予測(−2/9)と、モンテカルロ標準誤差(0.001〜0.006)の範囲内で一致する数値検証結果。

さらに、観測情報 $j_n(\hat{\beta})$ と期待情報 $i_n(\hat{\beta})$ を用いた2種類のWald信頼区間のカバレッジを比較したところ、両者の差は全ての標本サイズで0.1%未満に留まり、 $H^{(1)}$ 由来の分散補正は本モデルにおいて実務上ほぼ無視できることが確認された。一方でカバレッジ不足(n=3で83.5%)の主因は式(26)で捉えた $O(1/n)$ バイアスであり、Efron曲率よりも歪度テンソルTがTEM精度を実質的に支配するという理論的知見が実証された。

4. r*統計量(完全なTEM)の実装と検証

4.1 定式化の確認(Fraser–Reid 1995 / Davison–Reid 2022)
Davison & Reid (2022) のレビューに基づき、nuisanceパラメータを含む一般公式(34)を、本研究の設定(p=1、nuisanceパラメータなし)に特殊化する。まず十分方向 V(sufficient direction)を、構造方程式 $S_1=\beta(n+W_1)$ , $S_2=\beta^2(n+2W_1+W_2)$ ( $W_1,W_2$ は真の $\beta$ に依らない厳密にpivotalな量)を $\beta$ について偏微分することで構成する:

$$V = \left( \frac{S_1}{\hat{\beta}} , \frac{2S_2}{\hat{\beta}} \right) \quad (27)$$

局所canonical parameter $\phi(\beta)$ は、対数尤度のサンプル空間微分をVと内積することで得られる:

$$\phi(\beta) = V\cdot\left(\frac{\partial\ell}{\partial S_1}, \frac{\partial\ell}{\partial S_2}\right) = \frac{S_1}{\hat{\beta}\beta} - \frac{S_2}{\hat{\beta}\beta^2} \quad (28)$$

これを用い、 $r(\beta)$ (符号付き尤度比統計量、第一部の実装から不変)と、Wald型統計量 $q(\beta)$ を構成する:

$$q(\beta) = \frac{[\phi(\hat{\beta})-\phi(\beta)]\cdot\sqrt{j_p(\hat{\beta})}}{\phi'(\hat{\beta})} \quad (29)$$

$$r^*(\beta) = r(\beta) + \frac{1}{r(\beta)}\cdot\log\left(\frac{q(\beta)}{r(\beta)}\right) \quad (30)$$

4.2 数値結果
n=4〜40の各標本サイズで、大規模モンテカルロ( $N=3\times 10^5$ )により $r^*(\beta)$ の分布を検証した。比較対象は、素朴なWald統計量(期待情報)、観測情報によるWald統計量、および前段階の尤度比統計量rである。

| n | KS距離 Wald(期待) | KS距離 Wald(観測) | KS距離 r | KS距離 r* | カバレッジ Wald(期待) | カバレッジ r* |
|---|---|---|---|---|---|---|
| 4 | 0.1325 | 0.1338 | 0.0925 | 0.0027 | 85.9% | 95.05% |
| 6 | 0.1056 | 0.1065 | 0.0752 | 0.0032 | 88.6% | 95.02% |
| 10 | 0.0805 | 0.0810 | 0.0569 | 0.0018 | 91.0% | 95.03% |
| 20 | 0.0559 | 0.0561 | 0.0413 | 0.0013 | 92.9% | 94.98% |
| 40 | 0.0371 | 0.0370 | 0.0274 | 0.0028 | 94.0% | 95.00% |

表2: 4手法の比較。目標カバレッジは95.00%。r*はn=4でもほぼ厳密なカバレッジを達成。

さらにn=4における標準正規分布からのKLダイバージェンスを比較すると、Wald(期待情報)が0.2899であるのに対し、rは0.0277、r*はわずか0.00020であった。これはr*がWaldの約1500分の1という、実質的に区別不能なレベルの精度を、極小標本においてすら達成することを意味する。

5. 結論:2部構成の研究の統合的総括
第一部・第二部を通じて得られた知見を統合すると、次の一貫したストーリーが得られる。

1. Ancillary方向選択の非一意性は、法束(ancillary方向の候補空間)の非平坦性・ホロノミーとして幾何学的に定式化できる(第一部、数値例で32/45という具体的な非零値)。
2. TEM近似誤差の起源は一様ではない:観測情報(Efron曲率 $H^{(1)}$ 由来)は分散側の2次補正だが実務上の影響は小さく、バイアス・カバレッジ不足を支配するのは誘導接続 $\Gamma^{(1)S}$ と歪度テンソルT由来の3次項である(式24–26)。
3. Fraser–Reidの十分方向V(局所位置モデルの構造方程式に基づく構成)を用いた完全なTEM/r*統計量は、これら全ての誤差源(観測情報・歪度・接続の非平坦性)を自動的かつ正確に統合し、n=4という極端な小標本でも名目カバレッジをほぼ厳密に達成する(表2)。

この結果は、D.A.S. Fraserが構造推論の枠組みで追求した「ancillary統計量に基づく条件付き推論の正確性」が、Amari–Nagaokaの情報幾何学の言葉(α-接続、Efron曲率、歪度テンソル、法束曲率)によって統一的に説明され、かつ具体的な数値実験によって実証されることを示すものである。

今後の課題として、(i) 本稿の理論・数値検証は全てp=1の具体例に基づいており、 $p \ge 2$ (第一部6.3節のホロノミーが非自明な場合)でr*統計量がどう振る舞うか、特に方向依存的推論(directional inference, Fraser–Reid–Sartori 2016)との関係の解明、(ii) 非指数型のstructural model(Fraser本来の構造方程式 $X=\theta(\beta)*U$ )への拡張、(iii) 式(24)の一般p,k次元での数値検証、が挙げられる。

参考文献(主要な関連研究)
- Amari, S. and Nagaoka, H. (2000). Methods of Information Geometry. AMS/Oxford University Press.
- Andrews, D. A., Fraser, D. A. S. and Wong, A. (2005). Computation of distribution functions from likelihood information near observed data. Journal of Statistical Planning and Inference 134, 180–193.
- Barndorff-Nielsen, O. E. (1983). On a formula for the distribution of the maximum likelihood estimator. Biometrika 70, 343–365.
- Barndorff-Nielsen, O. E. (1986). Inference on full or partial parameters based on the standardized signed log likelihood ratio. Biometrika 73, 307–322.
- Cox, D. R. and Snell, E. J. (1968). A general definition of residuals. Journal of the Royal Statistical Society B 30, 248–275.
- Davison, A. C. and Reid, N. (2022). The Tangent Exponential Model. arXiv:2106.10496.
- Efron, B. (1975). Defining the curvature of a statistical problem (with applications to second order efficiency). Annals of Statistics 3(6), 1189–1242.
- Fraser, D. A. S. and Reid, N. (1995). Ancillaries and third order significance. Utilitas Mathematica 47, 33–53.
- Fraser, D. A. S. and Reid, N. (2001). Ancillary information for statistical inference. In Empirical Bayes and Likelihood Inference, Springer.
- Fraser, D. A. S., Reid, N. and Sartori, N. (2016). Accurate directional inference for vector parameters. Biometrika 103, 625–639.
- Skovgaard, I. M. (1985). A second-order investigation of asymptotic ancillarity. Annals of Statistics 13, 534–551.
- Skovgaard, I. M. (1996). An explicit large-deviation approximation to one-parameter tests. Bernoulli 2, 145–165.