# Fraser-Compatible Structural Information Geometry: Initial Audit

Date: 2026-09-27 10:38:15 (OS local time)
Agent: GitHub Copilot
Evidence status: theorem candidate `open`; conditional score-transport identity `proved/agent`; logistic quadrature `verified-computationally` only at the scope stated below.

## Scope and inputs

Audited [the proposal](../../../ChatGPT-理論拡張案-20260926-2117.md) and built the disposable probe at [logistic_model.py](../../../.research-scratch/fraser_structural_geometry/20260927-initial-audit/logistic_model.py). The proposed manuscript attachments are not present in this workspace, so claims about their current equations or corrections could not be checked against those manuscripts. The supplied root `LEDGER.md` is a blank template; there was no `threads/`, `threads/INDEX.md`, local reference catalog, `tools/reference_lookup.py`, `docs/ENVIRONMENT.md`, or Git repository at task start. The repository's root `LITERATURE.md` and `COMPUTATIONS.md` were available and followed to the extent the workspace permits.

The source is an exported proposal, not primary mathematical evidence. Its cited links are discovery leads only. No literature claim is promoted to `proved/literature` here.

## A-H claim inventory

| Category | Classification | Audit |
|---|---|---|
| A. Fraser equation `X = theta(beta) * U` | Definition / model representation | It is a proposed primitive structural representation, subject to a specified action, error law, and regularity. It is not by itself a theorem about induced likelihood geometry. |
| B. General structural model and `v_a = partial_a F(beta,u)` | Definition; conditional theorem candidate | To obtain a vector field on sample space, each `F_beta` needs a suitable local inverse (or another specified transport construction). The continuity-equation score identity follows when the pushforward has a smooth density and the transport equation has no unaccounted boundary flux. The proposed `F_ab` is not yet a defined curvature. |
| C. Statistical model geometry | Definition / construction | `P_beta = (F_beta)_# P_0` is a pushforward construction. Absolute continuity, common domination, differentiability under the integral, and nonsingular Fisher information are additional assumptions, not automatic consequences of the structural equation. |
| D. Information geometry (`g`, `T`, alpha connection) | Definitions; standard conditional identities | Use `g_ab = E[s_a s_b]` and `T_abc = E[s_a s_b s_c]` under mean-zero scores and finite moments. The proposal's `g_abc = E[s_a s_b]` is an index typo. With convention `Gamma^(alpha) = Gamma^(0) - alpha*T^sharp/2`, the affine difference identity is algebraic; smoothness and duality assumptions remain necessary for the geometric package. |
| E. Ancillary contour `V` versus normal bundle `N` | Distinction / reformulation, not theorem | These are different constructions: a structural orbit/contour in sample space versus a metric-orthogonal complement in a specified statistical ambient manifold. No canonical equality follows. The proposal's `U_beta(X)` depends on the unknown beta, so it is an error coordinate/pivot, not automatically an ancillary statistic. |
| F. Connections and curvature (`H^(alpha)`, Ricci) | Definitions plus conditional theorem candidates | `H^(alpha)` requires an immersion into a chosen ambient statistical manifold and a normal projection. Defining `kappa = Pi_N T^sharp` gives `H^(alpha) = H^(1) + (1-alpha)kappa/2` under the stated connection convention. The displayed Gauss-Codazzi-Ricci equations and signs were not independently checked against one fixed convention. |
| G. Holonomy (`R_perp != 0` versus `F = 0`) | Analogy / open structural proposal | Nonzero curvature of a specified normal connection implies local non-flat transport; it does not imply nonexistence of an exact ancillary. Involutivity `[v_a,v_b] in span(v)` is a Frobenius condition. The proposed `F_ab = [v_a,v_b] - C_ab^c v_c` is not a curvature until the fields, coefficients, and bundle/tensorial meaning of `C` are defined. Structural integrability and normal curvature can be separate questions, but their independent realizability needs an example or proof. |
| H. “Structural-Information-Geometric Consistency Theorem” | Conjectural theorem candidate; status `open` | As written it bundles pushforward regularity, information geometry, submanifold geometry, named curvature conventions, and recovery of unavailable earlier-paper formulas. Most identities are conditional standard constructions; the recovery clause and any Fraser-specific content remain unverified. It is not a theorem in this record. |

Two further proposal-level statements need qualification:

- The asserted chain `Fraser ⊃ general structural model ⊃ curved exponential model ⊃ TEM` is an analogy, not a literal inclusion of model classes. A TEM is a local approximation/construction, not generally a subclass of the original model.
- A nonzero normal holonomy result concerns parallel transport for the selected normal connection. It cannot alone establish nonexistence or nonuniqueness of exact ancillary statistics.

For the location-scale family, `A(X) = ((X_i - mean(X))/R(X))_i`, where `R(X) = sqrt(sum_i (X_i-mean(X))^2)`, is an example of a parameter-free location/positive-scale invariant and is ancillary when defined (the zero-denominator event has probability zero under the continuous model). By contrast `U_beta(X)` is beta-dependent. This repairs the ancillary example without identifying it with a normal bundle.

## Eight-step theorem-candidate protocol

The request names an “8-stage protocol” but enumerates five deliverables, and the workspace contains no separate protocol template. The five named deliverables are covered below, with the proof/reduction/computation obligations split out to make eight explicit stages.

### 1. Assumptions

Let `B` be a smooth `p`-manifold, `U` and `X` smooth sample spaces with a common dominating measure, and `F_beta: U -> X` a `C^3` diffeomorphism for each beta (or state and prove a suitable nonsingular transport replacement). Let `U ~ P_0`; require the pushforwards `P_beta = (F_beta)_# P_0` to have positive densities `p_beta`, differentiable in beta under the integral with the required domination and boundary conditions. Require scores in `L^2`, third score products integrable, and positive-definite Fisher metric.

For second fundamental forms and normal curvature, additionally specify a smooth ambient statistical manifold `M_tilde`, a smooth immersion `i: M -> M_tilde`, its Fisher metric, cubic tensor, dual alpha-connections, a nondegenerate metric normal bundle, and enough differentiability for curvature. These ambient data are absent from the proposal's logistic example and cannot be inferred from the two-parameter family alone.

### 2. Nonstandard objects

- `v_a(F_beta(u)) = partial_a F(beta,u)` with `u` held fixed; this requires local invertibility to define the field at `x`.
- `s_a = partial_a log p_beta`; `g_ab = E_beta[s_a s_b]`; `T_abc = E_beta[s_a s_b s_c]`.
- `T^sharp` is obtained by raising one index with `g`; `Gamma^(alpha) = Gamma^(0) - alpha*T^sharp/2` fixes the convention.
- For an immersion into `M_tilde`, `H^(alpha)(X,Y) = Pi_N(nabla_tilde_X^(alpha)Y)` and `kappa(X,Y) = Pi_N(T^sharp(X,Y))`.
- `R_perp^(alpha)` is the curvature of the induced normal connection, not a property of the sample-space vector fields by itself.
- An exact ancillary is a parameter-free statistic whose distribution is parameter-independent. A parameter-indexed residual `U_beta(X)` does not meet that definition by itself.

### 3. Proof attempt: pushforward score and Fisher geometry

If `p_beta` is transported by `v_a`, the continuity equation is
`partial_a p_beta + div(p_beta v_a) = 0`. Expanding the divergence and dividing by positive `p_beta` gives
`s_a = -div(v_a) - v_a(log p_beta)`.
This proves the displayed score identity under the assumptions above; integration by parts is not needed for this pointwise identity, though boundary conditions matter for expectation identities. Then `g` and `T` are defined by score moments. Their finiteness and positive-definiteness are assumptions, not conclusions of this calculation.

### 4. Proof attempt: connection and embedding identities

From the fixed convention, `nabla^(alpha) - nabla^(1) = (1-alpha)T^sharp/2`. Applying the same normal projection to an immersed submanifold yields `H^(alpha) = H^(1) + (1-alpha)kappa/2`. This is a conditional algebraic identity. It does not construct the ambient manifold, immersion, normal frame, or a nontrivial normal bundle.

The Gauss-Codazzi-Ricci part needs a separate derivation with explicit dual second fundamental forms, shape-operator sign convention, and normal connection. The proposal's displayed formulas are not admitted as proved here.

### 5. Proof attempt: special-case recovery

To recover the earlier curved-exponential formulas, identify the exact ambient coordinates, e-flatness assumption, cubic tensor convention, second fundamental form convention, and the target manuscript equations. The referenced `.docx` files are unavailable here, so the recovery clause cannot currently be checked. “Generalized Efron curvature” should remain a proposed name until equivalence to the established Efron curvature is proved under explicit hypotheses.

### 6. Counterexample search and current obstructions

- Ancillary error-coordinate test: `U_beta(X)` changes with beta and is not a statistic independent of beta. Use a maximal invariant such as standardized residuals when an exact ancillary is needed.
- Ambient-choice test: if the two-parameter location-scale logistic family is itself the ambient manifold, its normal bundle has rank zero, so `H`, `kappa`, and `R_perp` are trivial/absent. A nontrivial calculation requires a larger specified ambient family; arbitrary ambient choices can change these quantities.
- Inference test: exact ancillary existence and flatness of a chosen normal connection are logically distinct. No theorem in the proposal bridges them.
- Integrability test: Frobenius involutivity is a condition on a distribution. The proposed `F_ab` needs a precise definition and is not, as currently written, an independent curvature invariant.

No explicit example with `F=0` and `R_perp != 0` was constructed in this bounded task; that coexistence remains open here, not established by analogy.

### 7. Literature inquiry plan

Before public discovery, query the local catalog with `uv run python tools/reference_lookup.py` for Fraser structural models/ancillaries, Amari alpha-connections and the Amari-Chentsov tensor, statistical submanifold Gauss-Codazzi-Ricci equations, Efron curvature, and tangent exponential models. The required script/catalog is absent in this workspace; the query is therefore a next-step plan, not a completed search. Then use primary sources and versioned arXiv TeX where available to check exact hypotheses, signs, and locators. Treat the proposal's Reid, Fraser-Staicu-Fraser, Marriott, and TEM links as leads only; verify bibliographic identity and the exact statements. For any claimed resolution of a paper-stated open problem, perform the forward-citation check required by `LITERATURE.md`. No external source was verified in this task.

### 8. Status and decision gate

The candidate theorem remains `open`. Its elementary score-transport and connection-difference components can be separated as conditional lemmas; a substantive consistency theorem still needs a selected ambient model, a verified dual-connection Ricci convention, comparison with the unavailable manuscripts, and an example testing the proposed structural/normal-curvature independence. The current logistic computation is a pilot only.

## Location-scale logistic pilot

For iid `U_i ~ Logistic(0,1)`, `X_i = mu + exp(tau) U_i`, put `u_i = (x_i-mu)exp(-tau)`. The structural sensitivities and likelihood scores are

```text
v_mu = (1,...,1)
v_tau = (x_1-mu,...,x_n-mu)
s_mu = exp(-tau) sum_i tanh(u_i/2)
s_tau = -n + sum_i u_i tanh(u_i/2)
```

The script checks the differentiated log density and continuity-equation score against these expressions at two deterministic parameter/sample points for `n=4`. Those pointwise checks are sanity checks, not an identity proof. Under `Y = tanh(U/2)`, `Y` is uniform on `(-1,1)` and the one-observation standardized scores are `Y` and `2Y atanh(Y)-1`. The script uses one-dimensional adaptive quadrature for the second and third score moments, then scales them by `n` for iid observations.

Observed pilot output for `n=4`, `tau=0`:

```text
g ~= [[1.3333333, 0], [0, 5.7198242]]
T_mmm = 0; T_mmt ~= 1.33333333333335
T_mtt = 0; T_ttt ~= 13.1594725348213
```

The values are quadrature outputs (SciPy error estimate threshold `1e-8`), not exact symbolic evaluations. They are consistent with candidate closed forms `g_tautau = 4*(pi^2+3)/9`, `T_mumu_tau = 4/3`, and `T_tautau_tau = 4*pi^2/3`; those closed forms were not established in this run. Exact symbolic score differentiation is implemented; Fisher/T output remains numerical quadrature.

The code also includes generic finite-dimensional ambient-chart routines for `H^(1)`, `kappa`, and `d(omega)+omega wedge omega`. A flat-line ambient smoke test returned zero `H` and `kappa`; a zero normal-connection test returned zero normal curvature. These are implementation sanity checks, not logistic normal-curvature results. Logistic `H^(1)`, `kappa`, and `R_perp^(1)` remain undetermined until an ambient statistical model and normal frame are specified.

Execution facts: Python 3.14.6, SymPy 1.14.0, SciPy 1.18.1; symbolic expressions plus double-precision `scipy.integrate.quad`. The selected VS Code Python interpreter is unset. No project backend is recorded because `docs/ENVIRONMENT.md`, `uv`, and the project preflight tools are absent. The probe stays in `.research-scratch/` and is not a durable computation package.

## Canonical implications

- Keep the consistency theorem `open`; do not state it as proved or literature-established.
- Treat structural contours, parameter-free exact ancillaries, and Fisher-normal bundles as separate objects.
- Do not report logistic normal curvature before an ambient model and normal-frame convention are fixed.