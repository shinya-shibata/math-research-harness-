Date: 2026-09-30 21:36:08 (OS local time)
Agent: GitHub Copilot
Type: literature search

# SIAM search snapshot: Fraser ancillary statistical inference

## Search purpose

- Research question: locate SIAM literature relevant to Fraser-style structural models and ancillary statistics.
- Search pass: question-driven discovery
- Search source: SIAM Journals, native search interface
- Search date and time: 2026-09-30; the exact browser timezone is unavailable.
- Exact query: `Fraser ancillary statistical inference`
- Query field: Anywhere (`AllField`)
- Filters and sort order: no filters; relevance; 20 results per page
- Search URL: <https://epubs.siam.org/action/doSearch?AllField=Fraser%20ancillary%20statistical%20inference>

## Result coverage

- Displayed result count: 7 (`Results: 1 - 7 of 7`)
- Page size: 20
- Pages exposed: one
- Pages inspected: one
- Results inspected: 7/7 at title and displayed bibliographic-metadata level
- Coverage status: all displayed results inspected
- Access or interface notes: results rendered in the shared browser despite a failed Cloudflare challenge resource and a 403 resource event. The result list itself was visible.

This records only the publisher's returned result set for this query. No
abstracts or full texts were evaluated, and no claim of corpus coverage or
mathematical relevance is made. The mixed results suggest this query is too
broad for a targeted Fraser/ancillarity search; the publisher's exact matching
semantics were not established.

## Results

| # | Title | Authors | Year | Journal/book | DOI or stable URL | Triage / next action |
|---|---|---|---:|---|---|---|
| 1 | Adjusted Likelihood Inference About Interest Parameters | Ole E. Barndorff-Nielsen | 1994 | Theory of Probability & Its Applications, 38(2), 179-193 | <https://doi.org/10.1137/1138021> | Title-level relevance unassessed; inspect abstract only if likelihood-adjustment terminology is relevant. |
| 2 | 1. Bayesian Statistics a Review | D. V. Lindley | 1972 | Bayesian Statistics | <https://doi.org/10.1137/1.9781611970654.ch1> | Broad search hit; relevance unassessed. |
| 3 | Mortality Implications of Mortality Plateaus | Trifon I. Missov; James W. Vaupel | 2015 | SIAM Review, 57(1), 61-70 | <https://doi.org/10.1137/130912992> | Broad search hit; relevance unassessed. |
| 4 | Back Matter | Not displayed | 2017 | Advances and Trends in Optimization with Engineering Applications | <https://doi.org/10.1137/1.9781611974683.bm> | Back matter hit; no apparent relevance from displayed metadata. |
| 5 | Back Matter | Not displayed | 2023 | Computational Discovery on Jupyter | <https://doi.org/10.1137/1.9781611977509.bm> | Back matter hit; no apparent relevance from displayed metadata. |
| 6 | Back Matter | Not displayed | 2026 | Perturbation Methods Using Backward Error | <https://doi.org/10.1137/1.9781611978865.bm> | Back matter hit; no apparent relevance from displayed metadata. |
| 7 | Chronicle | Not displayed | 1968 | SIAM Review, 10(2), 244-290 | <https://doi.org/10.1137/1010054> | Broad search hit; relevance unassessed. |

## Limits and next step

- Not done: abstract/full-text review, bibliographic verification outside the result page, citation chasing, or searches using title/author/keyword-specific fields.
- Next: split Fraser-author lookup from ancillary terminology searches; record each SIAM field and query as a separate search pass. Use publisher-exported BibTeX/citation data for any source selected for checking.
- Record template: `templates/LITERATURE-SEARCH-RECORD.md`.