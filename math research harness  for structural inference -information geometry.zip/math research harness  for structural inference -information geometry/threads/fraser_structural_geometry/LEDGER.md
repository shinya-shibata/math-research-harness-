# Thread: Fraser-Compatible Structural Information Geometry

Status: active
Active mode: bounded task
Last updated: 2026-09-27-103815 by GitHub Copilot
Claim catalog: inline
Active state: none

## Owner direction

Audit the supplied theory proposal and initiate the location-scale logistic pilot. Keep structural ancillary questions distinct from information-geometric normal transport. Do not promote the consistency candidate to a theorem without explicit ambient data and verified hypotheses.

## Conventions

- Evidence statuses follow `AGENTS.md`; the proposal export and its citations are not verified sources.
- Fix `Gamma^(alpha) = Gamma^(0) - alpha*T^sharp/2` when comparing alpha-connection formulas.
- `U_beta(X)` is parameter-dependent; an exact ancillary must be a parameter-free statistic.

## Current theory map

The structural pushforward can induce a regular statistical model under additional assumptions. The proposal conflates sample-space sensitivity, exact ancillary statistics, and normal geometry unless these are explicitly separated. Normal curvature is not defined by the logistic family alone: an ambient statistical manifold and immersion are required.

## Durable claims

No nonformal mathematical claim is currently admitted as a durable theorem.

## Current opportunities

- `open`: formulate the consistency result as conditional lemmas after choosing an ambient model and fixing dual-connection Ricci conventions.
- `open`: verify the exact logistic score-moment formulas and choose whether a higher-dimensional ambient family is mathematically motivated.
- `open`: check the Fraser/TEM and information-geometry literature using the local catalog once the missing lookup infrastructure is available.

## Corrections and durable obstructions

The proposed theorem and the compatibility of `F = 0` with `R_perp != 0` are not established. See [the initial audit](notes/2026-09-27-103815-fraser-consistency-audit.md) for scope, classifications, conditional derivations, computation, and literature plan.