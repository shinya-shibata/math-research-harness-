# Computational environment

This is the canonical record of the project's mathematical computing stack.
The related research policies are kept at the repository root alongside
`AGENTS.md`; `COMPUTATIONS.md` defines how computational evidence is recorded.

## Selected backends

| Backend | Responsibility | Invocation | Version source |
|---|---|---|---|
| SymPy | Exact symbolic expressions and differentiation | Python imports from `sympy` | `uv.lock` |
| NumPy | Floating-point arrays and linear algebra | Python imports from `numpy` | `uv.lock` |
| SciPy | Numerical integration and statistical routines | Python imports from `scipy` | `uv.lock` |

These roles support the current structural-model and information-geometry
workflows. Keep symbolic identities exact in SymPy where possible; label
floating-point calculations with their precision and scope. The libraries are
computational tools, not a substitute for proving general mathematical claims.

## Setup and preflight

Install the declared, lockfile-resolved dependencies and check that the
symbolic and numerical backends perform their basic operations:

```bash
uv sync
uv run python tools/computation_preflight.py
```

The preflight prints the active Python and package versions, then checks exact
symbolic differentiation, NumPy linear solving, and SciPy adaptive quadrature.
Run it before relying on these backends in a session. The lockfile selects
compatible concrete package versions for the active Python version.

Run the offline test suite with:

```bash
uv run python -m unittest discover -s tests
uv run python -m unittest discover -s .github/prompts -p 'test_hypothesis_batch.py'
```

Declare additional reusable Python dependencies with `uv add`. Keep a new
dependency only when a concrete research task benefits from it; commit both
`pyproject.toml` and `uv.lock` changes together.
