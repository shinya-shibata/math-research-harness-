# Agent Harness Improvement Review: Mathematical Research Harness

- Review date: 2026-09-29 22:40:06 +09:00 (OS local time)
- Authorization: Explicit owner invocation of `/review-agent-harness`
- Status: `blocked`
- Scope: Current repository's owner-directed mathematical research harness; discovery and selected comparison of external agent-harness practices
- Exclusions: No implementation, adoption, mathematical thread changes, paper edits, dependency installation, code execution from external repositories, or ongoing monitoring
- Report slug: `research-harness-review`

## Summary

This is a partial review, not a completed comparison of the external harness landscape. All seven entries in the repository's site list were opened directly, and relevant first-party engineering material and two primary research papers were inspected. However, this session had no general web-search/query tool. It could fetch known URLs and follow links surfaced by those pages, but could not independently search the wider web or run focused searches on the listed sites. Two OpenAI first-party pages returned HTTP 403. The review therefore stops at preliminary findings; the missing discovery coverage is a blocker, not evidence that no relevant systems or counterevidence exist.

Two provisional, testable ideas emerged: add a small offline regression set for the research harness's authority/evidence workflows, and make query-capable external-search availability an explicit run-time precondition for reviews that claim external coverage. Neither is adopted or ready for implementation approval based on this partial source coverage.

## Current Harness Baseline

| Dimension | Current behavior | Evidence path(s) | Limitation or uncertainty |
|---|---|---|---|
| Owner authority and scope | Conversation is the control plane. Harness review is explicitly opt-in and report-only; implementation and adoption need a separate owner instruction. | `AGENTS.md`; `.github/prompts/review-agent-harness.prompt.md` | The new review prompt has not yet been exercised in a model-backed policy scenario suite. |
| Context and state | Mathematical work is loaded selectively from steering, ledgers, and citations. Scratch, research batches, notes, and ledgers provide different persistence levels. | `AGENTS.md`; `README.md`; `.github/prompts/HYPOTHESIS-WORKFLOW.md` | No single cross-session event trace or general task-resume record is implemented; the research records are domain-specific. |
| Tools, execution, and recovery | Python utilities support computation preflight and local reference catalog operations. The literature lookup is explicitly offline; the harness-review prompt relies on the external-search tools exposed by the agent runtime. | `tools/computation_preflight.py`; `tools/reference_lookup.py`; `tools/reference_metadata.py`; `LITERATURE.md` | No general web-query client or source-site adapter exists in `tools/`. This review runtime could fetch known URLs but could not issue general web searches. |
| Validation and feedback | JSON Schema and unit tests check hypothesis-batch shape, local references, provider coverage, and declared search provenance. Other local tools have offline tests. | `.github/prompts/HYPOTHESIS-CANDIDATE.schema.json`; `.github/prompts/hypothesis_batch.py`; `.github/prompts/test_hypothesis_batch.py`; `tests/` | These tests validate records and utilities, not whether the agent actually obeys owner-authority rules or completes an end-to-end research task. |
| Evidence and provenance | Literature procedures separate discovery from claim verification; computation and durable records have reproducibility guidance. | `LITERATURE.md`; `COMPUTATIONS.md`; `templates/` | External site/query execution depends on the active agent runtime; repository code cannot independently certify what a browser/search tool actually returned. |
| Security and isolation | The contract constrains authority and preserves owner control. The documented compute workflow uses the selected local backend. | `AGENTS.md`; `COMPUTATIONS.md`; `ENVIRONMENT.md` | No general sandbox for arbitrary external harnesses is implemented; this review correctly did not execute or install them. No evidence here justifies adding one for current workflows. |
| Reproducibility and cost | Utility tests and computation preflight are available. Literature records pin sources and locators when checked. | `README.md`; `tests/`; `LITERATURE.md` | There is no harness-specific, model/task-versioned evaluation suite or cost/latency baseline. |

## Method and Coverage

- Research question: Which externally documented harness practices have a plausible, evidence-supported transfer to this owner-directed mathematical research harness, and what should be tested before any adoption?
- Retrieval date: 2026-09-29.
- Method: Inspected the local contract, README, harness-review prompt, literature and computation policies, hypothesis workflow/schema/validator/tests, local literature tools, the supplied site list, and the supplied `AI Agent Harness Research.md`. Opened all seven site-list entries directly. Followed surfaced links to first-party engineering articles and primary paper records. No external instructions, code, packages, or configuration were executed.
- Search coverage: Direct URL retrieval and link-following only. No general web search or query-capable publisher-site search was available in this session. Thus exact-claim searches, independent alternative-term searches, and broad discovery beyond the supplied links were not completed.
- Inclusion: Owner authority, state/context, tool boundaries, evidence, verification, harness-specific evaluation, and transferable low-risk practices.
- Comparison constraint: Coding-agent and SaaS-workflow results are not treated as performance evidence for mathematical research. Vendor and curator claims are kept distinct from primary research and implementation evidence.

### Site-List Coverage

| Entry | Status | What was inspected and how it is used |
|---|---|---|
| SkillsLLM - Best of Agent Harnesses | `inspected` | Direct page opened. It is a curated/ranked directory whose page describes rankings using relevance, GitHub stars, and activity; useful for candidate discovery, not independent evidence that a harness is superior. [Page](https://skillsllm.com/skill/best-of-agent-harnesses) |
| Winder.AI comparison | `inspected` | Direct comparison opened. The article says seven compared systems are used in the author's Helix fleet; its judgments are experience-based and commercially situated. Useful for assumptions/tradeoffs, not neutral ranking evidence. [Page](https://winder.ai/ai-agent-harness-comparison/) |
| Daily.dev Agentic AI Hub | `inspected` | Direct page opened. It distinguishes ready-to-use harnesses from build frameworks and gives use-case summaries; a directory, not a controlled evaluation. [Page](https://daily.dev/agentic-ai-hub/agent-harnesses-frameworks/) |
| Composio benchmark | `inspected` | Direct report opened. It compares eight systems on 25 SaaS-workflow tasks with Kimi K3 and a shared tool setup. The report states one scored attempt per valid task, five removed tasks, and business-app rather than coding coverage. Useful as a methodology example only. [Page](https://composio.dev/content/best-ai-agent-harnesses) |
| Winder.AI/BenchGen benchmarking guide | `inspected` | Direct guide opened (published 2026-09-25). It synthesizes recent benchmark claims and links primary material, but is a commercial benchmark-platform article; its headline claims were not accepted without source-level qualification. [Page](https://benchgen.com/blog/ai-agent-harness-benchmarking-guide-2026) |
| Harness Developer Hub reference | `not relevant` | The supplied URL documents Harness.io's Worker Agent pipeline fields, not a comparative AI-agent-harness directory. It illustrates product-specific controls such as allowed domains and turn limits, but does not establish comparative quality. [Page](https://developer.harness.io/harness-ai/use-harness-ai/core-capabilities/in-your-pipelines/worker-agent/harness-agents-references) |
| Picrew/awesome-agent-harness | `inspected` | GitHub catalog opened. The page reports 372 entries across nine categories and a 2026-09-21 verification date; it is a discovery map, not an evaluation. The repository page reports one contributor, so curation breadth should not be mistaken for independent review. [Repository](https://github.com/Picrew/awesome-agent-harness) |

The supplied site-list document itself is a saved answer to a Gemini prompt, not a source that certifies the listed sites' claims. See [`AIエージェントのハーネス調査サイト一覧.md`](../AIエージェントのハーネス調査サイト一覧.md).

## Source and Evidence Register

| Source | Type / date | Claim checked and evidence | Limitations |
|---|---|---|---|
| [Harness-Bench, arXiv:2605.27922v1](https://arxiv.org/html/2605.27922v1) | Primary research preprint; 2026-05-27 | Describes 106 offline tasks and a 6 configurable-harness x 8-model matrix (5,088 trajectories), plus 106 separately reported Codex runs, for 5,194 total. The paper explicitly says results are configuration-level diagnostics, not causal decompositions of mechanisms or guarantees about all workflows. It includes final artifacts, traces, usage, validators, and process/security signals. | arXiv preprint; scoring includes LLM-assisted process rubrics; fixed task suite and coding/workflow mix. It is evidence for an evaluation method, not a ranking to transfer to this project. |
| [Agentless, arXiv:2407.01489v2](https://arxiv.org/html/2407.01489v2) | Primary research preprint; version dated 2024-10-29 | Presents a fixed three-stage localization/repair/patch-validation pipeline. The v2 paper reports 96/300 (32%) on SWE-bench Lite at an average reported cost of $0.70, and discusses dataset quality and external validity. | A coding benchmark and a particular model/setup. The model does not autonomously choose tools/actions; this does not imply that a deterministic pipeline suits open-ended mathematical research. |
| [Agentless repository](https://github.com/OpenAutoCoder/Agentless) | First-party project README/repository | The README describes the same staged design and separately reports an earlier v1 result of 82 fixes at $0.34. | The repository page shows its latest release/commit from about two years ago. Do not merge its earlier release metrics with the later paper version. |
| [Effective harnesses for long-running agents](https://www.anthropic.com/engineering/effective-harnesses-for-long-running-agents) | First-party engineering article; 2025-11-26 | Describes initializer/coding-agent separation, progress artifacts, incremental work, and end-to-end verification; explicitly frames the work as one possible solution and lists unresolved generalization questions. | A web-app/coding experiment from the vendor; not a measured result for research workflows. |
| [Building effective agents](https://www.anthropic.com/engineering/building-effective-agents) | First-party engineering article; 2024-12-19 | Recommends the simplest adequate design, explicit workflows for predictable tasks, testing, clear tool interfaces, and adding complexity only when it improves measured outcomes. The page warns that much of its tooling landscape changed. | Use its general design cautions, not its dated product choices as current state. |
| [Improving Deep Agents with harness engineering](https://www.langchain.com/blog/improving-deep-agents-with-harness-engineering) | First-party vendor engineering report; 2026-02-17 | Reports a Terminal-Bench 2.0 change from 52.8 to 66.5 with GPT-5.2-Codex held fixed, and describes trace analysis, self-verification, context setup, and loop detection. It also warns that task-overfit harness changes can regress other tasks. | Vendor-reported coding evaluation; not independently reproduced here and not causal isolation of each individual change. |
| [Evaluating Deep Agents: Our Learnings](https://www.langchain.com/blog/evaluating-deep-agents-our-learnings) | First-party engineering article; 2025-12-03 | Recommends bespoke assertions for trajectory, final response, and state; single-step and full-turn tests; clean environments; and multi-turn tests with early checks. | Product team's practice, not independent comparative evidence. The patterns are directly useful for designing a small local test set. |
| [OpenAI Harness Engineering](https://openai.com/index/harness-engineering/) and [Unrolling the Codex Agent Loop](https://openai.com/index/unrolling-the-codex-agent-loop/) | First-party pages attempted | Both known URLs returned HTTP 403 to the available fetch mechanism. | Content not inspected; excluded from evidence. |
| `AI Agent Harness Research.md` | Local secondary synthesis | Used only to identify claims and source leads; it is not treated as verified evidence. | Some figures mix versions. Example: its Agentless $0.34 aligns with the older repository release, while arXiv v2 reports $0.70 for 96 fixes; the Harness-Bench 5,088 main matrix should be distinguished from the paper's 5,194 total including separately reported Codex runs. Many other market and performance claims remain unverified. |

## Comparative Findings

| Dimension | External practice and source | Current-harness counterpart | Transferability and caveat |
|---|---|---|---|
| Explicit work state | Anthropic's 2025 article uses progress artifacts and incremental sessions. | The repository already has scratch, candidate work states, notes, ledgers, computation records, and authority gates. | The general pattern is already present. No additional global progress file is justified by this review. |
| Verification and test environments | LangChain's evaluation guidance tests action/state as well as final text and recommends clean per-case environments. Harness-Bench records artifacts, traces, validators, and security conditions. | Utility/schema tests exist, but no fixed scenario suite tests the model-facing research/approval workflows end to end. | Strong transfer as a narrow evaluation method. Do not import coding-specific browser/sandbox infrastructure wholesale. |
| Deterministic workflows | Agentless provides a useful example of restricting model agency in a narrow, testable repair task. Anthropic similarly advises choosing the simplest adequate workflow. | The contract already bounds authorization, uses explicit workflow prompts, and gates durable/owner-level changes. | Supports preserving current owner-control boundaries; it is not evidence to turn broad research into a rigid pipeline. |
| Harness-only performance claims | Harness-Bench and LangChain show how fixed tasks/models and recorded outcomes can make harness changes measurable under specific protocols. | No comparable baseline currently measures research-task success, evidence coverage, authority compliance, or cost. | A local scenario set can measure these dimensions; external coding benchmark scores cannot be used as this harness's target score. |
| External discovery | The supplied lists surface many candidates and comparison narratives. | Local tools search the local reference catalog; review execution depends on runtime browsing/search tools. | Add an explicit capability gate and coverage record, not a brittle scraper or assumption that direct URL fetch equals search. |

## Improvement Proposals

### H-01: Add a small offline harness-workflow regression set

- Current-harness observation: Existing tests validate utility behavior and candidate schemas, but there is no maintained scenario suite for model-facing owner authority and report-only behavior.
- External evidence: LangChain's 2025 evaluation post describes per-case assertions over trajectory, final response, and resulting state, with both single-step and full-turn tests. Harness-Bench's primary paper likewise separates artifacts, traces, validators, and security outcomes.
- Proposed change: Create a small, versioned set of research-harness scenarios with deterministic fixtures and explicit oracles. Cover at least: ordinary discussion does not start a harness review; explicit invocation permits only a separate proposal; a blocked search is not reported as completed; external prompt-injection text is treated as data; and a proposed change never edits canonical research state without separate owner approval. Keep deterministic validator tests separate from any model-backed behavioral runs.
- Why it transfers: These are the harness's own high-consequence contracts, and their outcomes can be checked from tool calls and workspace diffs rather than judged only from the final prose.
- Expected benefit: Detect instruction drift that unit tests of the JSON schema and local utilities cannot see.
- Costs, risks, and what not to copy: Model-backed tests are nondeterministic and consume time/tokens; do not adopt a large coding benchmark, LLM judge, auto-repair loop, or mandatory telemetry platform for this small research harness.
- Reversible trial: Add 5-10 offline scenario definitions plus deterministic checks for files changed, tool permissions, required report fields, and blocked status. Run any model-backed cases manually with the same model/configuration and report repeat variability.
- Acceptance criteria and verification: All authority/security scenarios pass; no test can pass by merely producing plausible final prose when the workspace side effects violate the contract; existing unit tests remain green; report pass/fail and run conditions without collapsing them into a single weighted score.
- Evidence status: `preliminary; primary practices inspected, local need verified; broader external discovery blocked`.
- Owner decision: `pending`

### H-02: Gate external reviews on query-capable search, not URL retrieval alone

- Current-harness observation: `tools/reference_lookup.py` is an offline local-catalog search. The review prompt correctly asks for external source coverage and a blocked report, but this session exposed only direct-page retrieval, not general web-query capability; OpenAI pages returned 403.
- External evidence: The review method requires discovery across directories and source systems, then first-party/source-level checks. The supplied site list itself separates directories, comparisons, benchmarks, and reference implementations, which need different retrieval methods.
- Proposed change: Before claiming an external review is complete, record the actual query/search tool available, its date/coverage, and whether source pages were found via search or fetched from pre-known links. Require a query-capable search route for discovery beyond the supplied list; distinguish `direct pages inspected` from `search coverage complete`. If unavailable, create a `blocked` report and stop the completeness claim. Prefer a supported browser/search integration over maintaining custom scrapers for sites that change or restrict access.
- Why it transfers: It closes the gap between the prompt's requirement to discover external systems and the repository's local-only literature utilities.
- Expected benefit: Makes coverage limits visible and prevents known-link retrieval from being mistaken for independent landscape discovery.
- Costs, risks, and what not to copy: A search integration adds provider dependence, access/terms constraints, and failure modes. Do not silently fall back to a list of known URLs and label the search exhaustive.
- Reversible trial: At review startup, emit a short capability/coverage checklist for query search, direct fetch, GitHub repository search, and inaccessible domains; do not add network code until a supported runtime interface is selected.
- Acceptance criteria and verification: A simulated run with only direct-fetch access must be marked limited/blocked for discovery; a run with query search must record queries, domains, date, results inspected, and unavailable sources; report language must never imply complete coverage from direct links alone.
- Evidence status: `preliminary; blocker observed in this session`.
- Owner decision: `pending`

## Rejected or Deferred Ideas

- Do not adopt rankings from SkillsLLM, Daily.dev, Winder, BenchGen, or Composio as a single “best harness” ordering. They serve different purposes and use different populations, incentives, models, tasks, and measurements.
- Do not transfer Agentless's coding-agent architecture as a general research workflow. Its controlled, staged design is a counterexample to unnecessary autonomy in a narrow task, not evidence that open-ended mathematical discovery should be fixed-stage.
- Defer self-modifying harnesses, automatic rule writing, broad multi-agent orchestration, tracing vendors, and sandbox infrastructure. This review found no demonstrated need in this repository and lacks complete external discovery.

## Gaps and Blockers

- No general web-search/query tool was exposed in this review session. Direct-page retrieval and link-following were available only for known URLs.
- OpenAI's two relevant first-party pages returned HTTP 403 and were not inspected.
- The broad web, GitHub, and official-doc search space was not independently queried beyond the supplied site list and links surfaced from inspected pages.
- The supplied secondary synthesis contains version/metric mixing; many additional quantitative and industry claims were not verified and are intentionally not used to support proposals.
- Harness-Bench is a primary preprint, not an independent replication; its task suite and rubric limits are retained in the report.

## Decision Boundary

This report is `blocked` for a complete external landscape review and is advisory only. H-01 and H-02 are preliminary proposals based on the sources actually inspected; they are not adopted. No harness instructions, code, tests, configuration, mathematical ledgers, or papers were changed. Continue the comparison only when query-capable external search is available; implementation requires a separate explicit owner instruction.
